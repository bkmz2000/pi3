/* global React, T, Icon, Pi3Logo */

// ─────────────────────────────────────────────────────────────────────────────
// CANVAS WINDOW — native-feeling floating window with playback controls
// ─────────────────────────────────────────────────────────────────────────────

// ── Traffic lights ────────────────────────────────────────────────────────────
function TrafficLights({ hovering }) {
  const lights = [
    { color: "#ff5f56", hover: "#ff3a2d", icon: "✕" },
    { color: "#ffbd2e", hover: "#ffaa00", icon: "−" },
    { color: "#27c93f", hover: "#1aab29", icon: "+" },
  ];
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
      {lights.map((l, i) => (
        <div key={i} style={{
          width: 12, height: 12, borderRadius: T.rPill,
          background: l.color,
          display: "flex", alignItems: "center", justifyContent: "center",
          cursor: "pointer",
          transition: "background 0.1s",
          fontSize: 8, fontWeight: 800, color: "rgba(0,0,0,0.5)",
          lineHeight: 1,
        }}>
          {hovering ? l.icon : ""}
        </div>
      ))}
    </div>
  );
}

// ── Speed dial ────────────────────────────────────────────────────────────────
function SpeedDial({ speed, setSpeed }) {
  const steps = [0.25, 0.5, 1, 2, 4];
  const labels = { 0.25: "¼×", 0.5: "½×", 1: "1×", 2: "2×", 4: "4×" };
  return (
    <div style={{
      display: "flex", alignItems: "center",
      background: "rgba(0,0,0,0.25)",
      borderRadius: T.rPill,
      padding: 2, gap: 1,
    }}>
      {steps.map(s => (
        <button key={s} onClick={() => setSpeed(s)} style={{
          all: "unset", cursor: "pointer",
          padding: "3px 7px", borderRadius: T.rPill,
          background: speed === s ? "rgba(255,255,255,0.22)" : "transparent",
          color: speed === s ? "#fff" : "rgba(255,255,255,0.5)",
          fontFamily: T.fontMono, fontSize: 10.5, fontWeight: 700,
          lineHeight: 1, transition: "all 0.1s",
        }}>
          {labels[s]}
        </button>
      ))}
    </div>
  );
}

// ── Canvas placeholder (simulated pyxel output) ───────────────────────────────
function CanvasPlaceholder({ width, height, paused }) {
  // Fake "pong" scene as SVG
  return (
    <div style={{
      width, height,
      background: "#072428",
      position: "relative",
      imageRendering: "pixelated",
      overflow: "hidden",
    }}>
      {/* Court center line */}
      {Array.from({ length: 10 }).map((_, i) => (
        <div key={i} style={{
          position: "absolute",
          left: "50%", top: `${i * 10 + 2}%`,
          width: 2, height: "6%",
          background: "rgba(95,212,220,0.2)",
          transform: "translateX(-50%)",
        }} />
      ))}
      {/* Paddles */}
      <div style={{
        position: "absolute", left: 12, top: "35%",
        width: 6, height: "30%",
        background: "#fffaf0",
      }} />
      <div style={{
        position: "absolute", right: 12, top: "50%",
        width: 6, height: "30%",
        background: "#fffaf0",
      }} />
      {/* Ball */}
      <div style={{
        position: "absolute", left: "62%", top: "42%",
        width: 6, height: 6,
        background: "#5fd4dc",
        borderRadius: 1,
      }} />
      {/* Score */}
      <div style={{
        position: "absolute", top: 12, left: 0, right: 0,
        display: "flex", justifyContent: "center", gap: 32,
        fontFamily: T.fontMono, fontSize: 20, fontWeight: 700, color: "#fffaf0",
        opacity: 0.9,
      }}>
        <span>3</span>
        <span>5</span>
      </div>
      {/* Pause overlay */}
      {paused && (
        <div style={{
          position: "absolute", inset: 0,
          background: "rgba(7,36,40,0.72)",
          display: "flex", alignItems: "center", justifyContent: "center",
          backdropFilter: "blur(1px)",
        }}>
          <div style={{
            display: "flex", flexDirection: "column", alignItems: "center", gap: 8,
          }}>
            <div style={{
              width: 42, height: 42, borderRadius: T.rPill,
              background: "rgba(255,250,240,0.1)", border: "1.5px solid rgba(255,250,240,0.3)",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              <div style={{ display: "flex", gap: 4 }}>
                <div style={{ width: 3, height: 16, background: "#fffaf0", borderRadius: 2 }} />
                <div style={{ width: 3, height: 16, background: "#fffaf0", borderRadius: 2 }} />
              </div>
            </div>
            <span style={{
              fontFamily: T.fontMono, fontSize: 11, color: "rgba(255,250,240,0.55)",
              textTransform: "uppercase", letterSpacing: 1,
            }}>paused</span>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Full canvas window ────────────────────────────────────────────────────────
function CanvasWindow({ paused: initPaused = false, speed: initSpeed = 1 }) {
  const [paused, setPaused] = React.useState(initPaused);
  const [speed, setSpeed] = React.useState(initSpeed);
  const [hovering, setHovering] = React.useState(false);
  const [fps] = React.useState(30);
  const W = 320, H = 240;

  return (
    <div style={{
      width: W + 2, // +border
      background: "#0a3d44",
      borderRadius: 10,
      boxShadow: "0 22px 60px -10px rgba(0,0,0,0.55), 0 4px 14px rgba(0,0,0,0.22)",
      border: "1px solid rgba(255,255,255,0.10)",
      overflow: "hidden",
      fontFamily: T.fontUI,
      userSelect: "none",
    }}>
      {/* ── Title bar (drag handle) ── */}
      <div
        onMouseEnter={() => setHovering(true)}
        onMouseLeave={() => setHovering(false)}
        style={{
          height: 36,
          background: "linear-gradient(180deg, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0.03) 100%)",
          borderBottom: "1px solid rgba(255,255,255,0.08)",
          display: "flex", alignItems: "center",
          padding: "0 10px",
          cursor: "grab",
          gap: 10,
        }}
      >
        <TrafficLights hovering={hovering} />

        {/* Title */}
        <div style={{
          flex: 1, textAlign: "center",
          fontSize: 12, fontWeight: 600,
          color: "rgba(255,250,240,0.65)",
          letterSpacing: 0.2,
          pointerEvents: "none",
          display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
        }}>
          <span>Canvas</span>
          <span style={{
            fontFamily: T.fontMono, fontSize: 10,
            color: "rgba(255,250,240,0.35)",
          }}>{W}×{H}</span>
        </div>
      </div>

      {/* ── Toolbar ── */}
      <div style={{
        height: 34,
        background: "rgba(0,0,0,0.18)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
        display: "flex", alignItems: "center",
        padding: "0 10px",
        gap: 6,
      }}>
        {/* Pause / resume */}
        <button
          onClick={() => setPaused(p => !p)}
          title={paused ? "Resume" : "Pause"}
          style={{
            all: "unset", cursor: "pointer",
            width: 28, height: 28, borderRadius: 7,
            display: "flex", alignItems: "center", justifyContent: "center",
            background: paused ? "rgba(246,165,96,0.22)" : "rgba(255,255,255,0.08)",
            color: paused ? T.student : "rgba(255,250,240,0.7)",
            transition: "all 0.12s",
          }}
        >
          {/* Pause icon = two bars; play = triangle */}
          {paused ? (
            <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor">
              <polygon points="2,1 10,6 2,11" />
            </svg>
          ) : (
            <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor">
              <rect x="2" y="1" width="3" height="10" rx="1" />
              <rect x="7" y="1" width="3" height="10" rx="1" />
            </svg>
          )}
        </button>

        {/* Step frame (only when paused) */}
        {paused && (
          <button title="Step one frame" style={{
            all: "unset", cursor: "pointer",
            width: 28, height: 28, borderRadius: 7,
            display: "flex", alignItems: "center", justifyContent: "center",
            background: "rgba(255,255,255,0.08)",
            color: "rgba(255,250,240,0.7)",
          }}>
            <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor">
              <polygon points="2,2 8,6 2,10" />
              <rect x="9" y="2" width="2" height="8" rx="1" />
            </svg>
          </button>
        )}

        <div style={{ width: 1, height: 18, background: "rgba(255,255,255,0.10)" }} />

        {/* Speed dial */}
        <SpeedDial speed={speed} setSpeed={setSpeed} />

        <div style={{ flex: 1 }} />

        {/* FPS counter */}
        {!paused && (
          <div style={{
            fontFamily: T.fontMono, fontSize: 10.5,
            color: fps >= 25 ? "rgba(95,212,220,0.7)" : "rgba(251,191,119,0.8)",
            padding: "2px 6px",
          }}>
            {fps} fps
          </div>
        )}

        <div style={{ width: 1, height: 18, background: "rgba(255,255,255,0.10)" }} />

        {/* Screenshot */}
        <button title="Save screenshot" style={{
          all: "unset", cursor: "pointer",
          width: 28, height: 28, borderRadius: 7,
          display: "flex", alignItems: "center", justifyContent: "center",
          background: "rgba(255,255,255,0.08)",
          color: "rgba(255,250,240,0.7)",
        }}>
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
            <rect x="2" y="4" width="12" height="10" rx="2" />
            <circle cx="8" cy="9.5" r="2.5" />
            <path d="M5.5 4V3.5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1V4" />
            <circle cx="13" cy="5.5" r="0.5" fill="currentColor" />
          </svg>
        </button>

        {/* Resize / popout */}
        <button title="Pop out to full screen" style={{
          all: "unset", cursor: "pointer",
          width: 28, height: 28, borderRadius: 7,
          display: "flex", alignItems: "center", justifyContent: "center",
          background: "rgba(255,255,255,0.08)",
          color: "rgba(255,250,240,0.7)",
        }}>
          <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
            <path d="M10 3h3v3M9 7l4-4M6 13H3v-3m0 3l4-4" />
          </svg>
        </button>
      </div>

      {/* Canvas */}
      <CanvasPlaceholder width={W} height={H} paused={paused} />
    </div>
  );
}

// ── Artboard: show live + paused side by side ─────────────────────────────────
function CanvasWindowArtboard() {
  return (
    <div style={{
      width: "100%", height: "100%",
      background: "#e9e3d3",
      display: "flex", alignItems: "center", justifyContent: "center",
      gap: 40, flexWrap: "wrap", padding: 32,
    }}>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12 }}>
        <div style={{ fontSize: 10.5, fontWeight: 700, color: T.txtMute, letterSpacing: 0.6, textTransform: "uppercase" }}>Running · 1×</div>
        <CanvasWindow paused={false} speed={1} />
      </div>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12 }}>
        <div style={{ fontSize: 10.5, fontWeight: 700, color: T.txtMute, letterSpacing: 0.6, textTransform: "uppercase" }}>Paused</div>
        <CanvasWindow paused={true} speed={1} />
      </div>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12 }}>
        <div style={{ fontSize: 10.5, fontWeight: 700, color: T.txtMute, letterSpacing: 0.6, textTransform: "uppercase" }}>Fast · 2×</div>
        <CanvasWindow paused={false} speed={2} />
      </div>
    </div>
  );
}

window.CanvasWindowArtboard = CanvasWindowArtboard;
