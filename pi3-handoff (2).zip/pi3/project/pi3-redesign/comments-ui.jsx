/* global React, T, Avatar, RoleTag, Icon */

// ─────────────────────────────────────────────────────────────────────────────
// COMMENT THREADS + IN-EDITOR MOCK
// ─────────────────────────────────────────────────────────────────────────────

// ── Shared primitives ─────────────────────────────────────────────────────────

function CommentBubble({ c, isTeacher }) {
  const bg   = isTeacher ? T.teacherSoft : T.chip;
  const line = isTeacher ? T.teacherLine : T.border;
  return (
    <div style={{
      padding: "10px 12px",
      background: bg,
      border: `1px solid ${line}`,
      borderRadius: isTeacher ? "8px 8px 8px 2px" : "8px 8px 2px 8px",
    }}>
      <div style={{
        display: "flex", alignItems: "center", gap: 8, marginBottom: 6,
      }}>
        <Avatar name={c.author} role={isTeacher ? "teacher" : "student"} size={22} />
        <span style={{ flex: 1, fontSize: 12.5, fontWeight: 700, color: T.txt }}>{c.author}</span>
        <span style={{ fontSize: 11, color: T.txtFaint, fontFamily: T.fontMono }}>{c.time}</span>
        <RoleTag role={isTeacher ? "teacher" : "student"} />
      </div>
      <div style={{ fontSize: 13.5, color: T.txt, lineHeight: 1.55 }}>{c.text}</div>
    </div>
  );
}

// ── Thread panel (floating, anchored to a line) ───────────────────────────────

const THREAD_A = {
  id: "t1",
  line: 18,
  anchor: "self.move(self.dy)",
  resolved: false,
  comments: [
    {
      id: "c1", author: "Ms. Hopper", role: "teacher", time: "10:12",
      text: "This method doesn't exist yet on your Paddle class — did you mean self.dy += … ? Check the Paddle.__init__ for what attributes you defined.",
    },
    {
      id: "c2", author: "Ada L.", role: "student", time: "10:14",
      text: "Oh I see — I was calling move() but never defined it. I'll update __init__ to just use dy directly.",
    },
    {
      id: "c3", author: "Ms. Hopper", role: "teacher", time: "10:15",
      text: "Exactly! That's the fix. Once you've updated it, run your tests.",
    },
  ],
};

const THREAD_B = {
  id: "t2",
  line: 34,
  anchor: "if score >= WIN_SCORE:",
  resolved: true,
  comments: [
    {
      id: "c4", author: "Ms. Hopper", role: "teacher", time: "yesterday",
      text: "Nice — just move this win-check outside the for-loop so it runs every frame, not once per paddle.",
    },
    {
      id: "c5", author: "Ada L.", role: "student", time: "yesterday",
      text: "Done, moved it and it works now, thanks!",
    },
  ],
};

function ThreadPanel({ thread, onClose, composing, setComposing, draft, setDraft, canReply = true }) {
  const isResolved = thread.resolved;

  return (
    <div style={{
      width: 340,
      background: T.panel,
      border: `1px solid ${T.border}`,
      borderRadius: 12,
      boxShadow: T.shadowPop,
      fontFamily: T.fontUI,
      display: "flex",
      flexDirection: "column",
      overflow: "hidden",
    }}>
      {/* Header */}
      <div style={{
        display: "flex", alignItems: "center", gap: 8,
        padding: "12px 14px",
        borderBottom: `1px solid ${T.border}`,
        background: T.panelHeader,
      }}>
        {/* Line anchor */}
        <div style={{
          display: "inline-flex", alignItems: "center", gap: 6,
          padding: "3px 9px", borderRadius: T.rPill,
          background: T.surface, border: `1px solid ${T.border}`,
          fontFamily: T.fontMono, fontSize: 11, color: T.txtMute,
        }}>
          L{thread.line}
          <span style={{ color: T.teal }}>·</span>
          <span style={{ color: T.txt, maxWidth: 140, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {thread.anchor}
          </span>
        </div>
        <div style={{ flex: 1 }} />
        {isResolved && (
          <span style={{
            display: "inline-flex", alignItems: "center", gap: 5,
            padding: "2px 8px", borderRadius: T.rPill,
            background: T.okSoft, color: T.ok,
            fontSize: 10.5, fontWeight: 700, letterSpacing: 0.3, textTransform: "uppercase",
          }}>
            <Icon name="check" size={10} />
            Resolved
          </span>
        )}
        <button onClick={onClose} style={{
          all: "unset", cursor: "pointer", width: 26, height: 26, borderRadius: 6,
          display: "inline-flex", alignItems: "center", justifyContent: "center",
          color: T.txtMute,
        }}>
          <Icon name="close" size={12} />
        </button>
      </div>

      {/* Comments */}
      <div style={{
        padding: "12px 14px",
        display: "flex", flexDirection: "column", gap: 8,
        maxHeight: 320, overflowY: "auto",
      }}>
        {thread.comments.map(c => (
          <CommentBubble key={c.id} c={c} isTeacher={c.role === "teacher"} />
        ))}
      </div>

      {/* Compose reply — only for open threads */}
      {!isResolved && canReply && (
        <div style={{
          padding: "10px 14px",
          borderTop: `1px solid ${T.border}`,
          background: T.surface,
          display: "flex", flexDirection: "column", gap: 8,
        }}>
          <textarea
            placeholder="Reply…"
            value={draft}
            onChange={e => setDraft(e.target.value)}
            rows={composing ? 3 : 1}
            onFocus={() => setComposing(true)}
            style={{
              all: "unset", display: "block", width: "100%", boxSizing: "border-box",
              padding: "9px 12px",
              background: T.panel, border: `1px solid ${composing ? T.tealLine : T.border}`,
              borderRadius: T.rInput,
              fontFamily: T.fontUI, fontSize: 13.5, color: T.txt,
              resize: "none", lineHeight: 1.5,
              boxShadow: composing ? `0 0 0 3px ${T.tealSoft}` : "none",
              transition: "all 0.15s",
            }}
          />
          {composing && (
            <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", alignItems: "center" }}>
              <span style={{ flex: 1, fontSize: 11, color: T.txtFaint }}>
                ⌘ Return to send
              </span>
              <button style={{
                all: "unset", cursor: "pointer",
                padding: "6px 12px", borderRadius: 6,
                background: T.surface, border: `1px solid ${T.border}`,
                color: T.txtMute, fontSize: 12, fontWeight: 600,
              }}>Cancel</button>
              <button style={{
                all: "unset", cursor: "pointer",
                padding: "6px 14px", borderRadius: 6,
                background: T.tealDeep, color: "#fffaf0",
                fontSize: 12, fontWeight: 700,
              }}>Reply</button>
            </div>
          )}
        </div>
      )}

      {/* Resolve footer */}
      {!isResolved && (
        <div style={{
          padding: "10px 14px",
          borderTop: `1px solid ${T.border}`,
          display: "flex", justifyContent: "space-between", alignItems: "center",
        }}>
          <span style={{ fontSize: 11.5, color: T.txtMute }}>
            {thread.comments.length} comment{thread.comments.length !== 1 ? "s" : ""}
          </span>
          <button style={{
            all: "unset", cursor: "pointer",
            display: "inline-flex", alignItems: "center", gap: 6,
            padding: "6px 12px", borderRadius: 6,
            background: T.okSoft, color: T.ok,
            fontSize: 12, fontWeight: 700,
          }}>
            <Icon name="check" size={12} />
            Resolve thread
          </button>
        </div>
      )}
    </div>
  );
}

// ── Compose new thread ────────────────────────────────────────────────────────

function NewThreadCompose({ line, anchor }) {
  const [draft, setDraft] = React.useState("Have you tried using self.rect.move_ip() from pygame.Rect? It handles boundary clamping for you.");
  return (
    <div style={{
      width: 340,
      background: T.panel,
      border: `1px solid ${T.tealLine}`,
      borderRadius: 12,
      boxShadow: `${T.shadowPop}, 0 0 0 3px ${T.tealSoft}`,
      fontFamily: T.fontUI,
      overflow: "hidden",
    }}>
      {/* Header */}
      <div style={{
        display: "flex", alignItems: "center", gap: 8,
        padding: "12px 14px",
        borderBottom: `1px solid ${T.border}`,
        background: T.panelHeader,
      }}>
        <div style={{
          display: "inline-flex", alignItems: "center", gap: 6,
          padding: "3px 9px", borderRadius: T.rPill,
          background: T.tealSoft, border: `1px solid ${T.tealLine}`,
          fontFamily: T.fontMono, fontSize: 11, color: T.tealDeep,
        }}>
          <Icon name="plus" size={10} color={T.teal} />
          New comment · L{line}
          <span style={{ color: T.teal }}>·</span>
          <span style={{ maxWidth: 120, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {anchor}
          </span>
        </div>
        <div style={{ flex: 1 }} />
        <button style={{
          all: "unset", cursor: "pointer", width: 26, height: 26, borderRadius: 6,
          display: "inline-flex", alignItems: "center", justifyContent: "center",
          color: T.txtMute,
        }}>
          <Icon name="close" size={12} />
        </button>
      </div>
      {/* Compose */}
      <div style={{ padding: "12px 14px", display: "flex", gap: 10 }}>
        <Avatar name="Ms. Hopper" role="teacher" size={28} />
        <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 8 }}>
          <textarea
            defaultValue={draft}
            rows={4}
            style={{
              all: "unset", display: "block", width: "100%", boxSizing: "border-box",
              padding: "9px 12px",
              background: T.surface, border: `1px solid ${T.tealLine}`,
              borderRadius: T.rInput,
              fontFamily: T.fontUI, fontSize: 13.5, color: T.txt,
              resize: "none", lineHeight: 1.55,
              boxShadow: `0 0 0 3px ${T.tealSoft}`,
            }}
          />
          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", alignItems: "center" }}>
            <span style={{ flex: 1, fontSize: 11, color: T.txtFaint }}>⌘ Return to post</span>
            <button style={{
              all: "unset", cursor: "pointer",
              padding: "6px 12px", borderRadius: 6,
              background: T.surface, border: `1px solid ${T.border}`,
              color: T.txtMute, fontSize: 12, fontWeight: 600,
            }}>Discard</button>
            <button style={{
              all: "unset", cursor: "pointer",
              padding: "6px 14px", borderRadius: 6,
              background: T.tealDeep, color: "#fffaf0",
              fontSize: 12, fontWeight: 700,
            }}>Post comment</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Editor mock ───────────────────────────────────────────────────────────────

const CODE_LINES = [
  { n: 14, text: "class Paddle:" },
  { n: 15, text: "    def __init__(self, x, y):" },
  { n: 16, text: "        self.x = x" },
  { n: 17, text: "        self.y = y" },
  { n: 18, text: "        self.dy = 0", comment: "open",    dots: 3 },
  { n: 19, text: "        self.width = 12" },
  { n: 20, text: "        self.height = 80" },
  { n: 21, text: "" },
  { n: 22, text: "    def update(self):" },
  { n: 23, text: "        if self.dy != 0:" },
  { n: 24, text: '            self.move(self.dy)', error: true },
  { n: 25, text: "        self.y += self.dy" },
  { n: 26, text: "        self.draw()" },
  { n: 27, text: "" },
  { n: 28, text: "    def draw(self):" },
  { n: 29, text: "        pyxel.rect(self.x, self.y," },
  { n: 30, text: "                   self.width, self.height, 7)" },
  { n: 31, text: "" },
  { n: 32, text: "class Ball:" },
  { n: 33, text: "    def __init__(self):" },
  { n: 34, text: "        if score >= WIN_SCORE:", comment: "resolved", dots: 2 },
  { n: 35, text: "            game_over()" },
];

function syn(text) {
  // super minimal syntax coloring
  if (text.trim().startsWith("#")) {
    return <span style={{ color: "#9aa6b2", fontStyle: "italic" }}>{text}</span>;
  }
  // keywords
  let result = text
    .replace(/\b(class|def|if|self|return|import)\b/g, m => `<k>${m}</k>`)
    .replace(/"([^"]*)"/g, m => `<s>${m}</s>`)
    .replace(/\b(\d+)\b/g, m => `<n>${m}</n>`);

  const parts = [];
  let rest = result;
  let i = 0;
  const tagMap = { k: "#c2410c", s: "#15803d", n: "#a16207" };
  while (rest.length) {
    const match = rest.match(/^(.*?)<(k|s|n)>(.*?)<\/\2>(.*)/s);
    if (!match) { parts.push(<span key={i++}>{rest}</span>); break; }
    if (match[1]) parts.push(<span key={i++}>{match[1]}</span>);
    parts.push(<span key={i++} style={{ color: tagMap[match[2]] }}>{match[3]}</span>);
    rest = match[4];
  }
  return parts;
}

function GutterDot({ type }) {
  if (type === "open") return (
    <div style={{
      width: 10, height: 10, borderRadius: T.rPill,
      background: T.teal,
      boxShadow: `0 0 0 3px ${T.tealSoft}`,
      cursor: "pointer",
    }} />
  );
  if (type === "resolved") return (
    <div style={{
      width: 10, height: 10, borderRadius: T.rPill,
      background: T.ok, opacity: 0.6,
      cursor: "pointer",
    }} />
  );
  return null;
}

function EditorMock({ activeThread = "open", showCompose = false }) {
  const [openLine, setOpenLine] = React.useState(18);
  const [composing, setComposing] = React.useState(false);
  const [draft, setDraft] = React.useState("");

  return (
    <div style={{
      width: "100%", height: "100%",
      display: "flex", flexDirection: "column",
      background: "#fffaf0",
      fontFamily: T.fontMono,
      fontSize: 13,
      lineHeight: "1.65",
      position: "relative",
    }}>
      {/* Fake file bar */}
      <div style={{
        height: 36, flex: "none",
        display: "flex", alignItems: "center",
        background: "#0e9aa7",
        padding: "0 14px", gap: 2,
      }}>
        <div style={{
          padding: "5px 14px",
          background: "#fffaf0", borderRadius: "4px 4px 0 0",
          color: "#0a3d44", fontFamily: T.fontMono, fontSize: 12, fontWeight: 600,
        }}>main.py</div>
        <div style={{
          padding: "5px 14px",
          color: "rgba(255,255,255,0.7)", fontFamily: T.fontMono, fontSize: 12,
        }}>utils.py</div>
      </div>

      {/* Code area */}
      <div style={{ flex: 1, overflow: "auto", display: "flex" }}>
        {/* Line numbers + gutter */}
        <div style={{
          flex: "none",
          display: "flex", flexDirection: "column",
          background: "#fffaf0",
          userSelect: "none",
        }}>
          {CODE_LINES.map(l => (
            <div key={l.n} style={{
              height: "1.65em",
              display: "flex", alignItems: "center",
              gap: 6,
              paddingLeft: 12,
            }}>
              <span style={{
                width: 24, textAlign: "right",
                fontFamily: T.fontMono, fontSize: 12,
                color: l.comment === "open" ? T.teal : "#b6c2c8",
                fontWeight: l.comment ? 700 : 400,
              }}>{l.n}</span>
              <div style={{
                width: 16, display: "flex", alignItems: "center", justifyContent: "center",
              }}>
                {l.comment && <GutterDot type={l.comment} />}
              </div>
            </div>
          ))}
        </div>

        {/* Code text */}
        <div style={{ flex: 1, overflow: "auto", padding: "0 0 0 8px" }}>
          {CODE_LINES.map(l => (
            <div key={l.n} style={{
              height: "1.65em",
              display: "flex", alignItems: "center",
              background: l.comment === "open" && openLine === l.n
                ? "rgba(14,154,167,0.06)"
                : l.error ? "rgba(196,69,28,0.07)" : "transparent",
              paddingRight: 16,
              whiteSpace: "pre",
            }}>
              <code style={{ fontSize: 13 }}>{syn(l.text)}</code>
              {/* Inline comment indicator */}
              {l.comment === "open" && (
                <span style={{
                  marginLeft: "1.5em",
                  display: "inline-flex", alignItems: "center", gap: 5,
                  padding: "1px 8px", borderRadius: 3,
                  background: T.tealSoft, color: T.tealDeep,
                  fontFamily: T.fontUI, fontSize: 11, fontWeight: 600,
                  cursor: "pointer", whiteSpace: "nowrap",
                }}>
                  <Icon name="users" size={10} color={T.teal} />
                  {l.dots} comment{l.dots > 1 ? "s" : ""}
                </span>
              )}
              {l.comment === "resolved" && (
                <span style={{
                  marginLeft: "1.5em",
                  display: "inline-flex", alignItems: "center", gap: 5,
                  padding: "1px 8px", borderRadius: 3,
                  background: T.okSoft, color: T.ok,
                  fontFamily: T.fontUI, fontSize: 11, fontWeight: 500,
                  cursor: "pointer", whiteSpace: "nowrap", opacity: 0.7,
                }}>
                  <Icon name="check" size={10} color={T.ok} />
                  resolved
                </span>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Thread panel — pinned to right of editor */}
      {activeThread === "open" && (
        <div style={{
          position: "absolute", top: 36 + 4 * (18 - 14 + 1) * 1.65 * 13 + 8,
          right: 12,
          zIndex: 10,
        }}>
          <ThreadPanel
            thread={THREAD_A}
            onClose={() => {}}
            composing={composing}
            setComposing={setComposing}
            draft={draft}
            setDraft={setDraft}
          />
        </div>
      )}
    </div>
  );
}

// ── Standalone artboards ──────────────────────────────────────────────────────

function ThreadOpenArtboard() {
  const [composing, setComposing] = React.useState(false);
  const [draft, setDraft] = React.useState("");
  return (
    <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "center", gap: 24, padding: 32, background: "#e9e3d3", width: "100%", height: "100%", flexWrap: "wrap" }}>
      <div>
        <div style={{ fontFamily: T.fontUI, fontSize: 10.5, fontWeight: 700, color: T.txtMute, letterSpacing: 0.6, textTransform: "uppercase", marginBottom: 10 }}>Open thread</div>
        <ThreadPanel
          thread={THREAD_A}
          onClose={() => {}}
          composing={composing}
          setComposing={setComposing}
          draft={draft}
          setDraft={setDraft}
        />
      </div>
      <div>
        <div style={{ fontFamily: T.fontUI, fontSize: 10.5, fontWeight: 700, color: T.txtMute, letterSpacing: 0.6, textTransform: "uppercase", marginBottom: 10 }}>Resolved thread</div>
        <ThreadPanel
          thread={THREAD_B}
          onClose={() => {}}
          composing={composing}
          setComposing={setComposing}
          draft={draft}
          setDraft={setDraft}
          canReply={false}
        />
      </div>
      <div>
        <div style={{ fontFamily: T.fontUI, fontSize: 10.5, fontWeight: 700, color: T.txtMute, letterSpacing: 0.6, textTransform: "uppercase", marginBottom: 10 }}>New comment compose</div>
        <NewThreadCompose line={24} anchor="self.move(self.dy)" />
      </div>
    </div>
  );
}

function EditorWithThread() {
  return <EditorMock activeThread="open" />;
}

window.ThreadOpenArtboard = ThreadOpenArtboard;
window.EditorWithThread = EditorWithThread;
