/* global React, ReactDOM, D, Pi3, DIcon, DAvatar */
// COMPETE MODE — app shell. Rail + contest bar, then the two cohesive halves:
// the code editor (left) and the Problem / Visualizer panel (right).
const { useState, useEffect, useRef } = React;

const SAVE_KEY = "pi3compete.vizFrame";

function Rail() {
  const items = [
    { key: "compete", on: true, icon: <path d="M5 2h6v2.2a3 3 0 0 1-6 0V2zM4 3H2.4v1.2A2.4 2.4 0 0 0 4.9 6.4M12 3h1.6v1.2A2.4 2.4 0 0 1 11.1 6.4M6.2 8.4h3.6l-.4 2.4h1.2v1.4H5.4v-1.4h1.2z" stroke="currentColor" strokeWidth="1.3" fill="none" strokeLinejoin="round" /> },
    { key: "files", icon: window.DI.folder },
    { key: "class", icon: window.DI.users },
    { key: "more", icon: window.DI.dot3 },
  ];
  return (
    <div style={{ width: 56, background: D.rail, borderRight: `1px solid ${D.border}`, display: "flex", flexDirection: "column", alignItems: "center", padding: "12px 0", gap: 6, flex: "none" }}>
      <div style={{ marginBottom: 12 }}><Pi3 size={20} /></div>
      {items.map((it) => (
        <button key={it.key} title={it.key} style={{
          all: "unset", cursor: "pointer", width: 40, height: 40, borderRadius: 10,
          display: "inline-flex", alignItems: "center", justifyContent: "center",
          background: it.on ? "rgba(120,210,220,0.18)" : "transparent",
          color: it.on ? D.cyan : "rgba(155,210,216,0.7)",
          boxShadow: it.on ? `inset 0 0 0 1px ${D.cyanLine}` : "none",
        }}>
          <svg width="18" height="18" viewBox="0 0 16 16">{it.icon}</svg>
        </button>
      ))}
      <div style={{ flex: 1 }} />
      <DAvatar name="Ada Lovelace" role="student" size={32} />
    </div>
  );
}

function ContestBar() {
  const [left, setLeft] = useState(1 * 3600 + 24 * 60 + 6);
  useEffect(() => {
    const id = setInterval(() => setLeft((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => clearInterval(id);
  }, []);
  const hh = String(Math.floor(left / 3600)).padStart(1, "0");
  const mm = String(Math.floor((left % 3600) / 60)).padStart(2, "0");
  const ss = String(left % 60).padStart(2, "0");
  return (
    <div style={{ height: 48, flex: "none", display: "flex", alignItems: "center", gap: 14, padding: "0 18px", borderBottom: `1px solid ${D.border}`, background: D.surface }}>
      <span style={{ display: "inline-flex", alignItems: "center", gap: 8, fontFamily: D.fontUI, fontSize: 14, fontWeight: 800, color: D.txt }}>
        <span style={{ width: 7, height: 7, borderRadius: 7, background: D.warn, boxShadow: `0 0 8px ${D.warn}` }} />
        Weekly Contest 214
      </span>
      <span style={{ padding: "3px 10px", borderRadius: 999, background: D.chip, border: `1px solid ${D.border}`, fontFamily: D.fontMono, fontSize: 11.5, color: D.txtMute }}>Problem 2 / 5</span>
      <div style={{ flex: 1 }} />
      <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
        <button style={navBtn()}><DIcon name="back" size={13} /></button>
        <button style={navBtn()}><span style={{ transform: "scaleX(-1)", display: "inline-flex" }}><DIcon name="back" size={13} /></span></button>
      </div>
      <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "6px 14px", borderRadius: 8, background: D.warnSoft, border: `1px solid rgba(251,191,119,0.3)` }}>
        <svg width="13" height="13" viewBox="0 0 16 16" style={{ color: D.warn }}><g stroke="currentColor" strokeWidth="1.4" fill="none"><circle cx="8" cy="9" r="5" /><path d="M8 6.5V9l2 1.4M6.5 2.5h3" strokeLinecap="round" /></g></svg>
        <span style={{ fontFamily: D.fontMono, fontSize: 14, fontWeight: 700, color: D.warn, letterSpacing: 0.5, fontVariantNumeric: "tabular-nums" }}>{hh}:{mm}:{ss}</span>
        <span style={{ fontFamily: D.fontUI, fontSize: 11, color: D.txtMute }}>left</span>
      </div>
    </div>
  );
}
function navBtn() {
  return { all: "unset", cursor: "pointer", width: 30, height: 30, borderRadius: 7, display: "inline-flex", alignItems: "center", justifyContent: "center", background: D.chip, border: `1px solid ${D.border}`, color: D.txtMute };
}

function PanelTabs({ active, setActive }) {
  const tabs = [{ k: "problem", label: "Problem", icon: window.DI.file }, { k: "visualizer", label: "Visualizer", icon: <g stroke="currentColor" strokeWidth="1.4" fill="none"><circle cx="4" cy="5" r="2" /><circle cx="12" cy="5" r="2" /><circle cx="8" cy="12" r="2" /><path d="M5.7 6.2L10 11M10.3 6.2L6 11M6 5h4" /></g> }];
  return (
    <div style={{ height: 46, flex: "none", display: "flex", alignItems: "stretch", gap: 4, padding: "0 12px", borderBottom: `1px solid ${D.border}`, background: D.surface }}>
      {tabs.map((t) => {
        const on = active === t.k;
        return (
          <button key={t.k} onClick={() => setActive(t.k)} style={{
            all: "unset", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 8, padding: "0 16px",
            position: "relative", color: on ? D.txt : D.txtMute, fontFamily: D.fontUI, fontSize: 13.5, fontWeight: on ? 700 : 500,
          }}>
            <svg width="15" height="15" viewBox="0 0 16 16">{t.icon}</svg>
            {t.label}
            {on && <span style={{ position: "absolute", left: 12, right: 12, bottom: -1, height: 2.5, borderRadius: 2, background: D.cyan }} />}
          </button>
        );
      })}
    </div>
  );
}

function App() {
  const [fixed, setFixed] = useState(false);
  const [codeData, setCodeData] = useState(() => window.COMPETE_CODE(false));
  const [flashLine, setFlashLine] = useState(null);

  const [exampleRuns, setExampleRuns] = useState({
    1: { pass: true, got: "3" },
    2: { pass: false, got: "-1" },
  });

  const [consoleLines, setConsoleLines] = useState([]);
  const [consoleCollapsed, setConsoleCollapsed] = useState(false);
  const [running, setRunning] = useState(false);

  const [submitState, setSubmitState] = useState("idle"); // idle|running|wa|accepted
  const [hiddenProgress, setHiddenProgress] = useState(0);
  const [openDiffs, setOpenDiffs] = useState({ 3: true });
  const [submitting, setSubmitting] = useState(false);

  const [activeTab, setActiveTab] = useState("problem");

  // viz playback state (persisted)
  const [vizFrame, setVizFrame] = useState(() => {
    try { return Number(localStorage.getItem(SAVE_KEY)) || 318; } catch (e) { return 318; }
  });
  const [vizPlaying, setVizPlaying] = useState(false);
  const [vizSpeed, setVizSpeed] = useState(1);
  useEffect(() => {
    try { localStorage.setItem(SAVE_KEY, String(Math.round(vizFrame))); } catch (e) {}
  }, [vizFrame]);

  const timers = useRef([]);
  const after = (ms, fn) => { const id = setTimeout(fn, ms); timers.current.push(id); };
  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  function addConsole(text, kind) { setConsoleLines((p) => [...p, { text, kind }]); }

  function applyFixed(isFixed) {
    setFixed(isFixed);
    setCodeData(window.COMPETE_CODE(isFixed));
  }

  // ── Run (toolbar) — execute the visible examples, print to console ───────
  function handleRun() {
    if (running) return;
    setConsoleCollapsed(false);
    setRunning(true);
    setConsoleLines([{ text: "› python solution.py  (running sample cases)", kind: "info" }]);
    window.COMPETE_EXAMPLES.forEach((ex, i) => {
      after(420 + i * 380, () => {
        const pass = ex.pass(fixed), got = ex.got(fixed);
        setExampleRuns((p) => ({ ...p, [ex.id]: { pass, got } }));
        addConsole(`example ${ex.id}: min_cooldown(...) -> ${got}   ${pass ? "✓ matches expected" : "✗ expected " + ex.expected}`, pass ? null : "err");
      });
    });
    after(420 + window.COMPETE_EXAMPLES.length * 380 + 200, () => {
      const allPass = window.COMPETE_EXAMPLES.every((e) => e.pass(fixed));
      addConsole(allPass ? "all sample cases passed." : "1 sample case failed — see Example cards.", allPass ? "info" : "err");
      setRunning(false);
    });
  }

  // ── Submit — judge against public + hidden tests ─────────────────────────
  function runJudge(isFixed) {
    setSubmitting(true);
    setSubmitState("running");
    setHiddenProgress(0);
    setOpenDiffs(isFixed ? {} : { 3: true });
    setConsoleCollapsed(false);
    setConsoleLines([{ text: "› submitting to judge…", kind: "info" }]);
    setActiveTab("problem");

    const failAt = window.COMPETE_HIDDEN.failAt, total = window.COMPETE_HIDDEN.total;
    const target = isFixed ? total : failAt + 1;
    after(700, () => {
      addConsole("public tests…", null);
      let i = 0;
      const step = () => {
        i += Math.max(1, Math.round(total / 40));
        const v = Math.min(i, target);
        setHiddenProgress(v);
        if (v < target) { after(40, step); }
        else {
          if (isFixed) { addConsole("accepted — 847 ms · 14.2 MB", "info"); setSubmitState("accepted"); }
          else { addConsole(`wrong answer on hidden test ${failAt + 1} of ${total}`, "err"); setSubmitState("wa"); }
          setSubmitting(false);
        }
      };
      step();
    });
  }
  function handleSubmit() { if (!submitting) runJudge(fixed); }

  // ── Apply the suggested fix and auto-resubmit ────────────────────────────
  function handleFix() {
    applyFixed(true);
    setFlashLine(window.COMPETE_CODE(true).bugLine);
    setExampleRuns((p) => {
      const next = { ...p };
      window.COMPETE_EXAMPLES.forEach((ex) => { if (next[ex.id]) next[ex.id] = { pass: ex.pass(true), got: ex.got(true) }; });
      return next;
    });
    after(1400, () => setFlashLine(null));
    after(650, () => runJudge(true));
  }

  function toggleDiff(id) { setOpenDiffs((p) => ({ ...p, [id]: !p[id] })); }

  return (
    <div style={{ width: "100vw", height: "100vh", display: "flex", background: D.appBg, overflow: "hidden" }}>
      <Rail />
      <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
        <ContestBar />
        <div style={{ flex: 1, minHeight: 0, display: "flex" }}>
          {/* LEFT — editor */}
          <window.CompeteLeft
            codeData={codeData}
            flashLine={flashLine}
            onRun={handleRun}
            onSubmit={handleSubmit}
            running={running}
            submitting={submitting}
            consoleLines={consoleLines}
            consoleCollapsed={consoleCollapsed}
            onToggleConsole={() => setConsoleCollapsed((c) => !c)}
            onClearConsole={() => setConsoleLines([])}
          />

          {/* RIGHT — tabbed panel */}
          <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", background: D.appBg }}>
            <PanelTabs active={activeTab} setActive={setActiveTab} />
            <div style={{ flex: 1, minHeight: 0, display: activeTab === "problem" ? "flex" : "none" }}>
              <window.CompeteProblem
                fixed={fixed}
                exampleRuns={exampleRuns}
                onRunExample={(id) => {
                  setConsoleCollapsed(false);
                  setRunning(true);
                  setConsoleLines([{ text: `› running example ${id}…`, kind: "info" }]);
                  const ex = window.COMPETE_EXAMPLES.find((e) => e.id === id);
                  after(520, () => {
                    const pass = ex.pass(fixed), got = ex.got(fixed);
                    setExampleRuns((p) => ({ ...p, [id]: { pass, got } }));
                    addConsole(`example ${id} -> ${got}  ${pass ? "✓" : "✗ expected " + ex.expected}`, pass ? null : "err");
                    setRunning(false);
                  });
                }}
                submitState={submitState}
                hiddenProgress={hiddenProgress}
                openDiffs={openDiffs}
                onToggleDiff={toggleDiff}
                onFix={handleFix}
              />
            </div>
            <div style={{ flex: 1, minHeight: 0, display: activeTab === "visualizer" ? "flex" : "none" }}>
              <window.CompeteVisualizer
                frame={vizFrame} setFrame={setVizFrame}
                playing={vizPlaying} setPlaying={setVizPlaying}
                speed={vizSpeed} setSpeed={setVizSpeed}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
