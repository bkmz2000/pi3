/* global React */
// Content + state for pi3 Compete mode. Single source of truth so the
// editor, examples, submit results all stay coherent around one bug/fix.

// ── Code lines, hand-tokenized like the IDE's read-only viewer ───────────
// Each line is an array of [colorKey, text, colorKey, text, ...].
// Line index 6 (g[b].append(a)) is the bug: commented out in buggy mode,
// live in fixed mode. That single change flips ex2 + hidden tests.
window.COMPETE_CODE = function (fixed) {
  const C = [
    ["kw", "import", "pl", " collections"],
    ["blank"],
    ["kw", "def", "pl", " ", "fn", "min_cooldown", "pl", "(n, pipes, src):"],
    ["pl", "    g = collections.defaultdict(", "ty", "list", "pl", ")"],
    ["kw", "    for", "pl", " a, b ", "kw", "in", "pl", " pipes:"],
    ["pl", "        g[a].append(b)"],
    fixed
      ? ["pl", "        g[b].append(a)", "cm", "   # reach both ways"]
      : ["cm", "        # g[b].append(a)   <- pipes are two-way!"],
    ["blank"],
    ["pl", "    dist = {src: ", "num", "0", "pl", "}"],
    ["pl", "    q = collections.deque([src])"],
    ["kw", "    while", "pl", " q:"],
    ["pl", "        u = q.popleft()"],
    ["kw", "        for", "pl", " v ", "kw", "in", "pl", " g[u]:"],
    ["kw", "            if", "pl", " v ", "kw", "not in", "pl", " dist:"],
    ["pl", "                dist[v] = dist[u] + ", "num", "1"],
    ["pl", "                q.append(v)"],
    ["blank"],
    ["kw", "    if", "pl", " len(dist) < n:"],
    ["kw", "        return", "pl", " -", "num", "1"],
    ["kw", "    return", "pl", " max(dist.values())"],
  ];
  return { lines: C, bugLine: 6 };
};

// ── Problem statement, rendered as lightweight markdown blocks ───────────
window.COMPETE_PROBLEM = {
  title: "Coolant Cascade",
  difficulty: 3,
  tags: ["graphs", "bfs", "shortest-path"],
  accept: "41.2%",
  blocks: [
    { t: "p", c: "A fusion reactor has <b>n</b> coolant nodes numbered <code>0 … n-1</code>, joined by two-way <b>pipes</b>. When you flush coolant into the source node <code>s</code>, it spreads to every directly-connected node in exactly <b>one second</b>, then onward from there." },
    { t: "p", c: "Return the minimum number of seconds until <b>every</b> node holds coolant. If some node can never be reached, return <code>-1</code>." },
    { t: "math", c: "answer = max over v of  dist(s, v)" },
    { t: "h", c: "Input" },
    { t: "ul", c: [
      "<code>n</code> — the number of nodes  ·  <code>1 ≤ n ≤ 10⁵</code>",
      "<code>pipes</code> — list of <code>[a, b]</code> undirected edges  ·  <code>0 ≤ pipes.length ≤ 2·10⁵</code>",
      "<code>src</code> — the node coolant is flushed into",
    ] },
    { t: "h", c: "Function" },
    { t: "code", c: "def min_cooldown(n: int,\n                 pipes: list[list[int]],\n                 src: int) -> int:" },
    { t: "h", c: "Notes" },
    { t: "ul", c: [
      "Pipes are <b>two-way</b> — coolant flows in either direction.",
      "There may be more than one pipe between two nodes; treat extras as no-ops.",
      "The graph is not guaranteed to be connected.",
    ] },
  ],
};

// ── Examples ──────────────────────────────────────────────────────────────
// ex1 passes in both modes; ex2 only passes once `fixed` (needs reverse edge).
window.COMPETE_EXAMPLES = [
  {
    id: 1,
    input: "n = 4\npipes = [[0,1],[1,2],[2,3]]\nsrc  = 0",
    expected: "3",
    note: "A straight chain. Coolant walks 0→1→2→3.",
    got: () => "3",
    pass: () => true,
  },
  {
    id: 2,
    input: "n = 4\npipes = [[0,1],[0,2],[3,1],[3,2]]\nsrc  = 0",
    expected: "2",
    note: "A diamond. Node 3 is only reachable by flowing back up a pipe.",
    got: (fixed) => (fixed ? "2" : "-1"),
    pass: (fixed) => fixed,
  },
];

// ── Submit: public tests ──────────────────────────────────────────────────
window.COMPETE_PUBLIC = [
  { id: 1, label: "single node",        input: "n=1  pipes=[]  src=0",                 expected: "0",  got: () => "0",  needsFix: false },
  { id: 2, label: "chain of 5",         input: "n=5  pipes=[[0,1],[1,2]…]  src=0",     expected: "4",  got: () => "4",  needsFix: false },
  { id: 3, label: "diamond (two-way)",  input: "n=4  pipes=[[0,1],[0,2]…]  src=0",     expected: "2",  got: (f) => (f ? "2" : "-1"), needsFix: true },
  { id: 4, label: "disconnected node",  input: "n=3  pipes=[[0,1]]  src=0",            expected: "-1", got: () => "-1", needsFix: false },
];

// Hidden test outcome by mode: buggy stalls at 32/50, fixed clears 50/50.
window.COMPETE_HIDDEN = { total: 50, failAt: 32 };

window.COMPETE_RUNTIME = { ms: 847, faster: 63 };
