/* global React, D, DIcon */
// LEFT COLUMN — code editor toolbar, the editor itself (read-only, syntax-lit
// to match the IDE's CodeMirror view), and the collapsible console strip.
const { useState: useStateE, useRef: useRefE, useEffect: useEffectE } = React;

const COL = {
  kw: D.cyan, str: "#9be7c0", cm: D.txtFaint, num: D.warn,
  fn: "#7adfe6", ty: D.accent, pl: D.txt, blank: D.txt,
};
window.SUBMIT_BLUE = "#5b9df0";
window.SUBMIT_BLUE_SOFT = "rgba(91,157,240,0.16)";
window.SUBMIT_BLUE_LINE = "rgba(91,157,240,0.5)";

function renderTokens(row) {
  if (row[0] === "blank") return "\u00a0";
  const out = [];
  for (let j = 0; j < row.length; j += 2) {
    out.push(<span key={j} style={{ color: COL[row[j]] || D.txt }}>{row[j + 1]}</span>);
  }
  return out;
}

function CodeEditor({ codeData, flashLine }) {
  const { lines, bugLine } = codeData;
  return (
    <div style={{
      flex: 1, minHeight: 0, display: "flex", background: D.editorBg,
      fontFamily: D.fontMono, fontSize: 13.5, lineHeight: 1.85, overflow: "auto",
    }}>
      {/* gutter */}
      <div style={{
        padding: "12px 0", textAlign: "right", color: D.txtFaint, userSelect: "none",
        background: "rgba(0,0,0,0.14)", minWidth: 46, flex: "none", fontSize: 12.5,
      }}>
        {lines.map((_, i) => (
          <div key={i} style={{ padding: "0 14px", opacity: i === flashLine ? 1 : 0.7 }}>{i + 1}</div>
        ))}
      </div>
      {/* code */}
      <div style={{ padding: "12px 18px", flex: 1, position: "relative" }}>
        {lines.map((row, i) => (
          <div key={i} style={{
            minHeight: "1.85em", whiteSpace: "pre",
            background: i === flashLine ? "rgba(126,211,164,0.16)" : "transparent",
            margin: "0 -18px", padding: "0 18px",
            transition: "background 1.2s ease",
          }}>
            {renderTokens(row)}
            {i === lines.length - 1 && (
              <span style={{
                display: "inline-block", width: 8, height: "1.05em", marginLeft: 1,
                background: D.cyanBright, verticalAlign: "text-bottom", borderRadius: 1,
                animation: "pi3caret 1.1s step-end infinite",
              }} />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function EditorToolbar({ onRun, onSubmit, running, submitting }) {
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 10, padding: "10px 14px",
      borderBottom: `1px solid ${D.border}`, background: D.surface, flex: "none",
    }}>
      {/* language badge */}
      <div style={{
        display: "inline-flex", alignItems: "center", gap: 7, padding: "5px 11px",
        borderRadius: D.rPill, background: D.cyanSoft, border: `1px solid ${D.cyanLine}`,
      }}>
        <span style={{ width: 8, height: 8, borderRadius: 2, background: D.cyan }} />
        <span style={{ fontFamily: D.fontMono, fontSize: 12, fontWeight: 600, color: D.cyan, letterSpacing: 0.3 }}>Python 3</span>
      </div>
      <span style={{ fontFamily: D.fontMono, fontSize: 12, color: D.txtFaint }}>solution.py</span>

      <div style={{ flex: 1 }} />

      <button onClick={onRun} disabled={running} style={{
        all: "unset", boxSizing: "border-box", cursor: running ? "default" : "pointer",
        display: "inline-flex", alignItems: "center", gap: 7, padding: "9px 16px",
        borderRadius: D.rBtn, background: running ? "rgba(126,211,164,0.35)" : D.run,
        color: D.runTxt, fontFamily: D.fontUI, fontSize: 13, fontWeight: 700,
      }}>
        <svg width="13" height="13" viewBox="0 0 16 16"><path d="M5 3.5l7 4.5-7 4.5z" fill="currentColor" /></svg>
        {running ? "Running…" : "Run"}
      </button>

      <button onClick={onSubmit} disabled={submitting} style={{
        all: "unset", boxSizing: "border-box", cursor: submitting ? "default" : "pointer",
        display: "inline-flex", alignItems: "center", gap: 8, padding: "10px 22px",
        borderRadius: D.rBtn, background: window.SUBMIT_BLUE, color: "#04121f",
        fontFamily: D.fontUI, fontSize: 13.5, fontWeight: 800, letterSpacing: 0.2,
        boxShadow: `0 0 0 1px ${window.SUBMIT_BLUE_LINE}, 0 6px 18px -6px ${window.SUBMIT_BLUE}`,
      }}>
        <svg width="14" height="14" viewBox="0 0 16 16"><path d="M3 8l3.5 3.5L13 4.5" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>
        {submitting ? "Submitting…" : "Submit"}
      </button>
    </div>
  );
}

function ConsoleStrip({ lines, collapsed, onToggle, running, onClear }) {
  const bodyRef = useRefE(null);
  useEffectE(() => {
    if (bodyRef.current) bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
  }, [lines]);
  return (
    <div style={{
      flex: "none", background: D.console, borderTop: `1px solid ${D.border}`,
      height: collapsed ? 34 : 132, display: "flex", flexDirection: "column",
      transition: "height 0.18s ease",
    }}>
      {/* header */}
      <div style={{ height: 34, padding: "0 14px", display: "flex", alignItems: "center", gap: 12, flex: "none", borderBottom: collapsed ? "none" : `1px solid ${D.border}` }}>
        <button onClick={onToggle} style={{
          all: "unset", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 8,
          fontFamily: D.fontUI, fontWeight: 700, color: D.txt, fontSize: 11.5, letterSpacing: 0.6, textTransform: "uppercase",
        }}>
          <span style={{ display: "inline-flex", transform: collapsed ? "rotate(-90deg)" : "none", transition: "transform 0.15s", color: D.txtMute }}>
            <DIcon name="chev" size={13} />
          </span>
          Console
        </button>
        <span style={{
          padding: "2px 8px", borderRadius: D.rPill, fontFamily: D.fontUI, fontSize: 10, fontWeight: 700,
          letterSpacing: 0.6, textTransform: "uppercase",
          background: running ? D.okSoft : D.chip, color: running ? D.ok : D.txtMute,
        }}>{running ? "Running" : "Idle"}</span>
        <div style={{ flex: 1 }} />
        {running && (
          <span style={{ display: "inline-flex", gap: 4 }}>
            {[0, 0.2, 0.4].map((d, i) => (
              <span key={i} style={{ width: 6, height: 6, borderRadius: 6, background: D.cyan, animation: `pi3blink 1s ease-in-out ${d}s infinite` }} />
            ))}
          </span>
        )}
        <button onClick={onClear} style={{ all: "unset", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 5, fontFamily: D.fontUI, fontSize: 11.5, color: D.txtMute }}>
          <DIcon name="trash" size={12} /> Clear
        </button>
      </div>
      {/* body */}
      {!collapsed && (
        <div ref={bodyRef} style={{ flex: 1, overflow: "auto", padding: "8px 14px", fontFamily: D.fontMono, fontSize: 12.5, lineHeight: 1.6 }}>
          {lines.length === 0 && <div style={{ color: D.txtFaint }}>{"\u203a"} print() output appears here.</div>}
          {lines.map((l, i) => (
            <div key={i} style={{ color: l.kind === "err" ? D.danger : l.kind === "info" ? D.cyan : D.txt, whiteSpace: "pre-wrap" }}>{l.text}</div>
          ))}
        </div>
      )}
    </div>
  );
}

window.CompeteLeft = function CompeteLeft(props) {
  return (
    <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", background: D.editorBg, borderRight: `1px solid ${D.border}` }}>
      <EditorToolbar onRun={props.onRun} onSubmit={props.onSubmit} running={props.running} submitting={props.submitting} />
      <CodeEditor codeData={props.codeData} flashLine={props.flashLine} />
      <ConsoleStrip lines={props.consoleLines} collapsed={props.consoleCollapsed} onToggle={props.onToggleConsole} running={props.running} onClear={props.onClearConsole} />
    </div>
  );
};
