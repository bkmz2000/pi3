/* global React, D, DIcon */
// RIGHT COLUMN · PROBLEM TAB — title/difficulty/tags, the rendered statement,
// the Examples cards, and the Submit Results area (public + hidden + runtime).
const { useRef: useRefP } = React;

function Difficulty({ level }) {
  const label = ["", "Easy", "Easy+", "Medium", "Hard", "Expert"][level];
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
      <span style={{ display: "inline-flex", gap: 4 }}>
        {[1, 2, 3, 4, 5].map((i) => (
          <span key={i} style={{
            width: 9, height: 9, borderRadius: 9,
            background: i <= level ? D.warn : "transparent",
            boxShadow: `inset 0 0 0 ${i <= level ? 0 : 1.4}px ${i <= level ? "transparent" : D.borderStrong}`,
          }} />
        ))}
      </span>
      <span style={{ fontFamily: D.fontUI, fontSize: 12, fontWeight: 600, color: D.warn }}>{label}</span>
    </span>
  );
}

function ProblemHeader({ p }) {
  return (
    <div style={{ padding: "20px 24px 16px", borderBottom: `1px solid ${D.border}`, flex: "none" }}>
      <div style={{ display: "flex", alignItems: "baseline", gap: 14, flexWrap: "wrap" }}>
        <h1 style={{ margin: 0, fontFamily: D.fontUI, fontSize: 26, fontWeight: 800, color: D.txt, letterSpacing: -0.4 }}>{p.title}</h1>
        <Difficulty level={p.difficulty} />
        <div style={{ flex: 1 }} />
        <span style={{ fontFamily: D.fontMono, fontSize: 11.5, color: D.txtFaint }}>accepted {p.accept}</span>
      </div>
      <div style={{ display: "flex", gap: 7, marginTop: 13 }}>
        {p.tags.map((t) => (
          <span key={t} style={{
            fontFamily: D.fontMono, fontSize: 11.5, fontWeight: 500, color: D.txtMute,
            padding: "3px 10px", borderRadius: D.rPill, background: D.chip, border: `1px solid ${D.border}`,
          }}>{t}</span>
        ))}
      </div>
    </div>
  );
}

function StatementBlock({ b }) {
  if (b.t === "p") return <p className="prose" style={{ margin: "0 0 13px", color: D.txtMute, fontSize: 14, lineHeight: 1.62 }} dangerouslySetInnerHTML={{ __html: b.c }} />;
  if (b.t === "h") return <div style={{ fontFamily: D.fontUI, fontSize: 12.5, fontWeight: 700, color: D.txt, textTransform: "uppercase", letterSpacing: 0.7, margin: "20px 0 9px" }}>{b.c}</div>;
  if (b.t === "math") return (
    <div style={{
      margin: "4px 0 16px", padding: "13px 18px", borderRadius: D.rCard,
      background: "rgba(0,0,0,0.18)", border: `1px solid ${D.border}`,
      fontFamily: "Georgia, 'Times New Roman', serif", fontStyle: "italic",
      fontSize: 16, color: D.cyan, textAlign: "center", letterSpacing: 0.3,
    }}>{b.c}</div>
  );
  if (b.t === "code") return (
    <pre style={{
      margin: "4px 0 14px", padding: "13px 16px", borderRadius: D.rCard, overflow: "auto",
      background: D.appBg, border: `1px solid ${D.border}`, fontFamily: D.fontMono,
      fontSize: 12.5, lineHeight: 1.6, color: "#9be7c0",
    }}>{b.c}</pre>
  );
  if (b.t === "ul") return (
    <ul className="prose" style={{ margin: "0 0 14px", paddingLeft: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 7 }}>
      {b.c.map((li, i) => (
        <li key={i} style={{ position: "relative", paddingLeft: 18, color: D.txtMute, fontSize: 13.5, lineHeight: 1.55 }}>
          <span style={{ position: "absolute", left: 2, top: 8, width: 5, height: 5, borderRadius: 5, background: D.cyanLine }} />
          <span dangerouslySetInnerHTML={{ __html: li }} />
        </li>
      ))}
    </ul>
  );
  return null;
}

function IOBlock({ label, value, tone }) {
  return (
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ fontFamily: D.fontUI, fontSize: 10.5, fontWeight: 700, letterSpacing: 0.7, textTransform: "uppercase", color: D.txtFaint, marginBottom: 5 }}>{label}</div>
      <pre style={{
        margin: 0, padding: "9px 12px", borderRadius: 8, background: D.appBg,
        border: `1px solid ${tone || D.border}`, fontFamily: D.fontMono, fontSize: 12.5,
        lineHeight: 1.5, color: D.txt, whiteSpace: "pre-wrap", overflow: "auto",
      }}>{value}</pre>
    </div>
  );
}

function ExampleCard({ ex, fixed, run, onRun }) {
  // run: null | { pass, got }
  const passed = run && run.pass;
  const failed = run && !run.pass;
  return (
    <div style={{
      borderRadius: D.rCard, border: `1px solid ${failed ? D.dangerSoft : passed ? D.okSoft : D.border}`,
      background: D.surface, padding: 14, marginBottom: 12,
      boxShadow: failed ? `inset 0 0 0 1px rgba(255,139,139,0.25)` : passed ? `inset 0 0 0 1px rgba(126,224,168,0.22)` : "none",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 11 }}>
        <span style={{ fontFamily: D.fontUI, fontSize: 13, fontWeight: 700, color: D.txt }}>Example {ex.id}</span>
        {passed && <StatusChip kind="pass" text="Passed" />}
        {failed && <StatusChip kind="fail" text="Failed" />}
        <div style={{ flex: 1 }} />
        <button onClick={onRun} style={{
          all: "unset", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 6,
          padding: "6px 12px", borderRadius: D.rBtn, background: D.chip, border: `1px solid ${D.border}`,
          color: D.txt, fontFamily: D.fontUI, fontSize: 12, fontWeight: 600,
        }}>
          <svg width="11" height="11" viewBox="0 0 16 16"><path d="M5 3.5l7 4.5-7 4.5z" fill={D.run} /></svg>
          Run this
        </button>
      </div>
      <div style={{ display: "flex", gap: 12 }}>
        <IOBlock label="Input" value={ex.input} />
        <IOBlock label="Expected" value={ex.expected} tone={passed ? D.okSoft : undefined} />
      </div>
      {failed && (
        <div style={{ marginTop: 11, padding: "10px 12px", borderRadius: 8, background: D.dangerSoft, border: `1px solid rgba(255,139,139,0.3)` }}>
          <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 7, fontFamily: D.fontUI, fontSize: 11.5, fontWeight: 700, color: D.danger }}>
            <DIcon name="warn" size={13} /> Output mismatch
          </div>
          <div style={{ display: "flex", gap: 16, fontFamily: D.fontMono, fontSize: 12.5 }}>
            <div><span style={{ color: D.txtFaint }}>expected </span><span style={{ color: D.ok }}>{ex.expected}</span></div>
            <div><span style={{ color: D.txtFaint }}>your output </span><span style={{ color: D.danger, textDecoration: "line-through", textDecorationColor: "rgba(255,139,139,0.5)" }}>{run.got}</span></div>
          </div>
          <div style={{ marginTop: 7, fontFamily: D.fontUI, fontSize: 12, color: D.txtMute, lineHeight: 1.5 }}>{ex.note}</div>
        </div>
      )}
      {passed && <div style={{ marginTop: 9, fontFamily: D.fontUI, fontSize: 11.5, color: D.txtFaint }}>{ex.note}</div>}
    </div>
  );
}

function StatusChip({ kind, text }) {
  const pass = kind === "pass";
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5, padding: "2px 9px 2px 6px", borderRadius: D.rPill,
      background: pass ? D.okSoft : D.dangerSoft, color: pass ? D.ok : D.danger,
      fontFamily: D.fontUI, fontSize: 11, fontWeight: 700,
    }}>
      <svg width="13" height="13" viewBox="0 0 16 16">
        {pass
          ? <path d="M3.5 8.5l3 3 6-6.5" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
          : <path d="M4.5 4.5l7 7M11.5 4.5l-7 7" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" />}
      </svg>
      {text}
    </span>
  );
}

// ── Submit results ────────────────────────────────────────────────────────
function PublicRow({ test, fixed, open, onToggle }) {
  const pass = !(test.needsFix && !fixed);
  const got = test.got(fixed);
  return (
    <div style={{ borderRadius: 9, border: `1px solid ${pass ? D.border : "rgba(255,139,139,0.3)"}`, background: pass ? "transparent" : D.dangerSoft, marginBottom: 6, overflow: "hidden" }}>
      <button onClick={!pass ? onToggle : undefined} style={{
        all: "unset", width: "100%", boxSizing: "border-box", cursor: pass ? "default" : "pointer",
        display: "flex", alignItems: "center", gap: 10, padding: "9px 12px",
      }}>
        <span style={{
          width: 18, height: 18, borderRadius: 18, flex: "none", display: "inline-flex", alignItems: "center", justifyContent: "center",
          background: pass ? D.okSoft : D.dangerSoft, color: pass ? D.ok : D.danger,
        }}>
          <svg width="12" height="12" viewBox="0 0 16 16">
            {pass ? <path d="M3.5 8.5l3 3 6-6.5" stroke="currentColor" strokeWidth="2.2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
              : <path d="M4.5 4.5l7 7M11.5 4.5l-7 7" stroke="currentColor" strokeWidth="2.2" fill="none" strokeLinecap="round" />}
          </svg>
        </span>
        <span style={{ fontFamily: D.fontMono, fontSize: 12.5, color: D.txt }}>test {test.id}</span>
        <span style={{ fontFamily: D.fontUI, fontSize: 12, color: D.txtFaint }}>{test.label}</span>
        <div style={{ flex: 1 }} />
        {pass
          ? <span style={{ fontFamily: D.fontUI, fontSize: 11, fontWeight: 600, color: D.ok }}>passed</span>
          : <span style={{ display: "inline-flex", alignItems: "center", gap: 5, fontFamily: D.fontUI, fontSize: 11, fontWeight: 600, color: D.danger }}>
              diff <span style={{ display: "inline-flex", transform: open ? "rotate(180deg)" : "none", transition: "transform 0.15s" }}><DIcon name="chev" size={12} /></span>
            </span>}
      </button>
      {!pass && open && (
        <div style={{ padding: "0 12px 11px 40px", display: "flex", gap: 18, fontFamily: D.fontMono, fontSize: 12 }}>
          <div><span style={{ color: D.txtFaint }}>in </span><span style={{ color: D.txtMute }}>{test.input}</span></div>
          <div><span style={{ color: D.txtFaint }}>want </span><span style={{ color: D.ok }}>{test.expected}</span></div>
          <div><span style={{ color: D.txtFaint }}>got </span><span style={{ color: D.danger }}>{got}</span></div>
        </div>
      )}
    </div>
  );
}

function HiddenTests({ fixed, progress }) {
  const total = window.COMPETE_HIDDEN.total;
  const failAt = window.COMPETE_HIDDEN.failAt;
  const passedCount = fixed ? progress : Math.min(progress, failAt);
  const cells = [];
  for (let i = 0; i < total; i++) {
    let c = "rgba(255,255,255,0.07)";
    if (i < passedCount) c = D.ok;
    else if (!fixed && i === failAt && progress > failAt) c = D.danger;
    cells.push(c);
  }
  const filled = fixed ? progress : Math.min(progress, failAt);
  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 9 }}>
        <span style={{ fontFamily: D.fontUI, fontSize: 12.5, fontWeight: 700, color: D.txt }}>Hidden tests</span>
        <span style={{ fontFamily: D.fontMono, fontSize: 12, color: fixed ? D.ok : D.danger, fontWeight: 600 }}>{filled} / {total}</span>
        <div style={{ flex: 1 }} />
        <DIcon name="lock" size={13} color={D.txtFaint} />
        <span style={{ fontFamily: D.fontUI, fontSize: 11, color: D.txtFaint }}>inputs hidden</span>
      </div>
      {/* bar */}
      <div style={{ height: 9, borderRadius: 9, background: "rgba(0,0,0,0.28)", overflow: "hidden", marginBottom: 10 }}>
        <div style={{ width: `${(filled / total) * 100}%`, height: "100%", background: fixed ? D.ok : D.danger, transition: "width 0.18s linear", borderRadius: 9 }} />
      </div>
      {/* dots */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(25, 1fr)", gap: 4 }}>
        {cells.map((c, i) => <span key={i} style={{ height: 7, borderRadius: 2, background: c, transition: "background 0.1s" }} />)}
      </div>
    </div>
  );
}

function Histogram() {
  const ms = window.COMPETE_RUNTIME.ms, faster = window.COMPETE_RUNTIME.faster;
  const N = 28, userBar = Math.round(N * (1 - faster / 100)); // faster than 63% → left-ish
  const bars = [];
  for (let i = 0; i < N; i++) {
    const x = (i - N * 0.46) / (N * 0.2);
    const h = Math.exp(-0.5 * x * x);
    bars.push(h);
  }
  return (
    <div style={{ marginTop: 12, padding: "13px 16px", borderRadius: D.rCard, background: "rgba(0,0,0,0.18)", border: `1px solid ${D.border}` }}>
      <div style={{ display: "flex", alignItems: "baseline", gap: 9, marginBottom: 11 }}>
        <svg width="15" height="15" viewBox="0 0 16 16" style={{ color: D.warn }}><path d="M9 1.5L3 9h4l-1 5.5L13 6H8.5z" fill="currentColor" /></svg>
        <span style={{ fontFamily: D.fontMono, fontSize: 16, fontWeight: 700, color: D.txt }}>{ms} ms</span>
        <span style={{ fontFamily: D.fontUI, fontSize: 12.5, color: D.txtMute }}>faster than <b style={{ color: D.ok }}>{faster}%</b> of accepted solutions</span>
      </div>
      <div style={{ display: "flex", alignItems: "flex-end", gap: 3, height: 52, position: "relative" }}>
        {bars.map((h, i) => (
          <div key={i} style={{
            flex: 1, height: `${Math.max(6, h * 100)}%`, borderRadius: "2px 2px 0 0",
            background: i === userBar ? D.warn : "rgba(120,210,220,0.22)",
          }} />
        ))}
        {/* marker line */}
        <div style={{ position: "absolute", left: `${(userBar / N) * 100 + 1.5}%`, top: -4, bottom: 0, width: 2, background: D.warn, borderRadius: 2 }} />
        <div style={{ position: "absolute", left: `${(userBar / N) * 100 + 1.5}%`, top: -16, transform: "translateX(-50%)", fontFamily: D.fontMono, fontSize: 10, fontWeight: 700, color: D.warn, whiteSpace: "nowrap" }}>you</div>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 6, fontFamily: D.fontMono, fontSize: 10, color: D.txtFaint }}>
        <span>0 ms</span><span>slower →</span><span>3000 ms</span>
      </div>
    </div>
  );
}

function SubmitResults({ fixed, submitState, hiddenProgress, openDiffs, onToggleDiff, onFix }) {
  const accepted = submitState === "accepted";
  const running = submitState === "running";
  const verdict = accepted ? { label: "Accepted", color: D.ok, soft: D.okSoft } : { label: "Wrong Answer", color: D.danger, soft: D.dangerSoft };
  return (
    <div style={{ marginTop: 8 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
        <span style={{
          display: "inline-flex", alignItems: "center", gap: 8, padding: "7px 15px", borderRadius: D.rPill,
          background: running ? D.chip : verdict.soft, color: running ? D.txtMute : verdict.color,
          fontFamily: D.fontUI, fontSize: 14, fontWeight: 800, boxShadow: running ? "none" : `inset 0 0 0 1px ${verdict.color}44`,
        }}>
          {running ? <span style={{ display: "inline-flex", gap: 3 }}>{[0, 0.15, 0.3].map((d, i) => <span key={i} style={{ width: 6, height: 6, borderRadius: 6, background: D.cyan, animation: `pi3blink 1s ease-in-out ${d}s infinite` }} />)}</span>
            : <svg width="15" height="15" viewBox="0 0 16 16">{accepted ? <path d="M3.5 8.5l3 3 6-6.5" stroke="currentColor" strokeWidth="2.2" fill="none" strokeLinecap="round" strokeLinejoin="round" /> : <path d="M4.5 4.5l7 7M11.5 4.5l-7 7" stroke="currentColor" strokeWidth="2.2" fill="none" strokeLinecap="round" />}</svg>}
          {running ? "Judging…" : verdict.label}
        </span>
        {!running && !accepted && <span style={{ fontFamily: D.fontUI, fontSize: 12.5, color: D.txtMute }}>failed on hidden test {window.COMPETE_HIDDEN.failAt + 1}</span>}
        {accepted && <span style={{ fontFamily: D.fontUI, fontSize: 12.5, color: D.txtMute }}>all {window.COMPETE_PUBLIC.length + window.COMPETE_HIDDEN.total} tests cleared</span>}
      </div>

      {/* public tests */}
      <div style={{ fontFamily: D.fontUI, fontSize: 12.5, fontWeight: 700, color: D.txt, marginBottom: 9, display: "flex", gap: 9, alignItems: "center" }}>
        Public tests <span style={{ fontFamily: D.fontMono, fontSize: 11.5, color: D.txtFaint, fontWeight: 500 }}>{window.COMPETE_PUBLIC.filter(t => !(t.needsFix && !fixed)).length}/{window.COMPETE_PUBLIC.length}</span>
      </div>
      {window.COMPETE_PUBLIC.map((t) => (
        <PublicRow key={t.id} test={t} fixed={fixed} open={!!openDiffs[t.id]} onToggle={() => onToggleDiff(t.id)} />
      ))}

      {/* hidden tests */}
      <div style={{ marginTop: 18 }}>
        <HiddenTests fixed={fixed} progress={hiddenProgress} />
      </div>

      {/* runtime only on accept */}
      {accepted && <Histogram />}

      {/* fix CTA on WA */}
      {!running && !accepted && (
        <button onClick={onFix} style={{
          all: "unset", cursor: "pointer", marginTop: 16, display: "flex", alignItems: "center", gap: 9,
          padding: "11px 16px", borderRadius: D.rCard, width: "100%", boxSizing: "border-box",
          background: D.warnSoft, border: `1px solid rgba(251,191,119,0.35)`,
        }}>
          <span style={{ fontSize: 15 }}>💡</span>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: D.fontUI, fontSize: 12.5, fontWeight: 700, color: D.warn }}>Pipes are two-way — but line 7 is commented out.</div>
            <div style={{ fontFamily: D.fontUI, fontSize: 11.5, color: D.txtMute, marginTop: 1 }}>Uncomment <code style={{ fontFamily: D.fontMono }}>g[b].append(a)</code> and resubmit.</div>
          </div>
          <span style={{ fontFamily: D.fontUI, fontSize: 12, fontWeight: 700, color: D.warn, display: "inline-flex", alignItems: "center", gap: 5 }}>Apply fix <DIcon name="arrow" size={13} /></span>
        </button>
      )}
    </div>
  );
}

window.CompeteProblem = function CompeteProblem(props) {
  const p = window.COMPETE_PROBLEM;
  return (
    <div style={{ flex: 1, minHeight: 0, overflow: "auto" }}>
      <ProblemHeader p={p} />
      <div style={{ padding: "18px 24px 28px" }}>
        {p.blocks.map((b, i) => <StatementBlock key={i} b={b} />)}

        {/* Examples */}
        <div style={{ fontFamily: D.fontUI, fontSize: 12.5, fontWeight: 700, color: D.txt, textTransform: "uppercase", letterSpacing: 0.7, margin: "26px 0 12px" }}>Examples</div>
        {window.COMPETE_EXAMPLES.map((ex) => (
          <ExampleCard key={ex.id} ex={ex} fixed={props.fixed} run={props.exampleRuns[ex.id]} onRun={() => props.onRunExample(ex.id)} />
        ))}

        {/* Submit results */}
        {props.submitState !== "idle" && (
          <div style={{ marginTop: 24, paddingTop: 22, borderTop: `1px solid ${D.border}` }}>
            <SubmitResults
              fixed={props.fixed}
              submitState={props.submitState}
              hiddenProgress={props.hiddenProgress}
              openDiffs={props.openDiffs}
              onToggleDiff={props.onToggleDiff}
              onFix={props.onFix}
            />
          </div>
        )}
      </div>
    </div>
  );
};
