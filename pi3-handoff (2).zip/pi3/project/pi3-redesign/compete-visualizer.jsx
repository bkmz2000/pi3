/* global React, D, Konva */
// RIGHT COLUMN · VISUALIZER TAB — a Konva stage running a BFS over the
// problem's pipe graph, scrubbable frame-by-frame via the playback bar.
const { useRef: useRefV, useEffect: useEffectV } = React;

// ── Graph (matches the "Coolant Cascade" mental model) ───────────────────
const VIZ_NODES = [
  { id: 0, x: 0.09, y: 0.50 },
  { id: 1, x: 0.29, y: 0.20 }, { id: 2, x: 0.29, y: 0.50 }, { id: 3, x: 0.29, y: 0.80 },
  { id: 4, x: 0.51, y: 0.11 }, { id: 5, x: 0.51, y: 0.37 }, { id: 6, x: 0.51, y: 0.63 }, { id: 7, x: 0.51, y: 0.89 },
  { id: 8, x: 0.73, y: 0.28 }, { id: 9, x: 0.73, y: 0.66 },
  { id: 10, x: 0.92, y: 0.47 },
];
const VIZ_EDGES = [
  [0, 1], [0, 2], [0, 3],
  [1, 4], [1, 5], [2, 5], [2, 6], [3, 6], [3, 7],
  [5, 8], [6, 9], [7, 9],
  [8, 10], [9, 10],
  [4, 5], [6, 7],
];
const VIZ_TOTAL = 847;

// BFS from node 0 → discovery order, distance, and the parent edge used.
function buildBfs() {
  const adj = {};
  VIZ_NODES.forEach((n) => (adj[n.id] = []));
  VIZ_EDGES.forEach(([a, b]) => { adj[a].push(b); adj[b].push(a); });
  const dist = { 0: 0 }, parent = { 0: null }, order = [0];
  const q = [0];
  while (q.length) {
    const u = q.shift();
    for (const v of adj[u].sort((a, b) => a - b)) {
      if (!(v in dist)) { dist[v] = dist[u] + 1; parent[v] = u; order.push(v); q.push(v); }
    }
  }
  // assign each node a fractional reveal time by discovery order
  const tNode = {};
  order.forEach((id, i) => { tNode[id] = 0.06 + (i / (order.length - 1)) * 0.9; });
  return { dist, parent, order, tNode };
}
const BFS = buildBfs();

function VizCanvas({ frame }) {
  const wrapRef = useRefV(null);
  const stageRef = useRefV(null);
  const shapesRef = useRefV({ nodes: {}, labels: {}, edges: {}, dims: { w: 0, h: 0 } });

  // Build / rebuild the stage on size changes.
  useEffectV(() => {
    const wrap = wrapRef.current;
    if (!wrap || typeof Konva === "undefined") return;

    function build() {
      const w = wrap.clientWidth, h = wrap.clientHeight;
      if (w < 40 || h < 40) return false;
      if (stageRef.current) stageRef.current.destroy();
      const stage = new Konva.Stage({ container: wrap, width: w, height: h });
      const layer = new Konva.Layer();
      stage.add(layer);
      const px = (n) => 24 + n.x * (w - 48);
      const py = (n) => 22 + n.y * (h - 44);
      const nodeById = Object.fromEntries(VIZ_NODES.map((n) => [n.id, n]));

      const edges = {};
      VIZ_EDGES.forEach(([a, b], i) => {
        const line = new Konva.Line({
          points: [px(nodeById[a]), py(nodeById[a]), px(nodeById[b]), py(nodeById[b])],
          stroke: "rgba(148,210,216,0.12)", strokeWidth: 2,
        });
        layer.add(line);
        edges[i] = line;
      });

      const nodes = {}, labels = {};
      VIZ_NODES.forEach((n) => {
        const c = new Konva.Circle({
          x: px(n), y: py(n), radius: 17, fill: "rgba(12,46,52,0.9)",
          stroke: "rgba(148,210,216,0.3)", strokeWidth: 1.6,
        });
        const tx = new Konva.Text({
          x: px(n) - 17, y: py(n) - 8, width: 34, align: "center",
          text: String(n.id), fontFamily: "'JetBrains Mono', monospace",
          fontSize: 14, fontStyle: "700", fill: "#9bb3b8",
        });
        const dl = new Konva.Text({
          x: px(n) - 30, y: py(n) + 19, width: 60, align: "center",
          text: "", fontFamily: "'JetBrains Mono', monospace", fontSize: 11, fill: D.cyan,
        });
        layer.add(c); layer.add(tx); layer.add(dl);
        nodes[n.id] = c; labels[n.id] = { txt: tx, dist: dl };
      });

      shapesRef.current = { nodes, labels, edges, dims: { w, h }, layer };
      drawFrame(frameRef.current);
      layer.draw();
      stageRef.current = stage;
      return true;
    }

    // Poll with rAF until the container is actually laid out (the tab may be
    // display:none at mount), build once, then let ResizeObserver handle
    // subsequent size changes. ResizeObserver alone doesn't reliably fire on
    // the display:none -> visible transition in every host.
    let rafId = 0, ro = null;
    function poll() {
      if (build()) {
        ro = new ResizeObserver(() => build());
        ro.observe(wrap);
      } else {
        rafId = requestAnimationFrame(poll);
      }
    }
    poll();
    return () => {
      if (rafId) cancelAnimationFrame(rafId);
      if (ro) ro.disconnect();
      if (stageRef.current) { stageRef.current.destroy(); stageRef.current = null; }
    };
  }, []);

  // keep latest frame for rebuilds
  const frameRef = useRefV(frame);
  useEffectV(() => { frameRef.current = frame; drawFrame(frame); }, [frame]);

  function drawFrame(f) {
    const S = shapesRef.current;
    if (!S.layer) return;
    const p = f / VIZ_TOTAL;
    // current node = most recently reached
    let current = null, bestT = -1;
    VIZ_NODES.forEach((n) => {
      const t = BFS.tNode[n.id];
      if (p >= t && t > bestT) { bestT = t; current = n.id; }
    });
    VIZ_NODES.forEach((n) => {
      const reached = p >= BFS.tNode[n.id];
      const isSrc = n.id === 0;
      const isCur = n.id === current && !isSrc;
      const c = S.nodes[n.id];
      const fill = isSrc ? D.accent : reached ? (isCur ? D.cyanBright : "rgba(34,211,238,0.22)") : "rgba(12,46,52,0.9)";
      c.fill(fill);
      c.stroke(isSrc ? D.accentDeep : reached ? D.cyan : "rgba(148,210,216,0.3)");
      c.strokeWidth(isCur || isSrc ? 2.4 : 1.6);
      c.radius(isCur ? 20 : 17);
      c.shadowColor(isCur ? D.cyanBright : isSrc ? D.accent : "transparent");
      c.shadowBlur(isCur ? 22 : isSrc ? 14 : 0);
      const lab = S.labels[n.id];
      lab.txt.fill(isSrc ? "#062a26" : reached ? "#04121f" : "#9bb3b8");
      lab.txt.fontSize(isCur ? 15 : 14);
      lab.dist.text(reached ? `${BFS.dist[n.id]}s` : "");
    });
    VIZ_EDGES.forEach(([a, b], i) => {
      const used = (BFS.parent[b] === a || BFS.parent[a] === b);
      const childReached = p >= Math.max(BFS.tNode[a], BFS.tNode[b]);
      const line = S.edges[i];
      if (used && childReached) { line.stroke("rgba(34,211,238,0.55)"); line.strokeWidth(2.6); }
      else if (childReached) { line.stroke("rgba(148,210,216,0.22)"); line.strokeWidth(2); }
      else { line.stroke("rgba(148,210,216,0.12)"); line.strokeWidth(2); }
    });
    S.layer.batchDraw();
  }

  return (
    <div style={{ flex: 1, minHeight: 0, position: "relative", background: D.appBg }}>
      <div ref={wrapRef} style={{ position: "absolute", inset: 0 }} />
      {/* legend */}
      <div style={{ position: "absolute", left: 16, top: 14, display: "flex", gap: 16, pointerEvents: "none" }}>
        {[["source", D.accent], ["frontier", D.cyanBright], ["visited", "rgba(34,211,238,0.5)"], ["unreached", "rgba(148,210,216,0.3)"]].map(([t, c]) => (
          <span key={t} style={{ display: "inline-flex", alignItems: "center", gap: 6, fontFamily: D.fontUI, fontSize: 11, color: D.txtMute }}>
            <span style={{ width: 9, height: 9, borderRadius: 9, background: c }} /> {t}
          </span>
        ))}
      </div>
      <div style={{ position: "absolute", right: 16, top: 13, fontFamily: D.fontMono, fontSize: 11.5, color: D.txtFaint, pointerEvents: "none" }}>
        bfs(src=0) · min_cooldown
      </div>
    </div>
  );
}

// ── Playback bar ──────────────────────────────────────────────────────────
function PBtn({ children, onClick, big, title }) {
  return (
    <button title={title} onClick={onClick} style={{
      all: "unset", cursor: "pointer", display: "inline-flex", alignItems: "center", justifyContent: "center",
      width: big ? 40 : 32, height: big ? 40 : 32, borderRadius: big ? D.rPill : D.rBtn,
      background: big ? D.cyan : D.chip, color: big ? "#04121f" : D.txt,
      border: big ? "none" : `1px solid ${D.border}`,
    }}>{children}</button>
  );
}

function PlaybackBar({ frame, setFrame, playing, setPlaying, speed, setSpeed }) {
  return (
    <div style={{ flex: "none", borderTop: `1px solid ${D.border}`, background: D.surface, padding: "12px 18px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        {/* transport */}
        <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
          <PBtn title="Rewind to start" onClick={() => { setPlaying(false); setFrame(0); }}>
            <svg width="15" height="15" viewBox="0 0 16 16" fill="currentColor"><path d="M4 3h1.6v10H4zM14 3.5v9l-7-4.5z" /></svg>
          </PBtn>
          <PBtn title="Step back" onClick={() => { setPlaying(false); setFrame(Math.max(0, frame - 1)); }}>
            <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor"><path d="M11 3.5v9L4 8z" /></svg>
          </PBtn>
          <PBtn big title={playing ? "Pause" : "Play"} onClick={() => setPlaying(!playing)}>
            {playing
              ? <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><rect x="4" y="3.5" width="3" height="9" rx="1" /><rect x="9" y="3.5" width="3" height="9" rx="1" /></svg>
              : <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><path d="M5 3.5l8 4.5-8 4.5z" /></svg>}
          </PBtn>
          <PBtn title="Step forward" onClick={() => { setPlaying(false); setFrame(Math.min(VIZ_TOTAL, frame + 1)); }}>
            <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor"><path d="M5 3.5v9l7-4.5z" /></svg>
          </PBtn>
        </div>

        {/* speed */}
        <div style={{ display: "flex", alignItems: "center", gap: 4, padding: 3, borderRadius: D.rPill, background: D.appBg, border: `1px solid ${D.border}` }}>
          {[0.5, 1, 2, 5].map((s) => (
            <button key={s} onClick={() => setSpeed(s)} style={{
              all: "unset", cursor: "pointer", padding: "4px 10px", borderRadius: D.rPill,
              fontFamily: D.fontMono, fontSize: 11.5, fontWeight: 700,
              background: speed === s ? D.cyan : "transparent", color: speed === s ? "#04121f" : D.txtMute,
            }}>{s}×</button>
          ))}
        </div>

        {/* scrubber */}
        <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 12, minWidth: 0 }}>
          <input type="range" min={0} max={VIZ_TOTAL} value={frame}
            onChange={(e) => { setPlaying(false); setFrame(Number(e.target.value)); }}
            className="viz-scrub" style={{ flex: 1, minWidth: 0 }} />
          <span style={{ fontFamily: D.fontMono, fontSize: 12.5, color: D.txt, whiteSpace: "nowrap" }}>
            Frame <b style={{ color: D.cyan }}>{frame}</b> <span style={{ color: D.txtFaint }}>/ {VIZ_TOTAL}</span>
          </span>
        </div>
      </div>
    </div>
  );
}

window.CompeteVisualizer = function CompeteVisualizer(props) {
  const { frame, setFrame, playing, setPlaying, speed, setSpeed } = props;

  // playback loop
  useEffectV(() => {
    if (!playing) return;
    let raf, last = performance.now();
    const tick = (now) => {
      const dt = (now - last) / 1000; last = now;
      setFrame((f) => {
        const nf = f + dt * 70 * speed;
        if (nf >= VIZ_TOTAL) { setPlaying(false); return VIZ_TOTAL; }
        return nf;
      });
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing, speed]);

  const intFrame = Math.round(frame);
  return (
    <div style={{ flex: 1, minHeight: 0, display: "flex", flexDirection: "column" }}>
      <VizCanvas frame={intFrame} />
      <PlaybackBar frame={intFrame} setFrame={setFrame} playing={playing} setPlaying={setPlaying} speed={speed} setSpeed={setSpeed} />
    </div>
  );
};
