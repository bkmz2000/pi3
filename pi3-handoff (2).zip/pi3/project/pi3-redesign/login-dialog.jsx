/* global React, T, Pi3Logo, Avatar, RoleTag, Icon */

// ─────────────────────────────────────────────────────────────────────────────
// 1. LOGIN DIALOG — clean, role-first, friendly
// ─────────────────────────────────────────────────────────────────────────────
function LoginDialog({ initialMode = "signin", initialRole = "student" }) {
  const [mode, setMode] = React.useState(initialMode);
  const [role, setRole] = React.useState(initialRole);
  const [name, setName] = React.useState(mode === "signin" ? "ada.lovelace" : "");
  const [password, setPassword] = React.useState(mode === "signin" ? "••••••••" : "");
  const isSignUp = mode === "signup";

  const inputStyle = {
    all: "unset",
    display: "block",
    width: "100%",
    boxSizing: "border-box",
    padding: "11px 14px",
    background: T.surface,
    border: `1px solid ${T.border}`,
    borderRadius: T.rInput,
    fontFamily: T.fontUI,
    fontSize: 14,
    color: T.txt,
  };

  return (
    <div style={{
      width: 420,
      background: T.panel,
      borderRadius: 14,
      boxShadow: T.shadowDialog,
      fontFamily: T.fontUI,
      color: T.txt,
      overflow: "hidden",
      border: `1px solid ${T.border}`,
    }}>
      {/* Header band — brand + close */}
      <div style={{
        padding: "22px 24px 18px",
        background: "linear-gradient(180deg, #fdf3e1 0%, #fffaf0 100%)",
        borderBottom: `1px solid ${T.border}`,
        position: "relative",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <Pi3Logo size={24} />
          <div style={{
            height: 18, width: 1, background: T.border,
          }} />
          <span style={{ fontSize: 13, color: T.txtMute, fontWeight: 500 }}>
            {isSignUp ? "Create your account" : "Welcome back"}
          </span>
        </div>
        <div style={{ marginTop: 10, fontSize: 19, fontWeight: 700, letterSpacing: -0.2 }}>
          {isSignUp ? "Join your class" : "Sign in to keep coding"}
        </div>
        <button style={{
          all: "unset", cursor: "pointer", position: "absolute",
          top: 16, right: 16, width: 30, height: 30, borderRadius: 8,
          display: "inline-flex", alignItems: "center", justifyContent: "center",
          color: T.txtMute, background: "transparent",
        }}>
          <Icon name="close" size={14} />
        </button>
      </div>

      {/* Mode tabs — visible, not buried */}
      <div style={{
        display: "grid", gridTemplateColumns: "1fr 1fr",
        padding: "12px 14px 0",
        gap: 4,
      }}>
        {[
          { id: "signin", label: "Sign in" },
          { id: "signup", label: "Sign up" },
        ].map(m => (
          <button
            key={m.id}
            onClick={() => setMode(m.id)}
            style={{
              all: "unset", cursor: "pointer", textAlign: "center",
              padding: "10px 0", fontSize: 13, fontWeight: 600,
              color: mode === m.id ? T.tealDeep : T.txtMute,
              borderBottom: `2px solid ${mode === m.id ? T.teal : "transparent"}`,
              transition: "all 0.15s",
            }}
          >{m.label}</button>
        ))}
      </div>

      {/* Form */}
      <div style={{ padding: "22px 24px 24px", display: "flex", flexDirection: "column", gap: 16 }}>
        {/* Role chooser, only for signup, big and friendly */}
        {isSignUp && (
          <div>
            <div style={{ fontSize: 12, fontWeight: 600, color: T.txtMute, marginBottom: 8 }}>
              I&apos;m a…
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              {[
                { id: "student", title: "Student", sub: "Code & learn", color: T.student, soft: T.studentSoft, line: T.studentLine },
                { id: "teacher", title: "Teacher", sub: "Run a class",  color: T.teacher, soft: T.teacherSoft, line: T.teacherLine },
              ].map(r => {
                const on = role === r.id;
                return (
                  <button
                    key={r.id}
                    onClick={() => setRole(r.id)}
                    style={{
                      all: "unset", cursor: "pointer",
                      padding: "12px 14px",
                      borderRadius: T.rInput,
                      border: `1.5px solid ${on ? r.line : T.border}`,
                      background: on ? r.soft : T.surface,
                      position: "relative",
                    }}
                  >
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <span style={{
                        width: 28, height: 28, borderRadius: T.rPill,
                        background: r.color, color: "#fff",
                        display: "inline-flex", alignItems: "center", justifyContent: "center",
                      }}>
                        <Icon name={r.id === "teacher" ? "spark" : "folder"} size={14} color="#fff" />
                      </span>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 13.5, fontWeight: 700, color: T.txt }}>{r.title}</div>
                        <div style={{ fontSize: 11.5, color: T.txtMute, marginTop: 1 }}>{r.sub}</div>
                      </div>
                      {on && (
                        <span style={{
                          width: 18, height: 18, borderRadius: T.rPill,
                          background: r.color, color: "#fff",
                          display: "inline-flex", alignItems: "center", justifyContent: "center",
                        }}>
                          <Icon name="check" size={10} color="#fff" />
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        <div>
          <label style={{
            display: "block", fontSize: 12, fontWeight: 600,
            color: T.txtMute, marginBottom: 6,
          }}>Username</label>
          <input value={name} onChange={e => setName(e.target.value)} style={inputStyle} />
        </div>

        <div>
          <div style={{
            display: "flex", justifyContent: "space-between", alignItems: "baseline",
            marginBottom: 6,
          }}>
            <label style={{ fontSize: 12, fontWeight: 600, color: T.txtMute }}>Password</label>
            {!isSignUp && (
              <a href="#" style={{
                fontSize: 11.5, color: T.teal, textDecoration: "none", fontWeight: 600,
              }}>Forgot?</a>
            )}
          </div>
          <input type="password" value={password} onChange={e => setPassword(e.target.value)} style={inputStyle} />
          {isSignUp && (
            <div style={{ fontSize: 11, color: T.txtFaint, marginTop: 6 }}>
              4+ characters. Make it something you&apos;ll remember.
            </div>
          )}
        </div>

        <button style={{
          all: "unset", cursor: "pointer",
          marginTop: 4,
          padding: "12px 16px",
          borderRadius: T.rInput,
          background: T.tealDeep,
          color: "#fffaf0",
          fontSize: 14, fontWeight: 700,
          textAlign: "center",
          boxShadow: "0 1px 0 rgba(255,255,255,0.15) inset, 0 2px 6px rgba(10,61,68,0.25)",
        }}>
          {isSignUp ? `Create ${role} account` : "Sign in"}
        </button>

        <div style={{
          textAlign: "center",
          fontSize: 12, color: T.txtMute,
        }}>
          {isSignUp ? (
            <>Already have an account?{" "}
              <a onClick={() => setMode("signin")} style={{ color: T.teal, fontWeight: 600, textDecoration: "none", cursor: "pointer" }}>Sign in</a>
            </>
          ) : (
            <>New to pi<sup>3</sup>?{" "}
              <a onClick={() => setMode("signup")} style={{ color: T.teal, fontWeight: 600, textDecoration: "none", cursor: "pointer" }}>Create an account</a>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

window.LoginDialog = LoginDialog;
