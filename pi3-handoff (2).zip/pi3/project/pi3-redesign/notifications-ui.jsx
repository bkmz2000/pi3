/* global React, T, Avatar, Icon */

// ─────────────────────────────────────────────────────────────────────────────
// IN-EDITOR NOTIFICATIONS
// ─────────────────────────────────────────────────────────────────────────────

// ── Toast types ───────────────────────────────────────────────────────────────
// teacher_helping  — student sees "Ms. Hopper is looking at your code"
// comment_new      — "Ms. Hopper commented on line 18"
// help_resolved    — "Ms. Hopper marked your request resolved"
// comment_reply    — teacher sees "Ada replied to your comment on line 18"
// hand_up          — teacher sees "Linus raised their hand (Pong rebuild)"

const TOASTS = [
  {
    id: "t1", type: "teacher_helping",
    actor: "Ms. Hopper", role: "teacher",
    body: "is looking at your code",
    sub: "Pong rebuild · main.py",
    action: "View",
    tone: "teal",
  },
  {
    id: "t2", type: "comment_new",
    actor: "Ms. Hopper", role: "teacher",
    body: "left a comment on",
    highlight: "line 18",
    sub: "Have you tried using self.rect…",
    action: "Jump to",
    tone: "teal",
  },
  {
    id: "t3", type: "help_resolved",
    actor: "Ms. Hopper", role: "teacher",
    body: "resolved your help request",
    sub: "Pong rebuild",
    action: null,
    tone: "ok",
  },
  {
    id: "t4", type: "hand_up",
    actor: "Linus T.", role: "student",
    body: "raised their hand",
    highlight: "Pong rebuild",
    sub: "AttributeError · line 24",
    action: "Help now",
    tone: "hand",
  },
  {
    id: "t5", type: "comment_reply",
    actor: "Ada L.", role: "student",
    body: "replied to your comment on",
    highlight: "line 18",
    sub: "Oh I see — I was calling move()…",
    action: "View",
    tone: "student",
  },
];

const TONE_MAP = {
  teal:    { bg: T.teacherSoft,  line: T.teacherLine, accent: T.teal,    txt: T.tealDeep },
  ok:      { bg: T.okSoft,       line: "rgba(14,124,82,0.25)", accent: T.ok, txt: T.ok },
  hand:    { bg: T.handSoft,     line: "rgba(217,122,43,0.35)", accent: T.hand, txt: T.hand },
  student: { bg: T.studentSoft,  line: T.studentLine, accent: T.student, txt: "#7a3a10" },
};

// ── Single toast ─────────────────────────────────────────────────────────────
function Toast({ t, index = 0, stacked = false }) {
  const tone = TONE_MAP[t.tone];
  return (
    <div style={{
      width: 320,
      background: T.panel,
      border: `1px solid ${tone.line}`,
      borderRadius: 12,
      boxShadow: T.shadowPop,
      overflow: "hidden",
      fontFamily: T.fontUI,
      transform: stacked ? `translateY(${index * -6}px) scale(${1 - index * 0.03})` : "none",
      opacity: stacked ? 1 - index * 0.3 : 1,
      transition: "all 0.2s",
    }}>
      {/* Accent top line */}
      <div style={{ height: 3, background: tone.accent }} />

      <div style={{ padding: "12px 14px 14px" }}>
        {/* Actor row */}
        <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
          <Avatar name={t.actor} role={t.role} size={30} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 13.5, color: T.txt, lineHeight: 1.4 }}>
              <strong style={{ fontWeight: 700 }}>{t.actor}</strong>
              {" "}{t.body}
              {t.highlight && (
                <>
                  {" "}
                  <span style={{
                    fontFamily: T.fontMono, fontSize: 12,
                    background: tone.bg,
                    color: tone.txt,
                    padding: "1px 6px", borderRadius: 4,
                    fontWeight: 700,
                  }}>{t.highlight}</span>
                </>
              )}
            </div>
            {t.sub && (
              <div style={{
                fontSize: 11.5, color: T.txtMute, marginTop: 4,
                overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
                fontStyle: t.type === "comment_new" || t.type === "comment_reply" ? "italic" : "normal",
              }}>
                {t.type === "comment_new" || t.type === "comment_reply"
                  ? `"${t.sub}"`
                  : t.sub}
              </div>
            )}
          </div>
          <button style={{
            all: "unset", cursor: "pointer",
            width: 22, height: 22, borderRadius: 5,
            display: "inline-flex", alignItems: "center", justifyContent: "center",
            color: T.txtFaint, flex: "none",
          }}>
            <Icon name="close" size={10} />
          </button>
        </div>

        {/* Action row */}
        {t.action && (
          <div style={{ marginTop: 10, display: "flex", gap: 6 }}>
            <button style={{
              all: "unset", cursor: "pointer",
              padding: "5px 12px", borderRadius: 6,
              background: tone.accent, color: "#fff",
              fontSize: 12, fontWeight: 700,
            }}>{t.action}</button>
            <button style={{
              all: "unset", cursor: "pointer",
              padding: "5px 10px", borderRadius: 6,
              background: T.surface, border: `1px solid ${T.border}`,
              color: T.txtMute, fontSize: 12, fontWeight: 500,
            }}>Dismiss</button>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Toast stack — as it appears in the corner ─────────────────────────────────
function ToastStack({ toasts = TOASTS.slice(0, 2) }) {
  return (
    <div style={{ position: "relative" }}>
      {[...toasts].reverse().map((t, i) => (
        <div key={t.id} style={{
          position: i === 0 ? "relative" : "absolute",
          top: 0, right: 0,
          zIndex: toasts.length - i,
          transform: `translateY(${(toasts.length - 1 - i) * 6}px) scale(${1 - (toasts.length - 1 - i) * 0.03})`,
          transformOrigin: "bottom center",
          opacity: 1 - (toasts.length - 1 - i) * 0.28,
          pointerEvents: i === 0 ? "none" : "auto",
        }}>
          <Toast t={t} />
        </div>
      ))}
    </div>
  );
}

// ── Status bar pill (persistent, low-noise) ───────────────────────────────────
function StatusPillBar() {
  const pills = [
    // Teacher helping — teal pulsing dot
    {
      id: "helping", label: "Ms. Hopper is with you",
      color: T.teal, soft: T.tealSoft, pulse: true,
      extra: null,
    },
    // Unread comment — badge
    {
      id: "comment", label: "1 new comment",
      color: T.teal, soft: T.tealSoft, pulse: false,
      extra: "L18",
    },
    // Hands up (teacher view)
    {
      id: "hand", label: "3 hands up",
      color: T.hand, soft: T.handSoft, pulse: true,
      extra: null,
    },
  ];

  return (
    <div style={{
      display: "flex", flexDirection: "column", gap: 18,
      fontFamily: T.fontUI,
    }}>
      <div style={{
        fontSize: 10.5, fontWeight: 700, color: T.txtMute,
        letterSpacing: 0.6, textTransform: "uppercase", marginBottom: -8,
      }}>Status bar pills — always visible, low noise</div>

      {/* Status bar context */}
      {pills.map(p => (
        <div key={p.id} style={{
          background: T.panel, border: `1px solid ${T.border}`,
          borderRadius: T.rCard,
          overflow: "hidden",
        }}>
          {/* Mock status bar */}
          <div style={{
            height: 36, background: "#0e9aa7",
            display: "flex", alignItems: "center",
            padding: "0 12px", gap: 8,
          }}>
            <span style={{ fontFamily: T.fontMono, fontSize: 11, color: "rgba(255,255,255,0.6)" }}>main.py</span>
            <span style={{ fontFamily: T.fontMono, fontSize: 11, color: "rgba(255,255,255,0.4)" }}>Ln 18, Col 24</span>
            <div style={{ flex: 1 }} />
            {/* ← This is the new pill */}
            <div style={{
              display: "inline-flex", alignItems: "center", gap: 6,
              padding: "3px 10px 3px 8px", borderRadius: T.rPill,
              background: p.soft,
              color: p.color === T.hand ? T.hand : T.tealDeep,
            }}>
              <span style={{
                width: 7, height: 7, borderRadius: T.rPill,
                background: p.color,
                boxShadow: p.pulse ? `0 0 0 3px rgba(${p.color === T.hand ? "217,122,43" : "14,154,167"},0.3)` : "none",
              }} />
              <span style={{ fontSize: 11.5, fontWeight: 700 }}>{p.label}</span>
              {p.extra && (
                <span style={{
                  fontFamily: T.fontMono, fontSize: 10.5,
                  padding: "0 5px", borderRadius: 3,
                  background: "rgba(255,255,255,0.5)",
                  color: T.tealDeep,
                }}>{p.extra}</span>
              )}
            </div>
          </div>
          {/* Caption */}
          <div style={{ padding: "8px 12px", fontSize: 11, color: T.txtMute, fontStyle: "italic" }}>
            {p.id === "helping" && "Student sees teacher presence non-intrusively in the file bar"}
            {p.id === "comment" && "New unread comment — jumps to line on click"}
            {p.id === "hand" && "Teacher sees count without leaving the editor"}
          </div>
        </div>
      ))}
    </div>
  );
}

// ── All toasts catalog ────────────────────────────────────────────────────────
function ToastCatalog() {
  return (
    <div style={{ padding: 32, background: "#e9e3d3", width: "100%", height: "100%", overflow: "auto" }}>
      <div style={{
        display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24,
        maxWidth: 720,
      }}>
        {/* Left col: student toasts */}
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <div style={{ fontFamily: T.fontUI, fontSize: 10.5, fontWeight: 700, color: T.txtMute, letterSpacing: 0.6, textTransform: "uppercase", marginBottom: 4 }}>Student receives</div>
          {TOASTS.filter(t => ["teacher_helping", "comment_new", "help_resolved"].includes(t.type)).map(t => (
            <Toast key={t.id} t={t} />
          ))}
        </div>
        {/* Right col: teacher toasts */}
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <div style={{ fontFamily: T.fontUI, fontSize: 10.5, fontWeight: 700, color: T.txtMute, letterSpacing: 0.6, textTransform: "uppercase", marginBottom: 4 }}>Teacher receives</div>
          {TOASTS.filter(t => ["hand_up", "comment_reply"].includes(t.type)).map(t => (
            <Toast key={t.id} t={t} />
          ))}
          <div style={{ height: 20 }} />
          {/* Stack preview */}
          <div style={{ fontFamily: T.fontUI, fontSize: 10.5, fontWeight: 700, color: T.txtMute, letterSpacing: 0.6, textTransform: "uppercase", marginBottom: 8 }}>Multiple queued → stack</div>
          <ToastStack toasts={[TOASTS[3], TOASTS[4]]} />
        </div>
      </div>
    </div>
  );
}

// ── In-editor placement mock ──────────────────────────────────────────────────
function InEditorPlacement() {
  return (
    <div style={{
      width: "100%", height: "100%",
      background: "#fffaf0",
      fontFamily: T.fontUI,
      display: "flex", flexDirection: "column",
      position: "relative",
    }}>
      {/* Fake file bar */}
      <div style={{
        height: 36, flex: "none",
        display: "flex", alignItems: "center",
        background: "#0e9aa7",
        padding: "0 14px", gap: 2,
      }}>
        <div style={{
          padding: "5px 14px",
          background: "#fffaf0", borderRadius: "4px 4px 0 0",
          color: "#0a3d44", fontFamily: T.fontMono, fontSize: 12, fontWeight: 600,
        }}>main.py</div>
        <div style={{ flex: 1 }} />
        {/* Status pill */}
        <div style={{
          display: "inline-flex", alignItems: "center", gap: 6,
          padding: "3px 10px 3px 8px", borderRadius: T.rPill,
          background: T.tealSoft, marginRight: 8,
        }}>
          <span style={{
            width: 7, height: 7, borderRadius: T.rPill,
            background: T.teal,
            boxShadow: `0 0 0 3px ${T.tealSoft}`,
          }} />
          <span style={{ fontSize: 11.5, fontWeight: 700, color: T.tealDeep }}>Ms. Hopper is with you</span>
        </div>
        <span style={{ fontFamily: T.fontMono, fontSize: 11, color: "rgba(255,255,255,0.5)", marginRight: 4 }}>Ln 18</span>
      </div>

      {/* Fake editor lines */}
      <div style={{ flex: 1, padding: "0 0 0 52px", overflow: "hidden", position: "relative" }}>
        {CODE_LINES.slice(0, 10).map((l, i) => (
          <div key={l.n} style={{
            height: "1.65em",
            display: "flex", alignItems: "center",
            background: l.comment === "open" ? "rgba(14,154,167,0.06)" : "transparent",
          }}>
            <code style={{ fontSize: 13, fontFamily: T.fontMono, whiteSpace: "pre", color: T.txt, opacity: 0.85 }}>
              {l.text}
            </code>
            {l.comment === "open" && (
              <span style={{
                marginLeft: "1.5em",
                display: "inline-flex", alignItems: "center", gap: 5,
                padding: "1px 8px", borderRadius: 3,
                background: T.tealSoft, color: T.tealDeep,
                fontFamily: T.fontUI, fontSize: 11, fontWeight: 600,
                whiteSpace: "nowrap",
              }}>
                <Icon name="users" size={10} color={T.teal} />
                3 comments
              </span>
            )}
          </div>
        ))}

        {/* Toast — bottom right */}
        <div style={{
          position: "absolute", bottom: 16, right: 16,
          display: "flex", flexDirection: "column", gap: 8,
          alignItems: "flex-end",
        }}>
          <Toast t={TOASTS[1]} />
        </div>
      </div>
    </div>
  );
}

window.ToastCatalog = ToastCatalog;
window.StatusPillBar = StatusPillBar;
window.InEditorPlacement = InEditorPlacement;
window.Toast = Toast;
