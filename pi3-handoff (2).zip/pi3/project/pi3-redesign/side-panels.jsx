/* global React, T, Avatar, RoleTag, Icon, Pi3Logo */

// ─────────────────────────────────────────────────────────────────────────────
// SIDE PANEL PROPOSALS
// A — "This project" scoped panel
// B — "Class" live classroom context
// ─────────────────────────────────────────────────────────────────────────────

// ── Shared: Rail + IDE shell ──────────────────────────────────────────────────

function RailBtn({ icon, active, badge }) {
  return (
    <div style={{
      width: 44, height: 44, borderRadius: 6,
      display: "flex", alignItems: "center", justifyContent: "center",
      background: active ? "rgba(255,255,255,0.20)" : "transparent",
      color: active ? "#fff" : "rgba(255,255,255,0.6)",
      cursor: "pointer", position: "relative", flex: "none",
    }}>
      <Icon name={icon} size={20} color="currentColor" />
      {badge && (
        <span style={{
          position: "absolute", top: 6, right: 6,
          width: 8, height: 8, borderRadius: T.rPill,
          background: T.hand, border: "2px solid #0e9aa7",
        }} />
      )}
    </div>
  );
}

function IDEShell({ panelContent, activeRailIcon }) {
  const railIcons = [
    { icon: "folder",  label: "project" },
    { icon: "spark",   label: "run"     },
    { icon: "sparkle", label: "assets"  },
    { icon: "users",   label: "class"   },
    { icon: "book",    label: "docs"    },
    { icon: "settings",label: "settings"},
  ];

  return (
    <div style={{
      width: "100%", height: "100%",
      display: "flex", background: "#fffaf0",
      borderRadius: T.rCard, overflow: "hidden",
      fontFamily: T.fontUI,
      boxShadow: T.shadowCard,
    }}>
      {/* Rail */}
      <div style={{
        width: 56, flex: "none",
        background: "#0e9aa7",
        display: "flex", flexDirection: "column",
        alignItems: "center", padding: "14px 0",
        gap: 4,
      }}>
        <div style={{ marginBottom: 10 }}>
          <Pi3Logo size={22} color="#fffaf0" />
        </div>
        {railIcons.slice(0, 3).map(r => (
          <RailBtn key={r.icon} icon={r.icon} active={r.label === activeRailIcon} />
        ))}
        <div style={{ flex: 1 }} />
        <RailBtn icon="users" active={activeRailIcon === "class"} badge={activeRailIcon !== "class"} />
        <RailBtn icon="book" />
        <RailBtn icon="settings" />
      </div>

      {/* Sliding panel */}
      <div style={{
        width: 300, flex: "none",
        background: T.panel,
        borderRight: `1px solid ${T.border}`,
        display: "flex", flexDirection: "column",
        overflow: "hidden",
      }}>
        {panelContent}
      </div>

      {/* Editor stub */}
      <div style={{ flex: 1, background: "#fffaf0", overflow: "hidden", position: "relative" }}>
        <div style={{
          height: 36, background: "#0e9aa7",
          display: "flex", alignItems: "center", padding: "0 12px", gap: 2,
        }}>
          {["main.py", "utils.py"].map((f, i) => (
            <div key={f} style={{
              padding: "5px 12px", borderRadius: "4px 4px 0 0",
              background: i === 0 ? "#fffaf0" : "rgba(255,255,255,0.25)",
              color: i === 0 ? "#0a3d44" : "rgba(255,255,255,0.8)",
              fontFamily: T.fontMono, fontSize: 11.5, fontWeight: 600,
            }}>{f}</div>
          ))}
        </div>
        <div style={{ padding: "10px 16px", opacity: 0.35 }}>
          {[
            "class Paddle:",
            "    def __init__(self, x, y):",
            "        self.x = x",
            "        self.y = y",
            "        self.dy = 0",
            "",
            "    def update(self):",
            "        self.y += self.dy",
            "        self.draw()",
          ].map((l, i) => (
            <div key={i} style={{
              fontFamily: T.fontMono, fontSize: 11.5,
              color: T.txt, lineHeight: "1.65",
              whiteSpace: "pre",
            }}>{l || " "}</div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PROPOSAL A — "This project" panel (v2)
// Cover thumbnail · README · Files · Milestones · Community toggle
// ─────────────────────────────────────────────────────────────────────────────

const FILES = [
  { name: "main.py",  dirty: true,  active: true  },
  { name: "utils.py", dirty: false, active: false },
  { name: "assets/",  dirty: false, active: false, isDir: true },
];

// Fake milestone history
const MILESTONES = [
  { id: "m3", label: "Collision works!",      time: "10 min ago",   isCurrent: true  },
  { id: "m2", label: "Paddles moving",        time: "yesterday",    isCurrent: false },
  { id: "m1", label: "Blank canvas, first run", time: "2 days ago", isCurrent: false },
];

function FileRow({ f }) {
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 9,
      padding: "6px 10px",
      background: f.active ? T.tealSoft : "transparent",
      borderRadius: 6, cursor: "pointer",
    }}>
      <Icon name="folder" size={12} color={f.active ? T.teal : T.txtFaint} />
      <span style={{
        flex: 1, fontSize: 12.5, fontWeight: f.active ? 700 : 500,
        color: f.active ? T.tealDeep : T.txt,
        fontFamily: T.fontMono,
      }}>{f.name}</span>
      {f.dirty && (
        <span style={{ width: 6, height: 6, borderRadius: T.rPill, background: T.warn, flex: "none" }} />
      )}
    </div>
  );
}

// Tiny canvas thumbnail — same fake pong scene
function CoverThumb({ width = 272, height = 80 }) {
  return (
    <div style={{
      width, height,
      background: "#072428",
      borderRadius: 7,
      position: "relative", overflow: "hidden",
      imageRendering: "pixelated",
      flex: "none",
    }}>
      {Array.from({ length: 7 }).map((_, i) => (
        <div key={i} style={{
          position: "absolute",
          left: "50%", top: `${i * 14 + 2}%`,
          width: 2, height: "10%",
          background: "rgba(95,212,220,0.2)",
          transform: "translateX(-50%)",
        }} />
      ))}
      <div style={{ position: "absolute", left: 8, top: "28%", width: 4, height: "44%", background: "#fffaf0" }} />
      <div style={{ position: "absolute", right: 8, top: "44%", width: 4, height: "44%", background: "#fffaf0" }} />
      <div style={{ position: "absolute", left: "60%", top: "38%", width: 5, height: 5, background: "#5fd4dc", borderRadius: 1 }} />
      <div style={{
        position: "absolute", top: 8, left: 0, right: 0,
        display: "flex", justifyContent: "center", gap: 22,
        fontFamily: T.fontMono, fontSize: 14, fontWeight: 700, color: "#fffaf0", opacity: 0.9,
      }}>
        <span>3</span><span>5</span>
      </div>
      {/* "Set as cover" overlay on hover — always show for design purposes */}
      <div style={{
        position: "absolute", inset: 0,
        background: "rgba(7,36,40,0.55)",
        display: "flex", alignItems: "center", justifyContent: "center",
      }}>
        <button style={{
          all: "unset", cursor: "pointer",
          display: "inline-flex", alignItems: "center", gap: 6,
          padding: "5px 12px", borderRadius: T.rPill,
          background: "rgba(255,250,240,0.15)",
          border: "1px solid rgba(255,250,240,0.3)",
          color: "#fffaf0", fontSize: 11.5, fontWeight: 700,
        }}>
          <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <rect x="2" y="4" width="12" height="10" rx="2" />
            <circle cx="8" cy="9.5" r="2.5" />
            <path d="M5.5 4V3.5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1V4" />
          </svg>
          Set as cover
        </button>
      </div>
    </div>
  );
}

// Toggle pill
function Toggle({ on, onToggle, color = T.teal }) {
  return (
    <div onClick={onToggle} style={{
      width: 36, height: 20, borderRadius: T.rPill,
      background: on ? color : T.border,
      position: "relative", cursor: "pointer",
      transition: "background 0.15s", flex: "none",
    }}>
      <div style={{
        position: "absolute", top: 2,
        left: on ? 18 : 2,
        width: 16, height: 16, borderRadius: T.rPill,
        background: "#fff",
        transition: "left 0.15s",
        boxShadow: "0 1px 3px rgba(0,0,0,0.2)",
      }} />
    </div>
  );
}

function ProposalAPanel() {
  const [helpOthers, setHelpOthers]   = React.useState(false);
  const [editingReadme, setEditingReadme] = React.useState(false);
  const [readme, setReadme]           = React.useState("Rebuilt Pong from scratch using Pyxel. Both paddles move, ball bounces. Working on the score counter next.");
  const [showMark, setShowMark]       = React.useState(false);
  const [milestoneMsg, setMilestoneMsg] = React.useState("");

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", overflow: "hidden" }}>

      {/* ── Cover + title ── */}
      <div style={{
        padding: "12px 14px",
        borderBottom: `1px solid ${T.border}`,
        background: T.panelHeader,
        display: "flex", flexDirection: "column", gap: 10,
      }}>
        <CoverThumb />
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ flex: 1, fontSize: 15, fontWeight: 800, color: T.txt, letterSpacing: -0.2 }}>
            Pong rebuild
          </span>
          <span style={{ fontSize: 11, color: T.txtMute, fontFamily: T.fontMono }}>3 files · saved 2m ago</span>
          <button style={{
            all: "unset", cursor: "pointer", width: 24, height: 24, borderRadius: 5,
            display: "flex", alignItems: "center", justifyContent: "center",
            color: T.txtMute, background: T.chip,
          }}>
            <Icon name="dot3" size={12} />
          </button>
        </div>

        {/* README */}
        {editingReadme ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <textarea
              autoFocus
              value={readme}
              onChange={e => setReadme(e.target.value)}
              rows={3}
              style={{
                all: "unset", display: "block", width: "100%", boxSizing: "border-box",
                padding: "8px 10px",
                background: T.surface, border: `1px solid ${T.tealLine}`,
                borderRadius: 7, fontFamily: T.fontUI, fontSize: 12.5,
                color: T.txt, lineHeight: 1.5, resize: "none",
              }}
            />
            <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
              <button onClick={() => setEditingReadme(false)} style={{
                all: "unset", cursor: "pointer",
                padding: "4px 10px", borderRadius: 5,
                background: T.surface, border: `1px solid ${T.border}`,
                fontSize: 11.5, color: T.txtMute, fontWeight: 600,
              }}>Cancel</button>
              <button onClick={() => setEditingReadme(false)} style={{
                all: "unset", cursor: "pointer",
                padding: "4px 10px", borderRadius: 5,
                background: T.tealDeep, color: "#fffaf0",
                fontSize: 11.5, fontWeight: 700,
              }}>Save</button>
            </div>
          </div>
        ) : (
          <div
            onClick={() => setEditingReadme(true)}
            style={{
              fontSize: 12.5, color: readme ? T.txt : T.txtFaint,
              lineHeight: 1.5, cursor: "text",
              padding: "6px 8px", borderRadius: 6,
              background: "transparent",
              border: `1px dashed ${T.border}`,
              fontStyle: readme ? "normal" : "italic",
            }}
          >
            {readme || "Add a README — what does this project do?"}
          </div>
        )}
      </div>

      {/* ── Scroll body ── */}
      <div style={{ flex: 1, overflow: "auto", padding: "10px 10px 12px" }}>

        {/* Files */}
        <div style={{ marginBottom: 14 }}>
          <div style={{
            display: "flex", alignItems: "center", padding: "0 4px 5px",
            fontSize: 10.5, fontWeight: 700, color: T.txtMute,
            letterSpacing: 0.6, textTransform: "uppercase",
          }}>
            <span style={{ flex: 1 }}>Files</span>
            <button style={{
              all: "unset", cursor: "pointer",
              width: 18, height: 18, borderRadius: 4,
              display: "flex", alignItems: "center", justifyContent: "center",
              color: T.txtFaint,
            }}>
              <Icon name="plus" size={11} />
            </button>
          </div>
          {FILES.map(f => <FileRow key={f.name} f={f} />)}
        </div>

        {/* ── Milestone history ── */}
        <div style={{ marginBottom: 14 }}>
          <div style={{
            display: "flex", alignItems: "center", padding: "0 4px 8px",
            fontSize: 10.5, fontWeight: 700, color: T.txtMute,
            letterSpacing: 0.6, textTransform: "uppercase",
          }}>
            <span style={{ flex: 1 }}>Milestones</span>
          </div>

          {/* Timeline */}
          <div style={{ position: "relative", paddingLeft: 22, marginBottom: 8 }}>
            {/* Vertical line */}
            <div style={{
              position: "absolute", left: 7, top: 8, bottom: 8,
              width: 1.5, background: T.border, borderRadius: 1,
            }} />
            {MILESTONES.map((m, i) => (
              <div key={m.id} style={{
                position: "relative", marginBottom: i < MILESTONES.length - 1 ? 10 : 0,
              }}>
                {/* Dot */}
                <div style={{
                  position: "absolute", left: -18, top: 5,
                  width: 10, height: 10, borderRadius: T.rPill,
                  background: m.isCurrent ? T.teal : T.chip,
                  border: `2px solid ${m.isCurrent ? T.teal : T.border}`,
                  boxShadow: m.isCurrent ? `0 0 0 3px ${T.tealSoft}` : "none",
                }} />
                <div style={{
                  padding: "7px 10px",
                  background: m.isCurrent ? T.tealSoft : T.surface,
                  border: `1px solid ${m.isCurrent ? T.tealLine : T.border}`,
                  borderRadius: 7, cursor: "pointer",
                }}>
                  <div style={{
                    display: "flex", alignItems: "center", gap: 6,
                  }}>
                    <span style={{
                      flex: 1, fontSize: 12.5, fontWeight: m.isCurrent ? 700 : 500,
                      color: m.isCurrent ? T.tealDeep : T.txt,
                    }}>{m.label}</span>
                    {m.isCurrent && (
                      <span style={{
                        fontSize: 9.5, fontWeight: 700, padding: "1px 6px",
                        borderRadius: T.rPill, background: T.teal, color: "#fff",
                        textTransform: "uppercase", letterSpacing: 0.3,
                      }}>now</span>
                    )}
                  </div>
                  <div style={{
                    fontSize: 11, color: T.txtMute, marginTop: 2,
                    fontFamily: T.fontMono,
                  }}>{m.time}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Mark milestone CTA */}
          {showMark ? (
            <div style={{ display: "flex", flexDirection: "column", gap: 6, marginTop: 6 }}>
              <input
                autoFocus
                placeholder="What did you just achieve?"
                value={milestoneMsg}
                onChange={e => setMilestoneMsg(e.target.value)}
                style={{
                  all: "unset", display: "block", width: "100%", boxSizing: "border-box",
                  padding: "8px 10px",
                  background: T.surface, border: `1px solid ${T.tealLine}`,
                  borderRadius: 7, fontFamily: T.fontUI, fontSize: 12.5, color: T.txt,
                }}
              />
              <div style={{ display: "flex", gap: 6 }}>
                <button onClick={() => { setShowMark(false); setMilestoneMsg(""); }} style={{
                  all: "unset", cursor: "pointer",
                  flex: 1, padding: "6px 0", borderRadius: 6,
                  background: T.surface, border: `1px solid ${T.border}`,
                  fontSize: 12, color: T.txtMute, fontWeight: 600, textAlign: "center",
                }}>Cancel</button>
                <button onClick={() => { setShowMark(false); setMilestoneMsg(""); }} style={{
                  all: "unset", cursor: "pointer",
                  flex: 1, padding: "6px 0", borderRadius: 6,
                  background: T.tealDeep, color: "#fffaf0",
                  fontSize: 12, fontWeight: 700, textAlign: "center",
                }}>Save snapshot</button>
              </div>
            </div>
          ) : (
            <button onClick={() => setShowMark(true)} style={{
              all: "unset", cursor: "pointer", width: "100%", boxSizing: "border-box",
              padding: "8px 12px", borderRadius: 7, marginTop: 4,
              border: `1.5px dashed ${T.tealLine}`,
              color: T.teal, fontSize: 12.5, fontWeight: 700,
              display: "flex", alignItems: "center", justifyContent: "center", gap: 7,
              background: "transparent",
            }}>
              <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
                <circle cx="8" cy="8" r="5.5" />
                <path d="M8 5.5v5M5.5 8h5" />
              </svg>
              Mark this moment
            </button>
          )}
        </div>

        {/* ── Community / sharing ── */}
        <div>
          <div style={{
            fontSize: 10.5, fontWeight: 700, color: T.txtMute,
            letterSpacing: 0.6, textTransform: "uppercase", padding: "0 4px 8px",
          }}>Class</div>

          {/* Ready to help others */}
          <div style={{
            padding: "12px",
            background: helpOthers ? T.studentSoft : T.surface,
            border: `1px solid ${helpOthers ? T.studentLine : T.border}`,
            borderRadius: T.rCard, marginBottom: 8,
          }}>
            <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: T.txt }}>
                  Ready to help others
                </div>
                <div style={{ fontSize: 11.5, color: T.txtMute, marginTop: 3, lineHeight: 1.4 }}>
                  Classmates can see your project as a reference. Great to turn on when you crack something tricky.
                </div>
              </div>
              <Toggle on={helpOthers} onToggle={() => setHelpOthers(s => !s)} color={T.student} />
            </div>
            {helpOthers && (
              <div style={{
                marginTop: 10, padding: "6px 10px", borderRadius: 6,
                background: T.studentSoft, border: `1px solid ${T.studentLine}`,
                fontSize: 11.5, color: "#7a3a10", display: "flex", alignItems: "center", gap: 7,
              }}>
                <span style={{ width: 7, height: 7, borderRadius: T.rPill, background: T.student, flex: "none" }} />
                Visible to 23 classmates as a reference
              </div>
            )}
          </div>

          {/* Ask for help (separate, complementary) */}
          <button style={{
            all: "unset", cursor: "pointer",
            display: "flex", alignItems: "center", gap: 10,
            width: "100%", boxSizing: "border-box",
            padding: "10px 12px", borderRadius: T.rCard,
            background: T.surface, border: `1px solid ${T.border}`,
          }}>
            <span style={{
              width: 26, height: 26, borderRadius: T.rPill,
              background: T.handSoft, color: T.hand,
              display: "inline-flex", alignItems: "center", justifyContent: "center", flex: "none",
            }}>
              <Icon name="hand" size={13} color={T.hand} />
            </span>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: T.txt }}>Ask for help</div>
              <div style={{ fontSize: 11, color: T.txtMute }}>Raise your hand for Ms. Hopper</div>
            </div>
            <Icon name="arrow" size={12} color={T.txtFaint} />
          </button>
        </div>
      </div>

      {/* Footer */}
      <div style={{ padding: "10px 12px", borderTop: `1px solid ${T.border}`, background: T.panelHeader }}>
        <a href="/projects" style={{
          all: "unset", cursor: "pointer",
          display: "flex", alignItems: "center", gap: 8,
          fontSize: 12.5, color: T.txtMute, fontWeight: 500,
        }}>
          <Icon name="folder" size={13} color={T.txtFaint} />
          All my projects →
        </a>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PROPOSAL B — "Class" live panel
// Replaces the projects drawer with live classroom context.
// Teacher sees class pulse. Student sees teacher + classmates.
// ─────────────────────────────────────────────────────────────────────────────

const CLASSMATES = [
  { name: "Linus T.",      active: "online", help: true,  project: "Pong rebuild"  },
  { name: "Grace H.",      active: "online", help: false, project: "Orbit sim"     },
  { name: "Alan T.",       active: "away",   help: false, project: "Snake game"    },
  { name: "Margaret H.",   active: "online", help: true,  project: "Lunar lander"  },
  { name: "Donald K.",     active: "offline",help: false, project: "Fractal tree"  },
];

const activeDot = (active) => ({
  online: "#34a853", away: T.student, offline: T.txtFaint,
}[active]);

function ClassmateLine({ s }) {
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 9,
      padding: "6px 6px", borderRadius: 6,
      background: s.help ? T.handSoft : "transparent",
    }}>
      <div style={{ position: "relative", flex: "none" }}>
        <Avatar name={s.name} role="student" size={26} />
        <span style={{
          position: "absolute", right: -1, bottom: -1,
          width: 9, height: 9, borderRadius: T.rPill,
          background: activeDot(s.active),
          border: `2px solid ${s.help ? "#fff4ea" : T.panel}`,
        }} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontSize: 12.5, fontWeight: 600, color: T.txt,
          overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
        }}>{s.name}</div>
        <div style={{
          fontSize: 10.5, color: T.txtMute,
          overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
          fontFamily: T.fontMono,
        }}>{s.project}</div>
      </div>
      {s.help && (
        <span style={{
          fontSize: 9.5, fontWeight: 700, padding: "2px 6px",
          borderRadius: T.rPill, background: T.hand, color: "#fff",
          letterSpacing: 0.2, textTransform: "uppercase", flex: "none",
        }}>hand</span>
      )}
    </div>
  );
}

function ProposalBPanel({ role = "student" }) {
  const isTeacher = role === "teacher";
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", overflow: "hidden" }}>
      {/* Header */}
      <div style={{
        padding: "14px 14px 10px",
        borderBottom: `1px solid ${T.border}`,
        background: T.panelHeader,
      }}>
        <div style={{ fontSize: 10.5, fontWeight: 700, color: T.txtMute, letterSpacing: 0.6, textTransform: "uppercase", marginBottom: 4 }}>
          {isTeacher ? "Your class" : "Your class"}
        </div>
        <div style={{ fontSize: 15, fontWeight: 800, color: T.txt, letterSpacing: -0.2, marginBottom: 2 }}>
          Period 4 · Algorithms
        </div>
        <div style={{ fontSize: 11.5, color: T.txtMute }}>
          {isTeacher ? "24 students" : "Ms. Hopper · 24 students"}
        </div>
      </div>

      <div style={{ flex: 1, overflow: "auto", padding: "12px 10px" }}>
        {/* Teacher: class pulse summary */}
        {isTeacher && (
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 10.5, fontWeight: 700, color: T.txtMute, letterSpacing: 0.6, textTransform: "uppercase", padding: "0 4px 8px" }}>
              Class pulse
            </div>
            {[
              { label: "Coding now",  v: 17, total: 24, color: T.ok },
              { label: "Hands up",    v: 2,  total: 24, color: T.hand },
              { label: "Errors",      v: 6,  total: 24, color: T.warn },
            ].map(row => (
              <div key={row.label} style={{ marginBottom: 8 }}>
                <div style={{ display: "flex", alignItems: "center", marginBottom: 3 }}>
                  <span style={{ flex: 1, fontSize: 12, color: T.txt }}>{row.label}</span>
                  <span style={{ fontFamily: T.fontMono, fontSize: 11, color: T.txtMute }}>{row.v}/{row.total}</span>
                </div>
                <div style={{ height: 4, background: T.chip, borderRadius: T.rPill, overflow: "hidden" }}>
                  <div style={{ width: `${(row.v / row.total) * 100}%`, height: "100%", background: row.color, borderRadius: T.rPill }} />
                </div>
              </div>
            ))}
            <button style={{
              all: "unset", cursor: "pointer",
              display: "block", width: "100%", boxSizing: "border-box",
              marginTop: 10, padding: "7px 12px", borderRadius: 7,
              background: T.hand, color: "#fff",
              fontSize: 12.5, fontWeight: 700, textAlign: "center",
            }}>
              2 hands up — help now
            </button>
          </div>
        )}

        {/* Student: teacher status */}
        {!isTeacher && (
          <div style={{ marginBottom: 16 }}>
            <div style={{
              padding: "12px",
              background: T.tealSoft,
              border: `1px solid ${T.tealLine}`,
              borderRadius: T.rCard,
              display: "flex", alignItems: "center", gap: 10,
            }}>
              <Avatar name="Ms. Hopper" role="teacher" size={32} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: T.txt }}>Ms. Hopper</div>
                <div style={{
                  display: "flex", alignItems: "center", gap: 5,
                  fontSize: 11.5, color: T.teal, marginTop: 2,
                }}>
                  <span style={{ width: 6, height: 6, borderRadius: T.rPill, background: T.teal }} />
                  In class · available
                </div>
              </div>
              {/* Ask for help */}
              <button style={{
                all: "unset", cursor: "pointer",
                padding: "5px 10px", borderRadius: 6,
                background: T.hand, color: "#fff",
                fontSize: 11.5, fontWeight: 700,
              }}>Ask</button>
            </div>
          </div>
        )}

        {/* Classmates list */}
        <div>
          <div style={{
            display: "flex", alignItems: "center",
            fontSize: 10.5, fontWeight: 700, color: T.txtMute,
            letterSpacing: 0.6, textTransform: "uppercase",
            padding: "0 4px 6px",
          }}>
            <span style={{ flex: 1 }}>
              {isTeacher ? "Students" : "In class now"}
            </span>
            <span style={{ fontFamily: T.fontMono, fontSize: 10.5, color: T.txtFaint, textTransform: "none", letterSpacing: 0 }}>
              {CLASSMATES.filter(s => s.active === "online").length}/{CLASSMATES.length}
            </span>
          </div>
          {CLASSMATES.map(s => <ClassmateLine key={s.name} s={s} />)}
        </div>
      </div>

      {/* Footer */}
      <div style={{ padding: "10px 12px", borderTop: `1px solid ${T.border}`, background: T.panelHeader }}>
        <a href={isTeacher ? "/teacher" : "/projects"} style={{
          all: "unset", cursor: "pointer",
          display: "flex", alignItems: "center", gap: 8,
          fontSize: 12.5, color: T.txtMute, fontWeight: 500,
        }}>
          <Icon name={isTeacher ? "spark" : "folder"} size={13} color={T.txtFaint} />
          {isTeacher ? "Full dashboard →" : "All my projects →"}
        </a>
      </div>
    </div>
  );
}

// ── Artboard wrappers ─────────────────────────────────────────────────────────

function ProposalA() {
  return (
    <IDEShell
      activeRailIcon="folder"
      panelContent={<ProposalAPanel />}
    />
  );
}

function ProposalBStudent() {
  return (
    <IDEShell
      activeRailIcon="class"
      panelContent={<ProposalBPanel role="student" />}
    />
  );
}

function ProposalBTeacher() {
  return (
    <IDEShell
      activeRailIcon="class"
      panelContent={<ProposalBPanel role="teacher" />}
    />
  );
}

window.ProposalA = ProposalA;
window.ProposalBStudent = ProposalBStudent;
window.ProposalBTeacher = ProposalBTeacher;
