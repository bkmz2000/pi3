// sprite-editor-layouts.jsx
// Infinite canvas: sprite groups as bordered boxes, rows=animations, cells=frames

const { useState } = React;

// ─── Canvas layout constants ──────────────────────────────────────────────────
const CELL     = 56;  // px per frame cell (overview)
const LABEL_W  = 18;  // px for vertical anim label
const HEADER_H = 24;  // px for group title bar
const ADD_W    = 26;  // px for the + add-frame button

// ─── Spatial data: sprite groups on the infinite canvas ──────────────────────
const CANVAS_GROUPS = [
  { spriteId:'hero',     color:'#0e9aa7', left:60,  top:40,
    rows:[
      { animId:'idle', frames:[F0,F1,F2,F3] },
      { animId:'run',  frames:[F2,F3,F0,F1] },
      { animId:'jump', frames:[F1,F2,F3]    },
    ]
  },
  { spriteId:'coin',     color:'#38b764', left:380, top:40,
    rows:[
      { animId:'spin', frames:[F0,F1,F2,F3] },
    ]
  },
  { spriteId:'platform', color:'#ffcd75', left:380, top:152,
    rows:[
      { animId:'idle', frames:[F0,F1] },
    ]
  },
];

// ─── Sidebar section wrapper ──────────────────────────────────────────────────
function SideSection({ children, style = {} }) {
  return (
    <div style={{ padding:'12px 12px 10px', borderBottom:`1px solid ${E.border}`, ...style }}>
      {children}
    </div>
  );
}

// ─── SpriteGroupBox ──────────────────────────────────────────────────────────
// One bordered group on the canvas: title + animation rows + frame cells
function SpriteGroupBox({ group, activeSpriteId, activeAnimId, activeFrame, onSelect }) {
  const isActiveSp  = activeSpriteId === group.spriteId;
  const borderColor = isActiveSp ? group.color : group.color + '60';

  return (
    <div style={{ position:'absolute', left:group.left, top:group.top,
      border:`2px solid ${borderColor}`, borderRadius:5,
      background: group.color + '08', overflow:'hidden' }}>

      {/* ── Title bar ── */}
      <div style={{ height:HEADER_H, display:'flex', alignItems:'center', gap:6,
        padding:'0 8px', background: group.color + '16',
        borderBottom:`1px solid ${group.color}30` }}>
        <div style={{ width:7, height:7, borderRadius:2, background:group.color }}/>
        <span style={{ fontSize:10, color:group.color, fontFamily:E.mono, fontWeight:700 }}>
          {group.spriteId}
        </span>
      </div>

      {/* ── Animation rows ── */}
      {group.rows.map((row, ri) => {
        const isActiveRow = isActiveSp && activeAnimId === row.animId;
        return (
          <div key={row.animId}
            style={{ display:'flex', alignItems:'stretch',
              background: isActiveRow ? group.color + '10' : 'transparent',
              borderBottom: ri < group.rows.length - 1 ? `1px solid ${group.color}20` : 'none' }}>

            {/* Vertical animation label */}
            <div style={{ width:LABEL_W, flexShrink:0, display:'flex', alignItems:'center',
              justifyContent:'center', borderRight:`1px solid ${group.color}28`,
              writingMode:'vertical-lr', transform:'rotate(180deg)',
              fontSize:7, color: isActiveRow ? group.color : E.txtFaint,
              fontFamily:E.mono, cursor:'default' }}>
              {row.animId}
            </div>

            {/* Frame cells */}
            {row.frames.map((frame, i) => {
              const isSel = isActiveRow && activeFrame === i;
              return (
                <div key={i} onClick={() => onSelect(group.spriteId, row.animId, i)}
                  style={{ width:CELL, height:CELL, flexShrink:0, position:'relative',
                    cursor:'pointer', boxSizing:'border-box',
                    borderRight:`1px solid ${group.color}20`,
                    outline: isSel ? `2px solid ${group.color}` : 'none',
                    outlineOffset:-2 }}>
                  <SpriteCanvas data={frame} px={CELL} grid={false}/>
                  <span style={{ position:'absolute', bottom:1, right:2, fontSize:7,
                    color: isSel ? group.color : E.txtFaint, fontFamily:E.mono }}>
                    {i + 1}
                  </span>
                </div>
              );
            })}

            {/* + add frame */}
            <div style={{ width:ADD_W, height:CELL, flexShrink:0, display:'flex',
              alignItems:'center', justifyContent:'center', cursor:'pointer',
              color:E.txtFaint, fontSize:16, lineHeight:1,
              borderRight:`1px solid ${group.color}14` }}>
              +
            </div>
          </div>
        );
      })}

      {/* ── + add animation ── */}
      <div style={{ height:20, display:'flex', alignItems:'center',
        padding:'0 8px', gap:4, cursor:'pointer',
        borderTop:`1px solid ${group.color}20` }}>
        <span style={{ fontSize:8, color:E.txtFaint, fontFamily:E.font }}>+ animation</span>
      </div>
    </div>
  );
}

// ─── InfiniteCanvasArea ───────────────────────────────────────────────────────
// Overview: all sprite groups spatial layout.
// Paint: zoomed-in editing of the selected frame.
function InfiniteCanvasArea({ activeSpriteId, activeAnimId, activeFrame, tool, onSelect }) {
  const [zoom, setZoom] = useState(1);
  const [paint, setPaint] = useState(false);

  const activeGroup = CANVAS_GROUPS.find(g => g.spriteId === activeSpriteId);
  const pxPerCell   = Math.max(4, Math.round(22 * zoom));
  const DISPLAY     = pxPerCell * 16;

  const zoomIn  = () => setZoom(z => Math.min(+(z * 1.4).toFixed(2), 3));
  const zoomOut = () => setZoom(z => Math.max(+(z / 1.4).toFixed(2), 0.3));

  return (
    <div style={{ flex:1, position:'relative', overflow:'hidden', background:E.canvasBg,
      backgroundImage:'radial-gradient(circle, rgba(255,255,255,0.055) 1px, transparent 1px)',
      backgroundSize:'20px 20px' }}>

      {/* ── Top bar: mode toggle + zoom ── */}
      <div style={{ position:'absolute', top:0, left:0, right:0, zIndex:10, pointerEvents:'none',
        display:'flex', alignItems:'center', padding:'6px 12px', gap:6,
        background:'linear-gradient(rgba(12,14,26,0.88) 60%, transparent)' }}>

        {/* Overview / Paint toggle */}
        <div style={{ display:'flex', gap:2, pointerEvents:'all' }}>
          {[['Overview', false],['Paint', true]].map(([label, val]) => (
            <button key={label} onClick={() => setPaint(val)}
              style={{ padding:'3px 10px', fontSize:9, borderRadius:4, cursor:'pointer',
                background: paint===val ? E.accentSoft : 'transparent',
                border:`1px solid ${paint===val ? E.accentLine : E.border}`,
                color: paint===val ? E.accent : E.txtMute, fontFamily:E.font }}>
              {label}
            </button>
          ))}
        </div>

        {/* Active context breadcrumb */}
        {activeGroup && (
          <div style={{ display:'flex', alignItems:'center', gap:4, padding:'2px 8px',
            borderRadius:4, background:activeGroup.color+'16', border:`1px solid ${activeGroup.color}40`,
            pointerEvents:'none' }}>
            <div style={{ width:5, height:5, borderRadius:1, background:activeGroup.color }}/>
            <span style={{ fontSize:9, color:activeGroup.color, fontFamily:E.mono }}>
              {activeSpriteId} · {activeAnimId} · {activeFrame + 1}
            </span>
          </div>
        )}

        <div style={{ flex:1 }}/>

        {/* Zoom */}
        <div style={{ display:'flex', alignItems:'center', gap:3, pointerEvents:'all' }}>
          <button onClick={zoomOut}
            style={{ width:22, height:22, borderRadius:4, background:E.surface2,
              border:`1px solid ${E.border}`, color:E.txtMute, cursor:'pointer',
              fontSize:16, lineHeight:1, display:'flex', alignItems:'center', justifyContent:'center' }}>
            −
          </button>
          <span style={{ fontSize:9, color:E.txtMute, fontFamily:E.mono, padding:'3px 8px',
            background:E.surface2, border:`1px solid ${E.border}`, borderRadius:4, minWidth:52,
            textAlign:'center' }}>
            {paint ? `${pxPerCell}px·cell` : `${Math.round(zoom * 100)}%`}
          </span>
          <button onClick={zoomIn}
            style={{ width:22, height:22, borderRadius:4, background:E.surface2,
              border:`1px solid ${E.border}`, color:E.txtMute, cursor:'pointer',
              fontSize:16, lineHeight:1, display:'flex', alignItems:'center', justifyContent:'center' }}>
            +
          </button>
        </div>
      </div>

      {/* ── Canvas content ── */}
      {!paint ? (
        /* OVERVIEW — all sprite groups */
        <div style={{ position:'absolute', inset:0, overflow:'auto', paddingTop:40 }}>
          <div style={{
            position:'relative', width:700, height:340,
            transform:`scale(${zoom})`, transformOrigin:'top left',
            marginLeft:20, marginTop:8,
          }}>
            {CANVAS_GROUPS.map(group => (
              <SpriteGroupBox key={group.spriteId} group={group}
                activeSpriteId={activeSpriteId} activeAnimId={activeAnimId}
                activeFrame={activeFrame} onSelect={onSelect}/>
            ))}

            {/* Region tool — "being drawn" indicator */}
            {tool === 'region' && (
              <div style={{ position:'absolute', left:590, top:55,
                width:80, height:80, border:'2px dashed rgba(255,255,255,0.55)',
                borderRadius:2, pointerEvents:'none' }}>
                <div style={{ position:'absolute', bottom:-30, left:0, whiteSpace:'nowrap',
                  background:E.panel, border:`1px solid ${E.border}`, borderRadius:4,
                  padding:'3px 8px', display:'flex', alignItems:'center', gap:5 }}>
                  <span style={{ fontSize:9, color:E.txtMute, fontFamily:E.font }}>name:</span>
                  <span style={{ fontSize:9, color:E.txt, fontFamily:E.mono }}>hero_wall|</span>
                  <kbd style={{ fontSize:8, padding:'1px 5px', borderRadius:3,
                    background:E.accent, color:'#fff', fontFamily:E.font }}>↵</kbd>
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        /* PAINT — single frame zoomed in */
        <div style={{ position:'absolute', inset:0, display:'flex',
          alignItems:'center', justifyContent:'center', paddingTop:40 }}>
          <div style={{ position:'relative' }}>
            {/* Region label */}
            <div style={{ position:'absolute', top:-30, left:0,
              display:'flex', alignItems:'center', gap:6 }}>
              <div style={{ display:'flex', alignItems:'center', gap:5, padding:'3px 9px',
                borderRadius:5, background:E.panel,
                border:`1px solid ${activeGroup?.color ?? E.border}44` }}>
                <div style={{ width:6, height:6, borderRadius:1, background:activeGroup?.color }}/>
                <span style={{ fontSize:9, color:activeGroup?.color, fontFamily:E.mono }}>
                  {activeSpriteId} · {activeAnimId} · frame {activeFrame + 1}
                </span>
              </div>
            </div>
            {/* Sprite canvas */}
            <div style={{ border:`2px solid ${activeGroup?.color ?? E.accent}`,
              borderRadius:2, overflow:'hidden', position:'relative',
              boxShadow:`0 0 0 1px ${activeGroup?.color ?? E.accent}22, 0 12px 40px rgba(0,0,0,0.5)` }}>
              <SpriteCanvas data={FRAMES[activeFrame % FRAMES.length]} px={DISPLAY} grid={pxPerCell >= 6}/>
              {/* Cursor pixel */}
              <div style={{ position:'absolute', pointerEvents:'none',
                left: 7 * pxPerCell, top: 8 * pxPerCell,
                width:pxPerCell, height:pxPerCell,
                outline:'2px solid rgba(255,255,255,0.7)', outlineOffset:-1 }}/>
            </div>
            {/* Coord */}
            <div style={{ position:'absolute', bottom:-20, left:0,
              fontSize:8, color:E.txtFaint, fontFamily:E.mono }}>(7, 8)</div>
          </div>
        </div>
      )}

      {/* ── Bottom bar: grid size chips ── */}
      <div style={{ position:'absolute', bottom:0, left:0, right:0, pointerEvents:'none',
        display:'flex', alignItems:'center', padding:'5px 12px', gap:5,
        background:'linear-gradient(transparent, rgba(12,14,26,0.85))' }}>
        <span style={{ fontSize:8, color:E.txtFaint, fontFamily:E.mono }}>x:0  y:0</span>
        <div style={{ flex:1 }}/>
        <div style={{ display:'flex', gap:3, pointerEvents:'all' }}>
          {['16px','32px','64px'].map((g,i) => (
            <button key={g} style={{ padding:'2px 6px', fontSize:8, borderRadius:3, cursor:'pointer',
              background: i===0 ? E.accentSoft : 'transparent',
              border:`1px solid ${i===0 ? E.accentLine : E.border}`,
              color: i===0 ? E.accent : E.txtFaint, fontFamily:E.mono }}>
              grid {g}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── AnimStrip ────────────────────────────────────────────────────────────────
// Bottom strip: breadcrumb + playback + frame thumbnails of active animation
function AnimStrip({ activeSpriteId, activeAnimId, activeFrame, onFrame }) {
  const [playing, setPlaying] = useState(false);
  const [fps, setFps]         = useState(8);
  const [onion, setOnion]     = useState(false);

  const sprite = SPRITES_DATA.find(s => s.id === activeSpriteId);
  const anim   = sprite?.animations.find(a => a.id === activeAnimId);
  const fCount = anim?.frames ?? 4;
  const animColor = anim?.color ?? E.accent;

  return (
    <div style={{ background:E.panel, borderTop:`1px solid ${E.border}`,
      padding:'7px 12px 8px', flexShrink:0 }}>
      <div style={{ display:'flex', alignItems:'center', gap:7, marginBottom:7 }}>
        <div style={{ display:'flex', alignItems:'center', gap:4 }}>
          <div style={{ width:6, height:6, borderRadius:1, background:sprite?.color, flexShrink:0 }}/>
          <span style={{ fontSize:9, color:sprite?.color, fontFamily:E.mono }}>{activeSpriteId}</span>
          <span style={{ fontSize:9, color:E.txtFaint }}>·</span>
          <span style={{ fontSize:9, color:animColor, fontFamily:E.mono }}>{activeAnimId}</span>
          <span style={{ fontSize:9, color:E.txtFaint, fontFamily:E.mono }}>{fCount}f</span>
        </div>
        <div style={{ flex:1 }}/>
        <PlayBtn playing={playing} onToggle={() => setPlaying(p => !p)}/>
        <TogBtn on={onion} onClick={() => setOnion(o => !o)}>Onion</TogBtn>
        <div style={{ display:'flex', alignItems:'center', gap:4 }}>
          <span style={{ fontSize:9, color:E.txtMute, fontFamily:E.font }}>FPS</span>
          <input type="number" min={1} max={30} value={fps}
            onChange={e => setFps(+e.target.value || 8)}
            style={{ width:36, padding:'2px 4px', fontSize:10, fontFamily:E.mono,
              background:E.surface2, border:`1px solid ${E.border}`,
              borderRadius:4, color:E.txt, textAlign:'center' }}/>
        </div>
        <span style={{ fontSize:9, color:E.txtFaint, fontFamily:E.mono }}>
          {activeFrame + 1}/{fCount}
        </span>
      </div>
      <div style={{ display:'flex', gap:4, overflowX:'auto' }}>
        {Array.from({length:fCount}).map((_,i) => (
          <div key={i} onClick={() => onFrame(i)}
            style={{ width:48, height:48, flexShrink:0, borderRadius:4, overflow:'hidden',
              cursor:'pointer', position:'relative', background:E.canvasBg,
              border:`2px solid ${activeFrame===i ? animColor : E.border}` }}>
            <SpriteCanvas data={FRAMES[i % FRAMES.length]} px={48} grid={false}/>
            <span style={{ position:'absolute', bottom:1, right:2, fontSize:7,
              color: activeFrame===i ? animColor : E.txtFaint, fontFamily:E.mono }}>{i+1}</span>
          </div>
        ))}
        <button style={{ width:48, height:48, flexShrink:0, borderRadius:4,
          border:`2px dashed ${E.border}`, background:'transparent',
          color:E.txtMute, cursor:'pointer', fontSize:22,
          display:'flex', alignItems:'center', justifyContent:'center' }}>+</button>
      </div>
    </div>
  );
}

// ─── SpritesPanel ─────────────────────────────────────────────────────────────
function SpritesPanel({ activeSprite, activeAnim, onSelect }) {
  const [open, setOpen] = useState({ hero:true, coin:false, platform:false });
  return (
    <div>
      <SLabel text="Sprites" right={
        <button style={{ fontSize:16, color:E.txtMute, cursor:'pointer',
          background:'transparent', border:'none', lineHeight:.9 }}>+</button>
      }/>
      {SPRITES_DATA.map(sp => {
        const isActiveSp = activeSprite === sp.id;
        const isOpen = open[sp.id];
        return (
          <div key={sp.id} style={{ marginBottom:2 }}>
            <div onClick={() => setOpen(o => ({...o, [sp.id]:!o[sp.id]}))}
              style={{ display:'flex', alignItems:'center', gap:6, padding:'4px 6px',
                borderRadius:5, cursor:'pointer',
                background: isActiveSp ? sp.color+'12' : 'transparent' }}>
              <span style={{ fontSize:9, color:E.txtFaint, width:10, flexShrink:0 }}>
                {isOpen ? '▾' : '▸'}
              </span>
              <div style={{ width:8, height:8, borderRadius:2, background:sp.color, flexShrink:0 }}/>
              <span style={{ fontSize:11, fontFamily:E.mono, fontWeight:600, flex:1,
                color: isActiveSp ? sp.color : E.txt }}>{sp.id}</span>
              <span style={{ fontSize:8, color:E.txtFaint, fontFamily:E.font }}>{sp.size}</span>
            </div>
            {isOpen && sp.animations.map(an => {
              const isActive = isActiveSp && activeAnim === an.id;
              return (
                <div key={an.id} onClick={() => onSelect(sp.id, an.id)}
                  style={{ display:'flex', alignItems:'center', gap:6,
                    padding:'3px 6px 3px 22px', borderRadius:5, cursor:'pointer', marginBottom:1,
                    background: isActive ? an.color+'1a' : 'transparent',
                    border:`1px solid ${isActive ? an.color+'44' : 'transparent'}` }}>
                  <div style={{ width:5, height:5, borderRadius:99, flexShrink:0,
                    background: isActive ? an.color : E.txtFaint }}/>
                  <span style={{ fontSize:10, fontFamily:E.mono, flex:1,
                    color: isActive ? an.color : E.txt }}>{an.id}</span>
                  <div style={{ display:'flex', gap:2 }}>
                    {Array.from({length:an.frames}).map((_,i) => (
                      <div key={i} style={{ width:5, height:5, borderRadius:1,
                        background: isActive&&i===0 ? an.color : E.txtFaint+'44' }}/>
                    ))}
                  </div>
                  <span style={{ fontSize:8, color:E.txtFaint, fontFamily:E.mono }}>{an.frames}f</span>
                </div>
              );
            })}
            {isOpen && (
              <button style={{ fontSize:9, color:E.txtFaint, fontFamily:E.font, cursor:'pointer',
                background:'transparent', border:'none', padding:'2px 6px 4px 26px',
                display:'flex', alignItems:'center', gap:3 }}>
                <span>+</span> add animation
              </button>
            )}
          </div>
        );
      })}
      <button style={{ marginTop:4, width:'100%', padding:'5px 0', fontSize:9,
        fontFamily:E.font, background:'transparent',
        border:`1px dashed ${E.border}`, borderRadius:5, color:E.txtFaint,
        cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:4 }}>
        <span style={{ fontSize:14, lineHeight:1 }}>+</span> New sprite
      </button>
    </div>
  );
}

// ─── LayoutStudio ─────────────────────────────────────────────────────────────
function LayoutStudio() {
  const [tool, setTool]     = useState('pencil');
  const [activeSp, setSp]   = useState('hero');
  const [activeAn, setAn]   = useState('idle');
  const [activeF, setF]     = useState(0);

  const selectAnim = (spId, anId) => { setSp(spId); setAn(anId); setF(0); };
  const selectFrame = (spId, anId, fi) => { setSp(spId); setAn(anId); setF(fi); };

  return (
    <div style={{ display:'flex', flexDirection:'column', width:'100%', height:'100%',
      background:E.bg, fontFamily:E.font, overflow:'hidden' }}>
      <EditorHeader/>

      <div style={{ display:'flex', flex:1, overflow:'hidden' }}>
        <ToolStrip active={tool} onSelect={setTool}/>

        {/* Canvas column */}
        <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'hidden', minWidth:0 }}>
          <InfiniteCanvasArea
            activeSpriteId={activeSp}
            activeAnimId={activeAn}
            activeFrame={activeF}
            tool={tool}
            onSelect={selectFrame}
          />
          <AnimStrip
            activeSpriteId={activeSp}
            activeAnimId={activeAn}
            activeFrame={activeF}
            onFrame={setF}
          />
        </div>

        {/* Right sidebar */}
        <div style={{ width:268, background:E.panel, borderLeft:`1px solid ${E.border}`,
          display:'flex', flexDirection:'column', overflow:'hidden', flexShrink:0 }}>
          <div style={{ flex:1, overflowY:'auto', display:'flex', flexDirection:'column' }}>
            <SideSection>
              <SpritesPanel activeSprite={activeSp} activeAnim={activeAn} onSelect={selectAnim}/>
            </SideSection>
            <SideSection><ColorLerpPanel/></SideSection>
            <SideSection><LayerPanel/></SideSection>
            <SideSection style={{ flex:1 }}>
              <SLabel text="Palette" right={
                <span style={{ fontSize:9, color:E.txtMute, fontFamily:E.font }}>Sweetie-16 ▾</span>
              }/>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:3 }}>
                {PAL.map((c,i) => (
                  <div key={i} style={{ aspectRatio:1, background:c, borderRadius:3,
                    border:'1px solid rgba(0,0,0,0.3)', cursor:'pointer' }}/>
                ))}
              </div>
            </SideSection>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { LayoutStudio });
