// sprite-editor-shared.jsx
// Dark theme tokens + all shared components for the Stage 1c sprite editor mockup

const { useState, useEffect, useRef } = React;

// ─── Dark editor theme ──────────────────────────────────────────────────────
const E = {
  bg:           '#12141e',
  panel:        '#181b2a',
  surface:      '#1e2132',
  surface2:     '#252940',
  border:       'rgba(255,255,255,0.06)',
  borderMid:    'rgba(255,255,255,0.10)',
  borderStrong: 'rgba(255,255,255,0.18)',
  accent:       '#0e9aa7',   // pi3 teal
  accentSoft:   'rgba(14,154,167,0.15)',
  accentLine:   'rgba(14,154,167,0.38)',
  orange:       '#f6a560',   // pi3 student orange
  orangeSoft:   'rgba(246,165,96,0.18)',
  purple:       '#9b6dff',
  purpleSoft:   'rgba(155,109,255,0.18)',
  green:        '#38b764',
  greenSoft:    'rgba(56,183,100,0.18)',
  yellow:       '#ffcd75',
  yellowSoft:   'rgba(255,205,117,0.18)',
  txt:          '#ccd0da',
  txtMute:      '#6b7785',
  txtFaint:     '#3a4060',
  canvasBg:     '#0c0e1a',
  font:  "'Inter', system-ui, sans-serif",
  mono:  "'JetBrains Mono', ui-monospace, monospace",
};

// ─── Sprite data (Sweetie-16 colour keys) ──────────────────────────────────
// 0=transparent, 1=#1a1c2c (outline), 2=#ef7d57 (skin), 3=#b13e53 (shirt),
// 4=#29366f (pants), 5=#ffcd75 (hair), 6=#333c57 (boots)
const SC = { 0:null,'1':'#1a1c2c','2':'#ef7d57','3':'#b13e53','4':'#29366f',
             '5':'#ffcd75','6':'#333c57','7':'#566c86','8':'#f4f4f4' };

const F0 = [   // hero — idle / neutral
  [0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0],
  [0,0,0,0,0,0,1,5,5,1,0,0,0,0,0,0],
  [0,0,0,0,0,1,5,5,5,5,1,0,0,0,0,0],
  [0,0,0,0,1,2,2,2,2,2,2,1,0,0,0,0],
  [0,0,0,0,1,2,1,2,2,1,2,1,0,0,0,0],
  [0,0,0,0,1,2,2,2,2,2,2,1,0,0,0,0],
  [0,0,0,0,1,2,2,3,3,2,2,1,0,0,0,0],
  [0,0,0,0,0,1,1,1,1,1,1,0,0,0,0,0],
  [0,0,0,1,1,3,3,3,3,3,3,1,1,0,0,0],
  [0,0,0,1,3,3,3,3,3,3,3,3,1,0,0,0],
  [0,0,0,1,3,3,3,3,3,3,3,3,1,0,0,0],
  [0,0,0,0,1,3,3,3,3,3,3,1,0,0,0,0],
  [0,0,0,0,1,4,4,1,1,4,4,1,0,0,0,0],
  [0,0,0,0,1,4,4,0,0,4,4,1,0,0,0,0],
  [0,0,0,0,1,4,4,0,0,4,4,1,0,0,0,0],
  [0,0,0,0,1,6,6,0,0,6,6,1,0,0,0,0],
];
const F1 = F0.map((r,y) =>   // idle — foot lift
  y===14 ? [0,0,0,0,1,4,4,0,0,4,5,1,0,0,0,0] :
  y===15 ? [0,0,0,0,1,6,6,0,0,1,5,0,0,0,0,0] : [...r]);
const F2 = F0.map((r,y) =>   // run — arm swing L
  y===8  ? [0,0,1,3,1,3,3,3,3,3,3,1,3,1,0,0] :
  y===13 ? [0,0,0,1,4,4,4,0,0,0,4,4,1,0,0,0] :
  y===14 ? [0,0,0,1,4,4,4,0,0,0,4,4,1,0,0,0] :
  y===15 ? [0,0,0,1,6,6,6,0,0,0,6,6,1,0,0,0] : [...r]);
const F3 = F0.map((r,y) =>   // run — arm swing R
  y===8  ? [0,0,0,1,3,1,3,3,3,3,1,3,1,0,0,0] :
  y===13 ? [0,0,0,0,1,4,4,0,0,4,4,1,0,0,0,0] :
  y===14 ? [0,0,0,0,0,4,4,0,0,4,4,0,0,0,0,0] :
  y===15 ? [0,0,0,0,1,6,6,0,0,6,6,1,0,0,0,0] : [...r]);

const FRAMES = [F0, F1, F2, F3];

// ─── 32×32 sprite — 2× scaled F0 with hand-added shading ────────────────────
const F0_32 = (() => {
  const g = Array.from({length:32}, (_,y) =>
    Array.from({length:32}, (_,x) => F0[Math.floor(y/2)][Math.floor(x/2)])
  );
  // Hair highlight (top-right crown)
  [[3,16],[4,16],[4,17],[4,18],[5,17]].forEach(([y,x]) => { if(g[y][x]===5) g[y][x]=8; });
  // Shirt inner shadow (right edge of torso)
  [[18,22],[19,22],[20,22],[21,22],[22,22]].forEach(([y,x]) => { if(g[y][x]===3) g[y][x]=7; });
  // Shirt collar shadow
  [[16,14],[16,15],[16,16]].forEach(([y,x]) => { if(g[y][x]===3) g[y][x]=7; });
  // Face subtle shadow (jaw area)
  [[12,9],[12,10],[13,9],[13,10]].forEach(([y,x]) => { if(g[y][x]===2) g[y][x]=7; });
  // Pants mid highlight
  [[26,10],[27,10]].forEach(([y,x]) => { if(g[y][x]===4) g[y][x]=7; });
  return g;
})();

// Sheet: which frame data goes in which cell (8×8 = 64 cells)
const SHEET_CELLS = {};
[0,1,2,3].forEach((c,i) => { SHEET_CELLS[c] = FRAMES[i]; });      // hero_idle
[4,5,6,7].forEach((c,i) => { SHEET_CELLS[c] = FRAMES[(i+2)%4]; });// hero_run
[8,9,10,11].forEach((c,i)=> { SHEET_CELLS[c] = FRAMES[(i+1)%4]; });// hero_jump
[16,17,18,19].forEach((c,i)=>{ SHEET_CELLS[c] = FRAMES[(i+3)%4];});// coin
[32,33].forEach((c,i) => { SHEET_CELLS[c] = FRAMES[i]; });         // platform

// Named regions on the sheet
const REGIONS = [
  { id:'hero_idle', cells:[0,1,2,3],     color:'#0e9aa7', label:'hero_idle' },
  { id:'hero_run',  cells:[4,5,6,7],     color:'#f6a560', label:'hero_run'  },
  { id:'hero_jump', cells:[8,9,10,11],   color:'#9b6dff', label:'hero_jump' },
  { id:'coin',      cells:[16,17,18,19], color:'#38b764', label:'coin_spin' },
  { id:'platform',  cells:[32,33],       color:'#ffcd75', label:'platform'  },
];
const CELL_MAP = {};
REGIONS.forEach(r => r.cells.forEach(c => { CELL_MAP[c] = r; }));

// Sweetie-16
const PAL = ['#1a1c2c','#5d275d','#b13e53','#ef7d57','#ffcd75','#a7f070','#38b764','#257179',
             '#29366f','#3b5dc9','#41a6f6','#73eff7','#f4f4f4','#94b0c2','#566c86','#333c57'];

// Sweetie-16 Python name aliases (for Colors.lerp() hint)
const PAL_NAMES = {
  '#1a1c2c':'dark','#5d275d':'purple','#b13e53':'red','#ef7d57':'orange',
  '#ffcd75':'yellow','#a7f070':'lime','#38b764':'green','#257179':'teal',
  '#29366f':'navy','#3b5dc9':'blue','#41a6f6':'sky','#73eff7':'cyan',
  '#f4f4f4':'white','#94b0c2':'silver','#566c86':'slate','#333c57':'charcoal',
};

// ─── Color lerp helpers ───────────────────────────────────────────────────────
function hexToRgb(h) {
  return [parseInt(h.slice(1,3),16), parseInt(h.slice(3,5),16), parseInt(h.slice(5,7),16)];
}
function hexLerp(a, b, t) {
  const [ar,ag,ab2] = hexToRgb(a), [br,bg,bb] = hexToRgb(b);
  return '#' + [
    Math.round(ar+(br-ar)*t),
    Math.round(ag+(bg-ag)*t),
    Math.round(ab2+(bb-ab2)*t),
  ].map(v => v.toString(16).padStart(2,'0')).join('');
}

// ─── ToolIcon ───────────────────────────────────────────────────────────────
function ToolIcon({ id, size = 14 }) {
  const d = {
    pencil:  <><path d="M2.5 11.5l.8 2.5 2.4-.8L13 6.5l-3-3z" fill="currentColor" opacity=".85"/><path d="M10.5 3.5l2 2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></>,
    eraser:  <><path d="M4 12L2 10l7-7 2 2-7 7z" stroke="currentColor" strokeWidth="1.4" fill="none" strokeLinejoin="round"/><path d="M3.5 13.5h9" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></>,
    line:    <path d="M2.5 13.5l11-11" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>,
    rect:    <rect x="2.5" y="3.5" width="11" height="9" stroke="currentColor" strokeWidth="1.5" fill="none" rx="0.5"/>,
    circle:  <circle cx="8" cy="8" r="5.5" stroke="currentColor" strokeWidth="1.5" fill="none"/>,
    fill:    <><path d="M2.5 12.5l4-4 1 1-4 4-1-1zM5.5 9.5l5-5 1 1" stroke="currentColor" strokeWidth="1.3" fill="none" strokeLinecap="round" strokeLinejoin="round"/><path d="M13 9.5s1.5 1.5 1.5 2.5a1.5 1.5 0 01-3 0c0-1 1.5-2.5 1.5-2.5z" fill="currentColor"/></>,
    eyedrop: <><path d="M9.5 3.5l2.5 2.5L6 12 3.5 9.5l6-6zM2.5 12.5l.8 2 2-.8" stroke="currentColor" strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round"/></>,
    mirror:  <><path d="M8 2v12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeDasharray="2 1.5"/><path d="M2 5.5l3 2.5-3 2.5M14 5.5l-3 2.5 3 2.5" stroke="currentColor" strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round"/></>,
    darken:  <><circle cx="8" cy="8" r="5.5" stroke="currentColor" strokeWidth="1.2" fill="none"/><path d="M8 2.5C5 2.5 2.5 5 2.5 8h11C13.5 5 11 2.5 8 2.5z" fill="currentColor" opacity=".6"/></>,
    lighten: <><circle cx="8" cy="8" r="5.5" stroke="currentColor" strokeWidth="1.2" fill="none"/><path d="M8 5v6M5 8h6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></>,
    region:  <><rect x="2" y="2" width="12" height="12" stroke="currentColor" strokeWidth="1.3" fill="none" strokeDasharray="2 1.5" rx="1"/><path d="M11 5l2-2m0 0v2.5m0-2.5h-2.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/></>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" style={{ flex:'none', display:'block' }}>
      {d[id] || <circle cx="8" cy="8" r="5" stroke="currentColor" strokeWidth="1.4" fill="none"/>}
    </svg>
  );
}

// ─── SpriteCanvas — renders one frame as a pixelated canvas ─────────────────
function SpriteCanvas({ data = F0, px = 480, grid = true }) {
  const ref = useRef(null);
  const N = data.length;
  const cell = px / N;
  useEffect(() => {
    const cv = ref.current; if (!cv) return;
    const ctx = cv.getContext('2d');
    for (let y = 0; y < N; y++) {
      for (let x = 0; x < N; x++) {
        const k = data[y]?.[x] ?? 0;
        ctx.fillStyle = k === 0 ? ((x+y)%2===0 ? '#191c2c' : '#141722') : (SC[k] || '#f0f');
        ctx.fillRect(x*cell, y*cell, cell, cell);
      }
    }
    if (grid && cell >= 4) {
      ctx.strokeStyle = 'rgba(255,255,255,0.05)';
      ctx.lineWidth = 0.5;
      for (let i = 1; i < N; i++) {
        ctx.beginPath(); ctx.moveTo(i*cell,0); ctx.lineTo(i*cell,px); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0,i*cell); ctx.lineTo(px,i*cell); ctx.stroke();
      }
    }
  }, [data, px, grid, N, cell]);
  return <canvas ref={ref} width={px} height={px} style={{ display:'block', imageRendering:'pixelated' }}/>;
}

// ─── FullSheetCanvas — entire 8×8 spritesheet with sprites + overlays ────────
function FullSheetCanvas({ px = 320, selected = 0, onSelect }) {
  const ref = useRef(null);
  const COLS = 8;
  const cellPx = px / COLS;
  const [hov, setHov] = useState(null);

  useEffect(() => {
    const cv = ref.current; if (!cv) return;
    const ctx = cv.getContext('2d');
    ctx.fillStyle = E.canvasBg;
    ctx.fillRect(0, 0, px, px);

    // Draw sprite data into each populated cell
    for (let ci = 0; ci < COLS * COLS; ci++) {
      const frame = SHEET_CELLS[ci]; if (!frame) continue;
      const col = ci % COLS, row = Math.floor(ci / COLS);
      const sx = col * cellPx, sy = row * cellPx;
      const N = frame.length, ppp = cellPx / N;
      for (let fy = 0; fy < N; fy++) {
        for (let fx = 0; fx < N; fx++) {
          const k = frame[fy]?.[fx] ?? 0; if (!k) continue;
          ctx.fillStyle = SC[k] || '#f0f';
          ctx.fillRect(sx + fx*ppp, sy + fy*ppp, ppp, ppp);
        }
      }
    }

    // Region overlays
    REGIONS.forEach(r => {
      ctx.fillStyle = hov === r.id ? r.color + '40' : r.color + '22';
      r.cells.forEach(c => {
        const col = c % COLS, row = Math.floor(c / COLS);
        ctx.fillRect(col*cellPx, row*cellPx, cellPx, cellPx);
      });
    });

    // Grid lines
    ctx.strokeStyle = 'rgba(255,255,255,0.07)'; ctx.lineWidth = 0.5;
    for (let i = 0; i <= COLS; i++) {
      ctx.beginPath(); ctx.moveTo(i*cellPx,0); ctx.lineTo(i*cellPx,px); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0,i*cellPx); ctx.lineTo(px,i*cellPx); ctx.stroke();
    }

    // Region label on first cell
    REGIONS.forEach(r => {
      const c = r.cells[0], col = c % COLS, row = Math.floor(c / COLS);
      ctx.fillStyle = r.color; ctx.font = `${Math.min(7, cellPx*0.22)}px 'JetBrains Mono', monospace`;
      ctx.fillText(r.label, col*cellPx+2, row*cellPx+cellPx*0.22);
    });

    // Selected cell highlight
    const sc2 = selected % COLS, sr2 = Math.floor(selected / COLS);
    ctx.strokeStyle = E.accent; ctx.lineWidth = 2;
    ctx.strokeRect(sc2*cellPx+1, sr2*cellPx+1, cellPx-2, cellPx-2);

  }, [px, selected, hov, cellPx]);

  return (
    <div style={{ position:'relative', display:'inline-block' }}>
      <canvas ref={ref} width={px} height={px} style={{ display:'block', imageRendering:'pixelated' }}/>
      {/* invisible click layer */}
      <div style={{ position:'absolute', inset:0, display:'grid', gridTemplateColumns:`repeat(${COLS},1fr)` }}>
        {Array.from({length:COLS*COLS},(_,c) => (
          <div key={c} onClick={() => onSelect?.(c)}
            onMouseEnter={() => { setHov(CELL_MAP[c]?.id || null); }}
            onMouseLeave={() => setHov(null)}
            style={{ cursor: SHEET_CELLS[c] ? 'pointer' : 'default' }}/>
        ))}
      </div>
    </div>
  );
}

// ─── ToolStrip ──────────────────────────────────────────────────────────────
const TOOL_GROUPS = [['pencil','eraser'],['line','rect','circle'],['fill','eyedrop'],['mirror'],['darken','lighten'],['region']];
const TOOL_META = {
  pencil:{l:'Pencil',k:'B'}, eraser:{l:'Eraser',k:'E'}, line:{l:'Line',k:'L'},
  rect:{l:'Rect',k:'R'}, circle:{l:'Circle',k:'C'}, fill:{l:'Fill',k:'G'},
  eyedrop:{l:'Pick',k:'I'}, mirror:{l:'Mirror',k:'M'}, darken:{l:'Darken',k:'D'}, lighten:{l:'Light',k:'S'},
  region:{l:'Region',k:'Q'},
};

function ToolStrip({ active = 'pencil', onSelect, style = {} }) {
  const [hov, setHov] = useState(null);
  return (
    <div style={{ width:50, background:E.panel, borderRight:`1px solid ${E.border}`, display:'flex', flexDirection:'column', alignItems:'center', padding:'10px 0', gap:2, flexShrink:0, ...style }}>
      {TOOL_GROUPS.map((g, gi) => (
        <React.Fragment key={gi}>
          {gi > 0 && <div style={{ width:28, height:1, background:E.border, margin:'4px 0' }}/>}
          {g.map(tid => {
            const on = active === tid;
            return (
              <button key={tid} title={`${TOOL_META[tid].l} (${TOOL_META[tid].k})`}
                onMouseEnter={() => setHov(tid)} onMouseLeave={() => setHov(null)}
                onClick={() => onSelect?.(tid)}
                style={{ width:36, height:36, display:'flex', alignItems:'center', justifyContent:'center',
                  borderRadius:6, border: on ? `1px solid ${E.accentLine}` : '1px solid transparent',
                  background: on ? E.accentSoft : hov===tid ? E.surface : 'transparent',
                  color: on ? E.accent : hov===tid ? E.txt : E.txtMute, cursor:'pointer', transition:'all .1s' }}>
                <ToolIcon id={tid} size={15}/>
              </button>
            );
          })}
        </React.Fragment>
      ))}
      <div style={{ flex:1 }}/>
      <div style={{ fontSize:9, color:E.txtFaint, fontFamily:E.mono, marginBottom:4 }}>
        {TOOL_META[active]?.k}
      </div>
    </div>
  );
}

// ─── LayerPanel ─────────────────────────────────────────────────────────────
function LayerPanel() {
  const [active, setActive] = useState(0);
  const layers = [{id:0,name:'Foreground',op:100},{id:1,name:'Background',op:60}];
  return (
    <div>
      <SLabel text="Layers" right={<span style={{ fontSize:16, color:E.txtMute, lineHeight:.9, cursor:'pointer' }}>+</span>}/>
      {layers.map(l => (
        <div key={l.id} onClick={() => setActive(l.id)}
          style={{ display:'flex', alignItems:'center', gap:6, padding:'5px 8px', borderRadius:6,
            background: active===l.id ? E.surface2 : 'transparent',
            border: active===l.id ? `1px solid ${E.borderMid}` : '1px solid transparent',
            cursor:'pointer', marginBottom:2 }}>
          <svg width={12} height={12} viewBox="0 0 16 16" fill="none" style={{ color: l.op > 50 ? E.txtMute : E.txtFaint, flexShrink:0 }}>
            <ellipse cx="8" cy="8" rx="6" ry="4" stroke="currentColor" strokeWidth="1.4"/>
            <circle cx="8" cy="8" r="2" fill="currentColor"/>
          </svg>
          <div style={{ width:18, height:18, background:E.canvasBg, border:`1px solid ${E.border}`, borderRadius:3, flexShrink:0 }}/>
          <span style={{ fontSize:11, color:E.txt, fontFamily:E.font, flex:1 }}>{l.name}</span>
          <span style={{ fontSize:9, color:E.txtFaint, fontFamily:E.mono }}>{l.op}%</span>
        </div>
      ))}
    </div>
  );
}

// ─── PalettePanel ───────────────────────────────────────────────────────────
function PalettePanel() {
  const [color, setColor] = useState('#ef7d57');
  return (
    <div>
      <SLabel text="Palette" right={
        <span style={{ fontSize:9, color:E.txtMute, fontFamily:E.font }}>Sweetie-16 ▾</span>
      }/>
      <div style={{ display:'flex', gap:8, marginBottom:8, alignItems:'center' }}>
        <div style={{ width:34, height:34, borderRadius:6, background:color, border:`2px solid ${E.borderStrong}`, flexShrink:0 }}/>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontSize:9, color:E.txtFaint, fontFamily:E.mono, marginBottom:4 }}>{color.toUpperCase()}</div>
          <input type="range" min={0} max={100} defaultValue={100} style={{ width:'100%', accentColor:E.accent, margin:0 }}/>
          <div style={{ fontSize:8, color:E.txtFaint, fontFamily:E.font }}>opacity 100%</div>
        </div>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:3 }}>
        {PAL.map((c,i) => (
          <button key={i} onClick={() => setColor(c)}
            style={{ aspectRatio:1, background:c, borderRadius:3, cursor:'pointer',
              border: c===color ? `2px solid ${E.txt}` : '1px solid rgba(0,0,0,0.35)' }}/>
        ))}
      </div>
    </div>
  );
}

// ─── ColorLerpPanel ─────────────────────────────────────────────────────────
function ColorLerpPanel() {
  const [colorA, setColorA] = useState('#b13e53');
  const [colorB, setColorB] = useState('#41a6f6');
  const [selT, setSelT] = useState(0.5);
  const [picking, setPicking] = useState(null); // 'a' | 'b' | null

  const STEPS = 9;
  const swatches = Array.from({length:STEPS}, (_,i) => hexLerp(colorA, colorB, i/(STEPS-1)));
  const activeColor = hexLerp(colorA, colorB, selT);
  const nameA = PAL_NAMES[colorA] || '?';
  const nameB = PAL_NAMES[colorB] || '?';

  const pickColor = (c) => {
    if (picking==='a') setColorA(c);
    else if (picking==='b') setColorB(c);
    setPicking(null);
  };

  return (
    <div>
      <SLabel text="Color Lerp" right={
        <span style={{ fontSize:8, color:E.accentLine, fontFamily:E.mono }}>Colors.lerp()</span>
      }/>

      {/* A — gradient strip — B */}
      <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:8 }}>
        <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:2 }}>
          <div onClick={() => setPicking(p => p==='a'?null:'a')}
            style={{ width:26, height:26, borderRadius:5, background:colorA,
              border:`2px solid ${picking==='a' ? E.txt : E.border}`, cursor:'pointer' }}/>
          <span style={{ fontSize:8, color:E.txtFaint, fontFamily:E.mono }}>A</span>
        </div>

        <div style={{ flex:1, display:'flex', flexDirection:'column', gap:4 }}>
          <div onClick={(e) => {
            const r = e.currentTarget.getBoundingClientRect();
            setSelT(Math.max(0,Math.min(1,(e.clientX-r.left)/r.width)));
          }} style={{ height:18, borderRadius:4, cursor:'crosshair',
            background:`linear-gradient(to right, ${colorA}, ${colorB})`,
            border:`1px solid ${E.border}`, position:'relative' }}>
            <div style={{ position:'absolute', top:-3, bottom:-3, width:4, borderRadius:2,
              left:`calc(${selT*100}% - 2px)`, background:E.txt,
              boxShadow:'0 0 0 1px rgba(0,0,0,0.6)', pointerEvents:'none' }}/>
          </div>
          <div style={{ display:'flex', justifyContent:'space-between' }}>
            <span style={{ fontSize:7, color:E.txtFaint, fontFamily:E.mono }}>0</span>
            <span style={{ fontSize:8, color:E.txtMute, fontFamily:E.mono }}>t = {selT.toFixed(2)}</span>
            <span style={{ fontSize:7, color:E.txtFaint, fontFamily:E.mono }}>1</span>
          </div>
        </div>

        <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:2 }}>
          <div onClick={() => setPicking(p => p==='b'?null:'b')}
            style={{ width:26, height:26, borderRadius:5, background:colorB,
              border:`2px solid ${picking==='b' ? E.txt : E.border}`, cursor:'pointer' }}/>
          <span style={{ fontSize:8, color:E.txtFaint, fontFamily:E.mono }}>B</span>
        </div>
      </div>

      {/* Lerp swatch strip */}
      <div style={{ display:'flex', gap:2, marginBottom:8 }}>
        {swatches.map((c, i) => {
          const t = i/(STEPS-1);
          const isActive = Math.round(selT*(STEPS-1)) === i;
          return (
            <div key={i} onClick={() => setSelT(t)}
              style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', gap:2 }}>
              <div style={{ height:22, borderRadius:3, background:c, width:'100%', cursor:'pointer',
                border:`2px solid ${isActive ? E.txt : 'transparent'}`, boxSizing:'border-box' }}/>
              {(i===0 || i===(STEPS-1)/2 || i===STEPS-1)
                ? <span style={{ fontSize:7, color:E.txtFaint, fontFamily:E.mono }}>{Math.round(t*100)}%</span>
                : <span style={{ fontSize:7, color:'transparent' }}>·</span>}
            </div>
          );
        })}
      </div>

      {/* Result chip */}
      <div style={{ display:'flex', alignItems:'center', gap:8, padding:'7px 9px',
        borderRadius:6, background:E.surface2, border:`1px solid ${E.border}`, marginBottom:8 }}>
        <div style={{ width:22, height:22, borderRadius:4, background:activeColor,
          border:`1px solid ${E.borderMid}`, flexShrink:0 }}/>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontSize:10, color:E.txt, fontFamily:E.mono, marginBottom:2 }}>{activeColor}</div>
          <div style={{ fontSize:8, color:E.txtMute, fontFamily:E.mono, whiteSpace:'nowrap', overflow:'hidden' }}>
            Colors.lerp(<span style={{ color:E.orange }}>{nameA}</span>,{' '}
            <span style={{ color:E.accent }}>{nameB}</span>, {selT.toFixed(2)})
          </div>
        </div>
      </div>

      {/* Inline palette picker */}
      {picking && (
        <div>
          <SLabel text={`Pick color ${picking.toUpperCase()}`}/>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:3 }}>
            {PAL.map((c,i) => (
              <div key={i} onClick={() => pickColor(c)}
                style={{ aspectRatio:1, background:c, borderRadius:3, cursor:'pointer',
                  border: ((picking==='a'&&c===colorA)||(picking==='b'&&c===colorB))
                    ? `2px solid ${E.txt}` : '1px solid rgba(0,0,0,0.3)' }}/>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── SheetNavigator (mini sidebar version) ──────────────────────────────────
function SheetNavigator({ cellPx = 24, selected = 0, onSelect, showLegend = true }) {
  const COLS = 8;
  const [selCell, setSelCell] = useState(selected);
  const [hovReg, setHovReg] = useState(null);
  const size = COLS * cellPx;

  const pick = (c) => { setSelCell(c); onSelect?.(c); };

  return (
    <div>
      <SLabel text="Sheet" right={<span style={{ fontSize:9, color:E.txtMute, fontFamily:E.mono }}>128×128</span>}/>
      {showLegend && (
        <div style={{ display:'flex', flexWrap:'wrap', gap:3, marginBottom:6 }}>
          {REGIONS.map(r => (
            <div key={r.id} onMouseEnter={()=>setHovReg(r.id)} onMouseLeave={()=>setHovReg(null)}
              style={{ display:'flex', alignItems:'center', gap:3, padding:'1px 5px', borderRadius:99,
                background: hovReg===r.id ? r.color+'30' : r.color+'16',
                border:`1px solid ${r.color}44`, cursor:'pointer' }}>
              <div style={{ width:5, height:5, borderRadius:2, background:r.color }}/>
              <span style={{ fontSize:8, color:E.txtMute, fontFamily:E.mono }}>{r.label}</span>
            </div>
          ))}
        </div>
      )}
      <div style={{ position:'relative', width:size, height:size, background:E.canvasBg,
        border:`1px solid ${E.borderMid}`, borderRadius:4, overflow:'hidden' }}>
        {/* Region colour fills */}
        {REGIONS.map(r => r.cells.map(c => {
          const col=c%COLS, row=Math.floor(c/COLS);
          return (
            <div key={`${r.id}-${c}`} style={{ position:'absolute', left:col*cellPx, top:row*cellPx,
              width:cellPx, height:cellPx, background: hovReg===r.id ? r.color+'3a' : r.color+'1c',
              borderBottom:`0.5px solid ${r.color}55`, borderRight:`0.5px solid ${r.color}55`,
              boxSizing:'border-box', transition:'background .1s', pointerEvents:'none' }}/>
          );
        }))}
        {/* Grid lines */}
        <svg width={size} height={size} style={{ position:'absolute', inset:0, pointerEvents:'none' }}>
          {Array.from({length:COLS+1}).map((_,i) => (
            <React.Fragment key={i}>
              <line x1={i*cellPx} y1={0} x2={i*cellPx} y2={size} stroke="rgba(255,255,255,0.04)" strokeWidth=".5"/>
              <line x1={0} y1={i*cellPx} x2={size} y2={i*cellPx} stroke="rgba(255,255,255,0.04)" strokeWidth=".5"/>
            </React.Fragment>
          ))}
        </svg>
        {/* Region labels */}
        {cellPx >= 20 && REGIONS.map(r => {
          const c=r.cells[0], col=c%COLS, row=Math.floor(c/COLS);
          return (
            <div key={r.id+'-l'} style={{ position:'absolute', left:col*cellPx+2, top:row*cellPx+1,
              fontSize:Math.min(7,cellPx*0.28), color:r.color, fontFamily:E.mono, pointerEvents:'none',
              whiteSpace:'nowrap', overflow:'hidden', maxWidth:r.cells.length*cellPx-4, opacity:.85 }}>
              {r.label}
            </div>
          );
        })}
        {/* Selected highlight */}
        <div style={{ position:'absolute', left:(selCell%COLS)*cellPx, top:Math.floor(selCell/COLS)*cellPx,
          width:cellPx, height:cellPx, outline:`2px solid ${E.accent}`, outlineOffset:-1,
          boxSizing:'border-box', pointerEvents:'none', zIndex:5 }}/>
        {/* Click targets */}
        {Array.from({length:COLS*COLS}).map((_,c) => {
          const col=c%COLS, row=Math.floor(c/COLS);
          return (
            <div key={c} onClick={() => pick(c)}
              onMouseEnter={() => setHovReg(CELL_MAP[c]?.id||null)}
              onMouseLeave={() => setHovReg(null)}
              style={{ position:'absolute', left:col*cellPx, top:row*cellPx,
                width:cellPx, height:cellPx, cursor:'pointer' }}/>
          );
        })}
      </div>
    </div>
  );
}

// ─── FrameStrip ─────────────────────────────────────────────────────────────
function FrameStrip({ thumbPx = 44 }) {
  const [active, setActive] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [fps, setFps] = useState(8);
  const [onion, setOnion] = useState(false);
  return (
    <div style={{ background:E.panel, borderTop:`1px solid ${E.border}`, padding:'7px 10px', flexShrink:0 }}>
      <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:6 }}>
        <PlayBtn playing={playing} onToggle={() => setPlaying(p=>!p)}/>
        <TogBtn on={onion} onClick={() => setOnion(o=>!o)}>Onion</TogBtn>
        <div style={{ display:'flex', alignItems:'center', gap:4 }}>
          <span style={{ fontSize:9, color:E.txtMute, fontFamily:E.font }}>FPS</span>
          <input type="number" min={1} max={30} value={fps} onChange={e=>setFps(+e.target.value||8)}
            style={{ width:36, padding:'2px 4px', fontSize:10, fontFamily:E.mono,
              background:E.surface2, border:`1px solid ${E.border}`, borderRadius:4,
              color:E.txt, textAlign:'center' }}/>
        </div>
        <div style={{ flex:1 }}/>
        <span style={{ fontSize:9, color:E.txtFaint, fontFamily:E.mono }}>{active+1}/{FRAMES.length}</span>
      </div>
      <div style={{ display:'flex', gap:4, overflowX:'auto' }}>
        {FRAMES.map((f,i) => (
          <div key={i} onClick={() => setActive(i)}
            style={{ width:thumbPx, height:thumbPx, flexShrink:0, borderRadius:4, overflow:'hidden',
              border:`2px solid ${active===i ? E.accent : E.border}`, cursor:'pointer',
              position:'relative', background:E.canvasBg }}>
            <SpriteCanvas data={f} px={thumbPx} grid={false}/>
            <span style={{ position:'absolute', bottom:1, right:2, fontSize:7,
              color: active===i ? E.accent : E.txtFaint, fontFamily:E.mono }}>{i+1}</span>
          </div>
        ))}
        <button style={{ width:thumbPx, height:thumbPx, flexShrink:0, borderRadius:4,
          border:`2px dashed ${E.border}`, background:'transparent', color:E.txtMute,
          cursor:'pointer', fontSize:20, display:'flex', alignItems:'center', justifyContent:'center' }}>+</button>
      </div>
    </div>
  );
}

// ─── EditorHeader ────────────────────────────────────────────────────────────
function EditorHeader({ subtitle }) {
  return (
    <div style={{ height:48, display:'flex', alignItems:'center', gap:8, padding:'0 14px',
      background:E.panel, borderBottom:`1px solid ${E.border}`, flexShrink:0 }}>
      {/* Pi3 logo mark */}
      <span style={{ fontFamily:"'Nunito',system-ui,sans-serif", fontWeight:800, fontSize:15, color:E.accent, letterSpacing:-0.5, flexShrink:0 }}>
        pi<sup style={{ fontSize:'0.6em', verticalAlign:'0.1em' }}>3</sup>
      </span>
      <div style={{ width:1, height:20, background:E.border }}/>
      <span style={{ fontSize:10, color:E.txtMute, fontFamily:E.font }}>sprites /</span>
      <input defaultValue="hero_idle" style={{ background:'transparent', border:'none', outline:'none',
        fontSize:13, fontFamily:E.mono, color:E.txt, fontWeight:600, padding:'2px 4px', width:120 }}/>
      {subtitle && <span style={{ fontSize:9, color:E.txtFaint, fontFamily:E.font }}>{subtitle}</span>}
      <div style={{ width:1, height:20, background:E.border }}/>
      {['16×16','32×32'].map((s,i) => (
        <button key={s} style={{ padding:'2px 7px', fontSize:9, borderRadius:99,
          background:i===0?E.accentSoft:'transparent', border:`1px solid ${i===0?E.accentLine:E.border}`,
          color:i===0?E.accent:E.txtMute, cursor:'pointer', fontFamily:E.mono }}>{s}</button>
      ))}
      <div style={{ width:1, height:20, background:E.border }}/>
      {['50%','100%','200%','400%'].map((z,i) => (
        <button key={z} style={{ padding:'2px 6px', fontSize:9, borderRadius:3,
          background:i===1?E.surface2:'transparent', border:`1px solid ${i===1?E.borderMid:'transparent'}`,
          color:i===1?E.txt:E.txtFaint, cursor:'pointer', fontFamily:E.mono }}>{z}</button>
      ))}
      <div style={{ flex:1 }}/>
      {['↩','↪'].map((s,i) => (
        <button key={i} style={{ width:28, height:28, borderRadius:6, background:'transparent',
          border:`1px solid ${E.border}`, color:E.txtMute, cursor:'pointer', fontSize:13,
          display:'flex', alignItems:'center', justifyContent:'center' }}>{s}</button>
      ))}
      <div style={{ width:1, height:20, background:E.border }}/>
      <button style={{ padding:'5px 12px', borderRadius:6, background:'transparent',
        border:`1px solid ${E.border}`, color:E.txtMute, cursor:'pointer', fontSize:11, fontFamily:E.font }}>
        Cancel
      </button>
      <button style={{ padding:'5px 14px', borderRadius:6, background:E.accent,
        border:'none', color:'#fff', cursor:'pointer', fontSize:11, fontFamily:E.font, fontWeight:600 }}>
        Save
      </button>
    </div>
  );
}

// ─── Small helpers ────────────────────────────────────────────────────────────
function SLabel({ text, right }) {
  return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:6 }}>
      <span style={{ fontSize:9, color:E.txtMute, fontFamily:E.font, textTransform:'uppercase',
        letterSpacing:'.08em', fontWeight:600 }}>{text}</span>
      {right}
    </div>
  );
}
function PlayBtn({ playing, onToggle }) {
  return (
    <button onClick={onToggle} style={{ width:28, height:28, display:'flex', alignItems:'center',
      justifyContent:'center', borderRadius:6, background:playing?E.accentSoft:E.surface2,
      border:`1px solid ${playing?E.accentLine:E.border}`, color:playing?E.accent:E.txtMute, cursor:'pointer' }}>
      <svg width={12} height={12} viewBox="0 0 16 16" fill="currentColor">
        {playing
          ? <><rect x="3" y="3" width="4" height="10" rx="1"/><rect x="9" y="3" width="4" height="10" rx="1"/></>
          : <path d="M5 3l9 5-9 5V3z"/>}
      </svg>
    </button>
  );
}
function TogBtn({ on, onClick, children }) {
  return (
    <button onClick={onClick} style={{ padding:'3px 8px', fontSize:9, borderRadius:5,
      background:on?E.accentSoft:'transparent', border:`1px solid ${on?E.accentLine:E.border}`,
      color:on?E.accent:E.txtMute, cursor:'pointer', fontFamily:E.font }}>
      {children}
    </button>
  );
}

// Export everything to window
// ─── 64×64 sprite (scale F0_32 × 2) ─────────────────────────────────────────
const F0_64 = Array.from({length:64}, (_,y) =>
  Array.from({length:64}, (_,x) => F0_32[Math.floor(y/2)][Math.floor(x/2)])
);

// ─── Sprite → animations data model ──────────────────────────────────────────
const SPRITES_DATA = [
  { id:'hero', color:'#0e9aa7', size:'16×16', animations:[
    { id:'idle', frames:4, color:'#0e9aa7' },
    { id:'run',  frames:4, color:'#f6a560' },
    { id:'jump', frames:3, color:'#9b6dff' },
  ]},
  { id:'coin', color:'#38b764', size:'16×16', animations:[
    { id:'spin', frames:4, color:'#38b764' },
  ]},
  { id:'platform', color:'#ffcd75', size:'32×32', animations:[
    { id:'idle', frames:1, color:'#ffcd75' },
  ]},
];
// Sprite zone: 1000×160  |  Background zone: 1000×1000 below
const MIXED_REGIONS = [
  { id:'hero_idle',   x:0,   y:0,   w:256, h:64, color:'#0e9aa7', label:'hero_idle',  size:'64×64', frames:4 },
  { id:'hero_run',    x:256, y:0,   w:256, h:64, color:'#f6a560', label:'hero_run',   size:'64×64', frames:4 },
  { id:'boss',        x:512, y:0,   w:192, h:64, color:'#9b6dff', label:'boss',       size:'64×64', frames:3 },
  { id:'coin',        x:0,   y:80,  w:128, h:32, color:'#38b764', label:'coin',       size:'32×32', frames:4 },
  { id:'tiles',       x:128, y:80,  w:320, h:32, color:'#ffcd75', label:'tiles',      size:'32×32', frames:10 },
  { id:'background',  x:0,   y:172, w:1000,h:1000,color:'#4a90d9', label:'background', size:'1000×1000', frames:1 },
];

// ─── BackgroundPreview — simple painted landscape placeholder ─────────────────
function BackgroundPreview({ w = 220, h = 130 }) {
  const ref = useRef(null);
  useEffect(() => {
    const cv = ref.current; if (!cv) return;
    const ctx = cv.getContext('2d');

    // Sky
    const sky = ctx.createLinearGradient(0, 0, 0, h * 0.6);
    sky.addColorStop(0, '#0e1a2e'); sky.addColorStop(1, '#1e4a7a');
    ctx.fillStyle = sky; ctx.fillRect(0, 0, w, h * 0.6);

    // Stars
    ctx.fillStyle = '#f4f4f4';
    [[0.15,0.08],[0.3,0.15],[0.55,0.06],[0.7,0.2],[0.85,0.1],[0.42,0.22]]
      .forEach(([px,py]) => ctx.fillRect(px*w-1, py*h-1, 2, 2));

    // Distant mountains
    ctx.fillStyle = '#1e3d55';
    [[0.1,0.45],[0.28,0.32],[0.5,0.42],[0.72,0.3],[0.9,0.44]].forEach(([mx,my]) => {
      ctx.beginPath(); ctx.moveTo(mx*w-50,h*0.6); ctx.lineTo(mx*w,my*h); ctx.lineTo(mx*w+50,h*0.6);
      ctx.fill();
    });

    // Ground gradient
    const gnd = ctx.createLinearGradient(0, h*0.6, 0, h);
    gnd.addColorStop(0, '#2d5a20'); gnd.addColorStop(1, '#1a3310');
    ctx.fillStyle = gnd; ctx.fillRect(0, h*0.6, w, h*0.4);

    // Ground details — grass tufts
    ctx.fillStyle = '#3a7a28';
    for (let gx = 0; gx < w; gx += 18) {
      ctx.fillRect(gx, h*0.6-2, 3, 5);
      ctx.fillRect(gx+6, h*0.6-3, 2, 4);
    }

    // Size overlay
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    ctx.fillRect(0, h-18, w, 18);
    ctx.fillStyle = '#94b0c2'; ctx.font = `9px 'JetBrains Mono', monospace`;
    ctx.fillText('1000×1000', 5, h-5);
  }, [w, h]);
  return <canvas ref={ref} width={w} height={h} style={{ display:'block' }}/>;
}

// ─── MixedSheetNavigator — two-zone: sprite strip + background block ──────────
function MixedSheetNavigator({ selected = 'hero_idle', onSelect }) {  
  const [sel, setSel] = useState(selected);
  const [hovId, setHovId] = useState(null);
  const SHEET_W = 1000;
  const NAV_W = 222;
  const sprScale = NAV_W / SHEET_W;          // 0.222
  const SPRITE_ZONE_H = 160;
  const sprNavH = Math.round(SPRITE_ZONE_H * sprScale); // ~36px

  const sprites = MIXED_REGIONS.filter(r => r.id !== 'background');
  const bg = MIXED_REGIONS.find(r => r.id === 'background');

  const pick = (id) => { setSel(id); onSelect?.(id); };

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
      <SLabel text="Sheet" right={
        <span style={{ fontSize:9, color:E.txtFaint, fontFamily:E.mono }}>1000×1172</span>
      }/>

      {/* ─ Sprites zone ─ */}
      <div>
        <div style={{ display:'flex', alignItems:'center', gap:5, marginBottom:4 }}>
          <span style={{ fontSize:8, color:E.txtMute, fontFamily:E.font, textTransform:'uppercase',
            letterSpacing:'.06em', fontWeight:600 }}>Sprites</span>
          <span style={{ fontSize:8, color:E.txtFaint, fontFamily:E.mono }}>1000×160</span>
          <div style={{ flex:1 }}/>
          <span style={{ fontSize:8, color:E.txtFaint, fontFamily:E.font }}>{sprites.length} regions</span>
        </div>
        <div style={{ position:'relative', width:NAV_W, height:sprNavH,
          background:E.canvasBg, border:`1px solid ${E.borderMid}`,
          borderRadius:4, overflow:'hidden' }}>
          {/* Grid lines for 64px cells */}
          <svg width={NAV_W} height={sprNavH} style={{ position:'absolute', inset:0, pointerEvents:'none' }}>
            {Array.from({length:16}).map((_,i) => (
              <line key={i} x1={i*64*sprScale} y1={0} x2={i*64*sprScale} y2={sprNavH}
                stroke="rgba(255,255,255,0.04)" strokeWidth=".5"/>
            ))}
            {[80].map(y => (
              <line key={y} x1={0} y1={y*sprScale} x2={NAV_W} y2={y*sprScale}
                stroke="rgba(255,255,255,0.04)" strokeWidth=".5"/>
            ))}
          </svg>
          {/* Region overlays */}
          {sprites.map(r => {
            const isActive = sel === r.id;
            const isHov = hovId === r.id;
            return (
              <div key={r.id}
                onClick={() => pick(r.id)}
                onMouseEnter={() => setHovId(r.id)}
                onMouseLeave={() => setHovId(null)}
                style={{ position:'absolute',
                  left: r.x * sprScale, top: r.y * sprScale,
                  width: r.w * sprScale, height: r.h * sprScale,
                  background: isHov ? r.color+'35' : r.color+'1c',
                  border:`1px solid ${r.color}${isActive?'aa':'44'}`,
                  cursor:'pointer', boxSizing:'border-box',
                  outline: isActive ? `2px solid ${r.color}` : 'none',
                  outlineOffset: -1, transition:'background .1s' }}>
                {r.w * sprScale >= 18 && (
                  <span style={{ fontSize: Math.min(7, r.h*sprScale*.4), color:r.color,
                    fontFamily:E.mono, position:'absolute', top:1, left:2,
                    pointerEvents:'none', whiteSpace:'nowrap', overflow:'hidden',
                    maxWidth: r.w*sprScale-4 }}>{r.label}</span>
                )}
              </div>
            );
          })}
        </div>
        {/* Sprite legend */}
        <div style={{ display:'flex', flexWrap:'wrap', gap:3, marginTop:5 }}>
          {sprites.map(r => (
            <div key={r.id} onMouseEnter={() => setHovId(r.id)} onMouseLeave={() => setHovId(null)}
              onClick={() => pick(r.id)}
              style={{ display:'flex', alignItems:'center', gap:3, padding:'1px 5px',
                borderRadius:99, cursor:'pointer',
                background: sel===r.id ? r.color+'22' : r.color+'10',
                border:`1px solid ${sel===r.id ? r.color+'66' : r.color+'30'}` }}>
              <div style={{ width:5, height:5, borderRadius:1, background:r.color }}/>
              <span style={{ fontSize:7.5, color:r.color, fontFamily:E.mono }}>{r.label}</span>
              <span style={{ fontSize:7, color:E.txtFaint, fontFamily:E.mono }}>·{r.size}</span>
            </div>
          ))}
        </div>
      </div>

      {/* ─ Scale bridge indicator ─ */}
      <div style={{ display:'flex', alignItems:'center', gap:6 }}>
        <div style={{ flex:1, height:1, background:E.border }}/>
        <span style={{ fontSize:8, color:E.txtFaint, fontFamily:E.mono, flexShrink:0 }}>×6.25 scale jump</span>
        <div style={{ flex:1, height:1, background:E.border }}/>
      </div>

      {/* ─ Background zone ─ */}
      <div>
        <div style={{ display:'flex', alignItems:'center', gap:5, marginBottom:4 }}>
          <span style={{ fontSize:8, color:E.txtMute, fontFamily:E.font, textTransform:'uppercase',
            letterSpacing:'.06em', fontWeight:600 }}>Background</span>
          <span style={{ fontSize:8, color:E.txtFaint, fontFamily:E.mono }}>1000×1000</span>
          <div style={{ flex:1 }}/>
          <span style={{ padding:'1px 5px', borderRadius:99, fontSize:7, fontFamily:E.font,
            background:E.surface2, border:`1px solid ${E.border}`, color:E.txtFaint }}>large</span>
        </div>
        <div onClick={() => pick('background')}
          style={{ position:'relative', width:NAV_W, borderRadius:6, overflow:'hidden', cursor:'pointer',
            border:`2px solid ${sel==='background' ? bg.color : E.border}`,
            boxSizing:'border-box', transition:'border-color .15s' }}>
          <BackgroundPreview w={NAV_W} h={Math.round(NAV_W * 0.52)}/>
          {/* Info overlay */}
          <div style={{ position:'absolute', inset:0,
            background:'linear-gradient(to bottom, transparent 40%, rgba(0,0,0,0.65))',
            pointerEvents:'none' }}>
            <div style={{ position:'absolute', bottom:6, left:8, display:'flex', flexDirection:'column', gap:1 }}>
              <span style={{ fontSize:10, color:bg.color, fontFamily:E.mono, fontWeight:600 }}>background</span>
              <span style={{ fontSize:8, color:'rgba(200,210,220,0.7)', fontFamily:E.mono }}>1000×1000 · PNG</span>
            </div>
            {sel==='background' && (
              <div style={{ position:'absolute', top:6, right:6, padding:'2px 6px',
                borderRadius:3, background:bg.color+'cc', fontSize:8, color:'#fff', fontFamily:E.font }}>✓ editing</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  E, SC, F0, F1, F2, F3, FRAMES, F0_32, F0_64, SHEET_CELLS, REGIONS, CELL_MAP,
  PAL, PAL_NAMES, hexLerp, MIXED_REGIONS, SPRITES_DATA,
  ToolIcon, SpriteCanvas, FullSheetCanvas, ToolStrip,
  LayerPanel, PalettePanel, ColorLerpPanel, SheetNavigator,
  MixedSheetNavigator, BackgroundPreview,
  FrameStrip, EditorHeader, SLabel, PlayBtn, TogBtn,
});
