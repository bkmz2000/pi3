/* global React, T, Avatar, RoleTag, Icon, Pi3Logo */

// ─────────────────────────────────────────────────────────────────────────────
// 4. TEACHER DASHBOARD — classroom-first, queue-driven
// ─────────────────────────────────────────────────────────────────────────────

const QUEUE = [
  { id: "h1", name: "Linus Torvalds",  handle: "linus",     project: "Pong rebuild",   waited: "1m",  status: "new",        line: 42, msg: "AttributeError: 'Paddle' object has no attribute 'move'" },
  { id: "h2", name: "Margaret Hamilton", handle: "mhamilton", project: "Lunar lander",  waited: "4m",  status: "in_progress", line: 18, msg: "stuck on the gravity loop" },
  { id: "h3", name: "Katherine Johnson", handle: "kj",      project: "Orbit sim",       waited: "9m",  status: "new",        line: 73, msg: "" },
];

function StatusBadge({ s }) {
  if (s === "new") {
    return (
      <span style={{
        display: "inline-flex", alignItems: "center", gap: 5,
        padding: "3px 9px 3px 7px", borderRadius: T.rPill,
        background: T.hand, color: "#fff",
        fontSize: 10.5, fontWeight: 700, letterSpacing: 0.3, textTransform: "uppercase",
      }}>
        <span style={{ width: 6, height: 6, borderRadius: T.rPill, background: "#fff" }} />
        New
      </span>
    );
  }
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      padding: "3px 9px 3px 7px", borderRadius: T.rPill,
      background: T.tealSoft, color: T.tealDeep,
      fontSize: 10.5, fontWeight: 700, letterSpacing: 0.3, textTransform: "uppercase",
    }}>
      <span style={{ width: 6, height: 6, borderRadius: T.rPill, background: T.teal }} />
      Helping
    </span>
  );
}

function MiniRail({ active }) {
  const items = [
    { id: "now",      icon: "spark",  label: "Now",       badge: 3 },
    { id: "students", icon: "users",  label: "Students" },
    { id: "groups",   icon: "folder", label: "Groups" },
    { id: "shared",   icon: "folder", label: "Shared work" },
  ];
  return (
    <div style={{
      width: 196, flex: "none",
      background: T.panel,
      borderRight: `1px solid ${T.border}`,
      padding: "20px 12px",
      display: "flex", flexDirection: "column", gap: 4,
      fontFamily: T.fontUI,
    }}>
      <div style={{
        padding: "0 8px 14px",
        fontSize: 10.5, fontWeight: 700, color: T.txtMute, letterSpacing: 0.6, textTransform: "uppercase",
      }}>Classroom</div>
      {items.map(it => (
        <button key={it.id} style={{
          all: "unset", cursor: "pointer",
          display: "flex", alignItems: "center", gap: 10,
          padding: "8px 10px", borderRadius: 7,
          background: active === it.id ? T.tealSoft : "transparent",
          color: active === it.id ? T.tealDeep : T.txt,
          fontSize: 13, fontWeight: active === it.id ? 700 : 500,
        }}>
          <Icon name={it.icon} size={14} color={active === it.id ? T.teal : T.txtMute} />
          <span style={{ flex: 1 }}>{it.label}</span>
          {it.badge && (
            <span style={{
              minWidth: 18, padding: "0 6px", height: 18,
              borderRadius: T.rPill, background: T.hand, color: "#fff",
              display: "inline-flex", alignItems: "center", justifyContent: "center",
              fontFamily: T.fontMono, fontSize: 10.5, fontWeight: 700,
            }}>{it.badge}</span>
          )}
        </button>
      ))}
      <div style={{ height: 1, background: T.border, margin: "12px 8px" }} />
      <div style={{
        padding: "0 8px 8px",
        fontSize: 10.5, fontWeight: 700, color: T.txtMute, letterSpacing: 0.6, textTransform: "uppercase",
      }}>Your classes</div>
      {["Period 4 · Algorithms", "Period 6 · Intro Py", "After-school club"].map((c, i) => (
        <button key={c} style={{
          all: "unset", cursor: "pointer",
          display: "flex", alignItems: "center", gap: 8,
          padding: "7px 10px", borderRadius: 6,
          color: i === 0 ? T.txt : T.txtMute,
          fontSize: 12.5, fontWeight: i === 0 ? 600 : 500,
        }}>
          <span style={{
            width: 6, height: 6, borderRadius: T.rPill,
            background: i === 0 ? T.teal : T.border,
          }} />
          {c}
        </button>
      ))}
    </div>
  );
}

function QueueCard({ item, selected, onSelect }) {
  return (
    <div onClick={() => onSelect(item.id)} style={{
      cursor: "pointer",
      padding: "12px 14px",
      borderRadius: T.rCard,
      background: selected ? T.panel : "transparent",
      border: `1px solid ${selected ? T.tealLine : T.border}`,
      boxShadow: selected ? `0 0 0 3px ${T.tealSoft}` : "none",
      display: "flex", flexDirection: "column", gap: 8,
      transition: "all 0.12s",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <Avatar name={item.name} role="student" size={30} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13.5, fontWeight: 700, color: T.txt }}>{item.name}</div>
          <div style={{ fontSize: 11.5, color: T.txtMute, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{item.project}</div>
        </div>
        <StatusBadge s={item.status} />
      </div>
      {item.msg && (
        <div style={{
          fontFamily: T.fontMono, fontSize: 11, color: T.txtMute,
          background: T.surface, padding: "6px 9px", borderRadius: 6,
          border: `1px solid ${T.border}`,
          overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
        }}>L{item.line}: {item.msg}</div>
      )}
      <div style={{
        display: "flex", alignItems: "center", gap: 8,
        fontSize: 11, color: T.txtMute,
      }}>
        <span style={{ fontFamily: T.fontMono }}>waited {item.waited}</span>
      </div>
    </div>
  );
}

function NowSection() {
  const [selected, setSelected] = React.useState(QUEUE[0].id);
  const cur = QUEUE.find(q => q.id === selected) || QUEUE[0];

  return (
    <div style={{ display: "grid", gridTemplateColumns: "340px 1fr", gap: 0, flex: 1, overflow: "hidden" }}>
      {/* Queue column */}
      <div style={{
        background: T.surface,
        borderRight: `1px solid ${T.border}`,
        overflow: "auto",
        padding: "22px 18px",
        display: "flex", flexDirection: "column", gap: 14,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <Icon name="hand" size={16} color={T.hand} />
          <span style={{ fontSize: 15, fontWeight: 800, color: T.txt }}>Help queue</span>
          <span style={{
            padding: "1px 8px", borderRadius: T.rPill,
            background: T.hand, color: "#fff",
            fontFamily: T.fontMono, fontSize: 11, fontWeight: 700,
          }}>{QUEUE.length}</span>
          <div style={{ flex: 1 }} />
          <span style={{ fontSize: 11, color: T.txtMute, fontFamily: T.fontMono }}>
            updated 5s ago
          </span>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {QUEUE.map(q => (
            <QueueCard key={q.id} item={q} selected={selected === q.id} onSelect={setSelected} />
          ))}
        </div>

        {/* Pulse strip — classroom heartbeat */}
        <div style={{ marginTop: 6 }}>
          <div style={{
            fontSize: 10.5, fontWeight: 700, color: T.txtMute, letterSpacing: 0.6, textTransform: "uppercase",
            marginBottom: 8,
          }}>Class pulse</div>
          <div style={{
            background: T.panel, border: `1px solid ${T.border}`,
            borderRadius: T.rCard, padding: 14,
            display: "flex", flexDirection: "column", gap: 10,
          }}>
            {[
              { label: "Running code",  v: 17, total: 24, color: T.ok },
              { label: "Errors hit",    v: 6,  total: 24, color: T.warn },
              { label: "Idle > 5 min",  v: 3,  total: 24, color: T.txtMute },
            ].map(row => (
              <div key={row.label}>
                <div style={{ display: "flex", alignItems: "center", marginBottom: 4 }}>
                  <span style={{ flex: 1, fontSize: 12, color: T.txt }}>{row.label}</span>
                  <span style={{ fontFamily: T.fontMono, fontSize: 11.5, color: T.txtMute }}>{row.v}/{row.total}</span>
                </div>
                <div style={{
                  height: 5, background: T.chip, borderRadius: T.rPill, overflow: "hidden",
                }}>
                  <div style={{
                    width: `${(row.v / row.total) * 100}%`, height: "100%",
                    background: row.color, borderRadius: T.rPill,
                  }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Detail column */}
      <div style={{ overflow: "auto", padding: "22px 28px 28px" }}>
        {/* Student header */}
        <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 18 }}>
          <Avatar name={cur.name} role="student" size={52} />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: T.txtMute, letterSpacing: 0.5, textTransform: "uppercase" }}>
              Helping
            </div>
            <div style={{ fontSize: 22, fontWeight: 800, color: T.txt, letterSpacing: -0.3 }}>
              {cur.name}
            </div>
            <div style={{ fontSize: 12.5, color: T.txtMute, marginTop: 2, display: "flex", alignItems: "center", gap: 8 }}>
              <Icon name="folder" size={12} />
              {cur.project}
              <span style={{ width: 3, height: 3, borderRadius: T.rPill, background: T.txtFaint }} />
              <span style={{ fontFamily: T.fontMono }}>waited {cur.waited}</span>
            </div>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button style={{
              all: "unset", cursor: "pointer",
              padding: "9px 14px", borderRadius: 7,
              background: T.panel, border: `1px solid ${T.border}`,
              color: T.txt, fontSize: 13, fontWeight: 600,
            }}>Mark helping</button>
            <button style={{
              all: "unset", cursor: "pointer",
              padding: "9px 18px", borderRadius: 7,
              background: T.ok, color: "#fff",
              fontSize: 13, fontWeight: 700,
              display: "inline-flex", alignItems: "center", gap: 6,
            }}>
              <Icon name="check" size={12} color="#fff" />
              Resolve
            </button>
          </div>
        </div>

        {/* Student message */}
        {cur.msg && (
          <div style={{
            background: T.panel, border: `1px solid ${T.border}`,
            borderRadius: T.rCard, padding: "14px 16px", marginBottom: 14,
            display: "flex", gap: 10,
          }}>
            <Icon name="hand" size={14} color={T.hand} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 11, color: T.txtMute, marginBottom: 2 }}>Student note</div>
              <div style={{ fontSize: 13.5, color: T.txt, fontFamily: T.fontMono }}>
                line {cur.line} · {cur.msg}
              </div>
            </div>
          </div>
        )}

        {/* Code preview */}
        <div style={{
          background: "#fffaf0", border: `1px solid ${T.border}`,
          borderRadius: T.rCard, overflow: "hidden", marginBottom: 14,
        }}>
          <div style={{
            display: "flex", alignItems: "center", gap: 8,
            padding: "10px 14px", borderBottom: `1px solid ${T.border}`,
            background: T.panelHeader,
          }}>
            <Icon name="folder" size={12} color={T.txtMute} />
            <span style={{ fontFamily: T.fontMono, fontSize: 12, color: T.txt }}>main.py</span>
            <span style={{ flex: 1 }} />
            <span style={{
              padding: "2px 8px", borderRadius: T.rPill,
              background: T.dangerSoft, color: T.danger,
              fontSize: 10.5, fontWeight: 700,
              fontFamily: T.fontMono,
            }}>error · L{cur.line}</span>
          </div>
          <pre style={{
            margin: 0, padding: "14px 18px",
            fontFamily: T.fontMono, fontSize: 12.5, lineHeight: 1.65,
            color: T.txt, whiteSpace: "pre",
            overflow: "auto",
          }}>
{`  ${cur.line - 2}  def update(self):
  ${cur.line - 1}      if self.dy != 0:
  ${cur.line}      `}<span style={{ background: T.dangerSoft, padding: "1px 3px", borderRadius: 3 }}>self.move(self.dy)</span>{`
  ${cur.line + 1}      self.y += self.dy
  ${cur.line + 2}      self.draw()`}
          </pre>
        </div>

        {/* Quick actions */}
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {[
            { label: "Open in editor",  primary: true },
            { label: "Send hint" },
            { label: "Start screen-share" },
            { label: "Comment on line" },
          ].map(b => (
            <button key={b.label} style={{
              all: "unset", cursor: "pointer",
              padding: "8px 14px", borderRadius: 7,
              background: b.primary ? T.tealDeep : T.panel,
              color: b.primary ? "#fffaf0" : T.txt,
              border: b.primary ? "none" : `1px solid ${T.border}`,
              fontSize: 12.5, fontWeight: b.primary ? 700 : 600,
            }}>{b.label}</button>
          ))}
        </div>
      </div>
    </div>
  );
}

function TeacherDashboard() {
  const user = { name: "ghopper", displayName: "Ms. Hopper", role: "teacher" };
  return (
    <div style={{
      width: "100%", height: "100%", background: T.surface,
      fontFamily: T.fontUI, display: "flex", flexDirection: "column",
    }}>
      {/* Top bar */}
      <div style={{
        height: 56, flex: "none",
        display: "flex", alignItems: "center",
        padding: "0 24px", gap: 14,
        background: T.panel,
        borderBottom: `1px solid ${T.border}`,
      }}>
        <button style={{
          all: "unset", cursor: "pointer",
          display: "inline-flex", alignItems: "center", gap: 6,
          color: T.txtMute, fontSize: 12.5, fontWeight: 500,
          padding: "6px 10px 6px 8px", borderRadius: 6,
        }}>
          <Icon name="back" size={12} />
          Back to editor
        </button>
        <div style={{ width: 1, height: 20, background: T.border }} />
        <Pi3Logo size={20} />
        <span style={{
          padding: "3px 8px", borderRadius: T.rPill,
          background: T.tealSoft, color: T.tealDeep,
          fontSize: 11, fontWeight: 700, letterSpacing: 0.3, textTransform: "uppercase",
        }}>Teacher</span>

        {/* Live class chip */}
        <div style={{
          marginLeft: 12,
          display: "inline-flex", alignItems: "center", gap: 8,
          padding: "5px 12px 5px 10px", borderRadius: T.rPill,
          background: T.okSoft, color: T.ok,
          fontSize: 12, fontWeight: 700,
        }}>
          <span style={{
            width: 7, height: 7, borderRadius: T.rPill, background: T.ok,
            boxShadow: `0 0 0 4px ${T.okSoft}`,
          }} />
          Period 4 · live
          <span style={{ color: T.txtMute, fontFamily: T.fontMono, fontWeight: 600 }}>21/24</span>
        </div>

        <div style={{ flex: 1 }} />

        {/* Bell */}
        <button style={{
          all: "unset", cursor: "pointer", position: "relative",
          width: 32, height: 32, borderRadius: 7,
          display: "inline-flex", alignItems: "center", justifyContent: "center",
          color: T.txtMute, background: T.surface, border: `1px solid ${T.border}`,
        }}>
          <Icon name="bell" size={14} />
          <span style={{
            position: "absolute", top: 4, right: 4,
            width: 8, height: 8, borderRadius: T.rPill,
            background: T.hand, border: `2px solid ${T.panel}`,
          }} />
        </button>

        {/* User pill */}
        <div style={{
          display: "inline-flex", alignItems: "center", gap: 9,
          padding: "4px 11px 4px 4px", borderRadius: T.rPill,
          background: T.surface, border: `1px solid ${T.border}`,
        }}>
          <Avatar name={user.name} role={user.role} size={24} />
          <span style={{ display: "flex", flexDirection: "column", lineHeight: 1.1 }}>
            <span style={{ fontSize: 12.5, fontWeight: 600, color: T.txt }}>{user.displayName}</span>
            <span style={{
              fontSize: 9.5, fontWeight: 700, letterSpacing: 0.3, textTransform: "uppercase",
              color: T.teal, marginTop: 1,
            }}>Teacher</span>
          </span>
        </div>
      </div>

      <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>
        <MiniRail active="now" />
        <NowSection />
      </div>
    </div>
  );
}

window.TeacherDashboard = TeacherDashboard;
