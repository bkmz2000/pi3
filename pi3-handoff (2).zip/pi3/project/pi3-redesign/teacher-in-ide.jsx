/* global React, T, Avatar, RoleTag, Icon, Pi3Logo */

// ─────────────────────────────────────────────────────────────────────────────
// TEACHER IN THE IDE
// Same shell as the student IDE — two states:
//   A) Classroom home — editor area becomes a live class grid
//   B) Reviewing a student — editor loads their code, teacher tools active
// ─────────────────────────────────────────────────────────────────────────────

// ── Shared data ───────────────────────────────────────────────────────────────

const STUDENTS = [
  { name: "Ada Lovelace",     handle: "ada",       status: "coding",  project: "Snake game",    errors: 0, help: false, lastLine: 42, runtime: "3m" },
  { name: "Linus Torvalds",   handle: "linus",     status: "help",    project: "Pong rebuild",  errors: 1, help: true,  lastLine: 24, runtime: "8m" },
  { name: "Grace Hopper",     handle: "grace",     status: "coding",  project: "Orbit sim",     errors: 0, help: false, lastLine: 18, runtime: "12m" },
  { name: "Alan Turing",      handle: "turing",    status: "idle",    project: "Number guesser",errors: 0, help: false, lastLine: 7,  runtime: null  },
  { name: "Margaret Hamilton",handle: "mhamilton", status: "help",    project: "Lunar lander",  errors: 2, help: true,  lastLine: 61, runtime: "5m"  },
  { name: "Donald Knuth",     handle: "knuth",     status: "error",   project: "Fractal tree",  errors: 3, help: false, lastLine: 33, runtime: "1m"  },
  { name: "Barbara Liskov",   handle: "liskov",    status: "coding",  project: "Chat bot",      errors: 0, help: false, lastLine: 88, runtime: "6m"  },
  { name: "Tim Berners-Lee",  handle: "tbl",       status: "offline", project: "Fractal tree",  errors: 0, help: false, lastLine: 0,  runtime: null  },
  { name: "Katherine Johnson",handle: "kj",        status: "coding",  project: "Orbit sim",     errors: 0, help: false, lastLine: 29, runtime: "9m"  },
  { name: "John von Neumann", handle: "jvn",       status: "idle",    project: "Snake game",    errors: 0, help: false, lastLine: 5,  runtime: null  },
  { name: "Hedy Lamarr",      handle: "hedy",      status: "coding",  project: "Pixel painter", errors: 0, help: false, lastLine: 54, runtime: "4m"  },
  { name: "Edsger Dijkstra",  handle: "edsger",    status: "error",   project: "Path finder",   errors: 1, help: false, lastLine: 77, runtime: "2m"  },
];

const STATUS_MAP = {
  coding:  { label: "Coding",   dot: "#34a853", bg: "transparent",   ring: false },
  help:    { label: "Hand up",  dot: T.hand,    bg: T.handSoft,      ring: true  },
  error:   { label: "Error",    dot: T.warn,    bg: T.warnSoft,      ring: false },
  idle:    { label: "Idle",     dot: T.txtFaint,bg: "transparent",   ring: false },
  offline: { label: "Offline",  dot: T.border,  bg: "transparent",   ring: false },
};

// ── Teacher rail class panel (reuse Proposal B teacher) ───────────────────────

function TeacherClassPanel({ onSelectStudent, selectedHandle }) {
  const hands = STUDENTS.filter(s => s.help);
  const online = STUDENTS.filter(s => s.status !== "offline");

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", overflow: "hidden", fontFamily: T.fontUI }}>
      {/* Header */}
      <div style={{
        padding: "14px 14px 10px",
        borderBottom: `1px solid ${T.border}`,
        background: T.panelHeader,
      }}>
        <div style={{ fontSize: 10.5, fontWeight: 700, color: T.txtMute, letterSpacing: 0.6, textTransform: "uppercase", marginBottom: 4 }}>Teaching</div>
        <div style={{ fontSize: 15, fontWeight: 800, color: T.txt, letterSpacing: -0.2, marginBottom: 2 }}>Period 4 · Algorithms</div>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ width: 7, height: 7, borderRadius: T.rPill, background: "#34a853" }} />
          <span style={{ fontSize: 11.5, color: T.txtMute }}>
            {online.length}/{STUDENTS.length} online
          </span>
        </div>
      </div>

      <div style={{ flex: 1, overflow: "auto", padding: "10px 8px" }}>
        {/* Class pulse */}
        <div style={{ marginBottom: 12 }}>
          {[
            { label: "Coding",   v: STUDENTS.filter(s=>s.status==="coding").length,  color: "#34a853" },
            { label: "Hands up", v: hands.length,                                    color: T.hand    },
            { label: "Errors",   v: STUDENTS.filter(s=>s.status==="error").length,   color: T.warn    },
          ].map(row => (
            <div key={row.label} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
              <span style={{ width: 7, height: 7, borderRadius: T.rPill, background: row.color, flex: "none" }} />
              <span style={{ flex: 1, fontSize: 12, color: T.txt }}>{row.label}</span>
              <span style={{ fontFamily: T.fontMono, fontSize: 11.5, color: T.txtMute, fontWeight: 700 }}>{row.v}</span>
            </div>
          ))}
        </div>

        {/* Hands up — prioritised */}
        {hands.length > 0 && (
          <div style={{ marginBottom: 12 }}>
            <div style={{
              fontSize: 10.5, fontWeight: 700, color: T.hand,
              letterSpacing: 0.6, textTransform: "uppercase", padding: "0 4px 6px",
            }}>Hands up</div>
            {hands.map(s => (
              <button key={s.handle} onClick={() => onSelectStudent(s.handle)} style={{
                all: "unset", cursor: "pointer",
                display: "flex", alignItems: "center", gap: 9,
                width: "100%", boxSizing: "border-box",
                padding: "7px 8px", borderRadius: 7, marginBottom: 2,
                background: selectedHandle === s.handle ? T.tealSoft : T.handSoft,
                border: `1px solid ${selectedHandle === s.handle ? T.tealLine : "transparent"}`,
              }}>
                <Avatar name={s.name} role="student" size={26} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 12.5, fontWeight: 700, color: T.txt, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{s.name}</div>
                  <div style={{ fontSize: 11, color: T.txtMute, fontFamily: T.fontMono, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{s.project}</div>
                </div>
                <span style={{
                  fontSize: 9.5, fontWeight: 700, padding: "2px 6px",
                  borderRadius: T.rPill, background: T.hand, color: "#fff",
                  flex: "none",
                }}>✋</span>
              </button>
            ))}
          </div>
        )}

        {/* All students */}
        <div>
          <div style={{
            fontSize: 10.5, fontWeight: 700, color: T.txtMute,
            letterSpacing: 0.6, textTransform: "uppercase", padding: "0 4px 6px",
          }}>All students</div>
          {STUDENTS.map(s => {
            const st = STATUS_MAP[s.status];
            return (
              <button key={s.handle} onClick={() => onSelectStudent(s.handle)} style={{
                all: "unset", cursor: "pointer",
                display: "flex", alignItems: "center", gap: 8,
                width: "100%", boxSizing: "border-box",
                padding: "5px 8px", borderRadius: 6, marginBottom: 1,
                background: selectedHandle === s.handle ? T.tealSoft : "transparent",
              }}>
                <div style={{ position: "relative", flex: "none" }}>
                  <Avatar name={s.name} role="student" size={22} />
                  <span style={{
                    position: "absolute", right: -1, bottom: -1,
                    width: 7, height: 7, borderRadius: T.rPill,
                    background: st.dot, border: `1.5px solid ${T.panel}`,
                  }} />
                </div>
                <span style={{
                  flex: 1, fontSize: 12, fontWeight: 500, color: T.txt,
                  overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
                }}>{s.name}</span>
                {s.errors > 0 && (
                  <span style={{
                    fontSize: 9.5, fontFamily: T.fontMono, fontWeight: 700,
                    color: T.warn, background: T.warnSoft,
                    padding: "1px 5px", borderRadius: 3,
                  }}>{s.errors}err</span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ── STATE A: Classroom grid (editor area) ─────────────────────────────────────

function StudentCard({ s, onSelect }) {
  const st = STATUS_MAP[s.status];
  return (
    <div
      onClick={() => onSelect(s.handle)}
      style={{
        background: st.bg !== "transparent" ? st.bg : T.panel,
        border: `1px solid ${s.help ? T.hand + "80" : s.status === "error" ? T.warn + "60" : T.border}`,
        borderRadius: T.rCard,
        padding: "12px",
        cursor: "pointer",
        display: "flex", flexDirection: "column", gap: 8,
        boxShadow: s.help ? `0 0 0 2px ${T.hand}30` : T.shadowCard,
        transition: "all 0.12s",
        position: "relative",
      }}
    >
      {/* Top row */}
      <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
        <div style={{ position: "relative", flex: "none" }}>
          <Avatar name={s.name} role="student" size={32} />
          <span style={{
            position: "absolute", right: -2, bottom: -2,
            width: 10, height: 10, borderRadius: T.rPill,
            background: st.dot, border: `2px solid ${st.bg !== "transparent" ? st.bg : T.panel}`,
          }} />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: T.txt, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{s.name}</div>
          <div style={{ fontSize: 11, color: T.txtMute, fontFamily: T.fontMono, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{s.project}</div>
        </div>
        {s.help && (
          <span style={{
            fontSize: 15, lineHeight: 1, flex: "none",
          }}>✋</span>
        )}
      </div>

      {/* Status / activity */}
      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <span style={{
          display: "inline-flex", alignItems: "center", gap: 5,
          padding: "2px 8px", borderRadius: T.rPill,
          background: s.status === "help" ? T.hand : s.status === "error" ? T.warn : s.status === "coding" ? "#34a85320" : T.chip,
          color: s.status === "help" || s.status === "error" ? "#fff" : s.status === "coding" ? "#0e7c52" : T.txtMute,
          fontSize: 10.5, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.3,
        }}>
          {st.label}
        </span>
        {s.runtime && (
          <span style={{ fontSize: 10.5, color: T.txtFaint, fontFamily: T.fontMono }}>
            running {s.runtime}
          </span>
        )}
        {s.errors > 0 && (
          <span style={{ fontSize: 10.5, color: T.warn, fontFamily: T.fontMono, marginLeft: "auto" }}>
            {s.errors} error{s.errors > 1 ? "s" : ""}
          </span>
        )}
      </div>
    </div>
  );
}

function ClassroomGrid({ onSelectStudent }) {
  return (
    <div style={{
      flex: 1, display: "flex", flexDirection: "column",
      background: T.surface, overflow: "hidden",
    }}>
      {/* "File bar" equivalent — class context */}
      <div style={{
        height: 40, flex: "none",
        display: "flex", alignItems: "center",
        background: "#0e9aa7",
        padding: "0 16px", gap: 12,
        fontFamily: T.fontUI,
      }}>
        <Pi3Logo size={16} color="#fffaf0" />
        <div style={{ width: 1, height: 16, background: "rgba(255,255,255,0.2)" }} />
        <span style={{ fontSize: 12.5, fontWeight: 700, color: "#fffaf0" }}>Period 4 · Algorithms</span>
        <div style={{
          display: "inline-flex", alignItems: "center", gap: 6,
          padding: "3px 10px", borderRadius: T.rPill,
          background: "rgba(255,255,255,0.15)",
          fontSize: 11.5, color: "#fffaf0", fontWeight: 700,
        }}>
          <span style={{ width: 6, height: 6, borderRadius: T.rPill, background: "#34a853" }} />
          Live · {STUDENTS.filter(s => s.status !== "offline").length} students
        </div>
        <div style={{ flex: 1 }} />
        {/* Sort/filter chips */}
        {["All", "Hands up", "Errors", "Idle"].map((f, i) => (
          <div key={f} style={{
            padding: "3px 10px", borderRadius: T.rPill,
            background: i === 0 ? "rgba(255,255,255,0.22)" : "transparent",
            border: "1px solid rgba(255,255,255,0.15)",
            fontSize: 11.5, color: i === 0 ? "#fffaf0" : "rgba(255,255,255,0.6)",
            fontWeight: i === 0 ? 700 : 500,
            cursor: "pointer",
          }}>{f}</div>
        ))}
      </div>

      {/* Grid */}
      <div style={{
        flex: 1, overflow: "auto",
        padding: "20px 20px 28px",
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill, minmax(210px, 1fr))",
        gap: 10,
        alignContent: "start",
      }}>
        {STUDENTS.map(s => (
          <StudentCard key={s.handle} s={s} onSelect={onSelectStudent} />
        ))}
      </div>
    </div>
  );
}

// ── STATE B: Teacher reviewing a student's code ───────────────────────────────

const STUDENT_CODE = [
  { n: 18, text: "class Paddle:" },
  { n: 19, text: "    def __init__(self, x, y):" },
  { n: 20, text: "        self.x = x" },
  { n: 21, text: "        self.y = y" },
  { n: 22, text: "        self.dy = 0" },
  { n: 23, text: "" },
  { n: 24, text: "    def update(self):", comment: true },
  { n: 25, text: "        if self.dy != 0:" },
  { n: 26, text: '            self.move(self.dy)', error: true },
  { n: 27, text: "        self.y += self.dy" },
  { n: 28, text: "        self.draw()" },
  { n: 29, text: "" },
  { n: 30, text: "    def draw(self):" },
  { n: 31, text: "        pyxel.rect(self.x, self.y," },
  { n: 32, text: "                   self.width, self.height, 7)" },
];

// Fake pong canvas thumbnail
function MiniCanvas({ width = 180, height = 130 }) {
  return (
    <div style={{
      width, height,
      background: "#072428",
      borderRadius: 6,
      position: "relative",
      overflow: "hidden",
      imageRendering: "pixelated",
      border: "1px solid rgba(255,255,255,0.08)",
    }}>
      {Array.from({ length: 7 }).map((_, i) => (
        <div key={i} style={{
          position: "absolute", left: "50%",
          top: `${i * 14 + 2}%`,
          width: 2, height: "10%",
          background: "rgba(95,212,220,0.2)",
          transform: "translateX(-50%)",
        }} />
      ))}
      <div style={{ position: "absolute", left: 6, top: "28%", width: 4, height: "44%", background: "#fffaf0" }} />
      <div style={{ position: "absolute", right: 6, top: "44%", width: 4, height: "44%", background: "#fffaf0" }} />
      <div style={{ position: "absolute", left: "60%", top: "38%", width: 4, height: 4, background: "#5fd4dc" }} />
      <div style={{
        position: "absolute", top: 6, left: 0, right: 0,
        display: "flex", justifyContent: "center", gap: 20,
        fontFamily: T.fontMono, fontSize: 13, fontWeight: 700, color: "#fffaf0", opacity: 0.9,
      }}>
        <span>3</span><span>5</span>
      </div>
      {/* Error badge */}
      <div style={{
        position: "absolute", bottom: 6, left: 6,
        padding: "2px 7px", borderRadius: T.rPill,
        background: T.dangerSoft || "rgba(196,69,28,0.18)",
        border: `1px solid ${T.danger}60`,
        fontFamily: T.fontMono, fontSize: 10, color: T.danger, fontWeight: 700,
      }}>AttributeError · L26</div>
    </div>
  );
}

function TeacherReviewPanel({ student, onBack }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", overflow: "hidden", fontFamily: T.fontUI }}>
      {/* Back */}
      <div style={{
        padding: "10px 14px 8px",
        borderBottom: `1px solid ${T.border}`,
        background: T.panelHeader,
      }}>
        <button onClick={onBack} style={{
          all: "unset", cursor: "pointer",
          display: "flex", alignItems: "center", gap: 6,
          fontSize: 12, color: T.txtMute, fontWeight: 600, marginBottom: 10,
        }}>
          <Icon name="back" size={12} />
          Back to class
        </button>
        {/* Student identity */}
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
          <Avatar name={student.name} role="student" size={36} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 14, fontWeight: 800, color: T.txt }}>{student.name}</div>
            <div style={{
              display: "flex", alignItems: "center", gap: 6,
              fontSize: 11, color: T.txtMute, marginTop: 1,
            }}>
              <span style={{ fontFamily: T.fontMono }}>@{student.handle}</span>
              <span style={{ width: 3, height: 3, borderRadius: T.rPill, background: T.txtFaint }} />
              <span>{student.project}</span>
            </div>
          </div>
          <span style={{
            padding: "3px 8px", borderRadius: T.rPill,
            background: student.help ? T.hand : T.okSoft,
            color: student.help ? "#fff" : T.ok,
            fontSize: 10.5, fontWeight: 700,
            textTransform: "uppercase", letterSpacing: 0.3,
          }}>
            {student.help ? "✋ Hand up" : "Coding"}
          </span>
        </div>

        {/* Mini canvas */}
        <MiniCanvas />
      </div>

      <div style={{ flex: 1, overflow: "auto", padding: "10px 12px" }}>
        {/* Student's help message */}
        {student.help && (
          <div style={{
            padding: "10px 12px", borderRadius: T.rCard,
            background: T.handSoft, border: `1px solid ${T.hand}50`,
            marginBottom: 12,
            display: "flex", gap: 8,
          }}>
            <Icon name="hand" size={13} color={T.hand} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 11, color: T.hand, fontWeight: 700, marginBottom: 3 }}>Student note</div>
              <div style={{ fontSize: 12.5, color: T.txt, fontFamily: T.fontMono }}>
                line {student.lastLine} · AttributeError: 'Paddle' has no attribute 'move'
              </div>
            </div>
          </div>
        )}

        {/* Quick actions */}
        <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 14 }}>
          <button style={{
            all: "unset", cursor: "pointer",
            display: "flex", alignItems: "center", gap: 10,
            padding: "9px 12px", borderRadius: 7,
            background: T.ok, color: "#fff",
          }}>
            <Icon name="check" size={13} color="#fff" />
            <span style={{ fontSize: 13, fontWeight: 700 }}>Resolve & dismiss</span>
          </button>
          <button style={{
            all: "unset", cursor: "pointer",
            display: "flex", alignItems: "center", gap: 10,
            padding: "9px 12px", borderRadius: 7,
            background: T.surface, border: `1px solid ${T.border}`,
            color: T.txt,
          }}>
            <Icon name="users" size={13} color={T.teal} />
            <span style={{ fontSize: 13, fontWeight: 600 }}>Add comment to code</span>
          </button>
        </div>

        {/* Milestone history */}
        <div style={{
          fontSize: 10.5, fontWeight: 700, color: T.txtMute,
          letterSpacing: 0.6, textTransform: "uppercase", marginBottom: 6,
        }}>Student milestones</div>
        {[
          { label: "Collision works!",   time: "10 min ago",  current: true  },
          { label: "Paddles moving",     time: "yesterday",   current: false },
          { label: "First run",          time: "2 days ago",  current: false },
        ].map((m, i) => (
          <div key={i} style={{
            display: "flex", alignItems: "center", gap: 8, marginBottom: 5,
            padding: "5px 8px", borderRadius: 6,
            background: m.current ? T.tealSoft : "transparent",
          }}>
            <span style={{
              width: 7, height: 7, borderRadius: T.rPill,
              background: m.current ? T.teal : T.txtFaint, flex: "none",
            }} />
            <span style={{
              flex: 1, fontSize: 12, color: T.txt, fontWeight: m.current ? 600 : 400,
            }}>{m.label}</span>
            <span style={{ fontSize: 10.5, color: T.txtFaint, fontFamily: T.fontMono }}>{m.time}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function TeacherCodeEditor({ student }) {
  return (
    <div style={{
      flex: 1, display: "flex", flexDirection: "column",
      background: "#fffaf0", overflow: "hidden",
    }}>
      {/* File bar */}
      <div style={{
        height: 40, flex: "none",
        display: "flex", alignItems: "center",
        background: "#0e9aa7",
        padding: "0 14px", gap: 10,
        fontFamily: T.fontUI,
      }}>
        {/* Breadcrumb */}
        <span style={{ fontSize: 12, color: "rgba(255,255,255,0.65)", fontWeight: 500 }}>
          Period 4
        </span>
        <span style={{ color: "rgba(255,255,255,0.35)", fontSize: 12 }}>/</span>
        <Avatar name={student.name} role="student" size={18} />
        <span style={{ fontSize: 12.5, fontWeight: 700, color: "#fffaf0" }}>{student.name}</span>
        <span style={{ color: "rgba(255,255,255,0.35)", fontSize: 12 }}>/</span>
        <div style={{
          padding: "4px 10px", background: "#fffaf0", borderRadius: "4px 4px 0 0",
          color: "#0a3d44", fontFamily: T.fontMono, fontSize: 12, fontWeight: 600,
        }}>main.py</div>
        <div style={{ flex: 1 }} />
        {/* Teacher badge */}
        <span style={{
          padding: "3px 9px", borderRadius: T.rPill,
          background: "rgba(255,255,255,0.15)", color: "#fffaf0",
          fontSize: 11, fontWeight: 700, letterSpacing: 0.3,
        }}>Reviewing</span>
        <span style={{ fontFamily: T.fontMono, fontSize: 11, color: "rgba(255,255,255,0.5)" }}>read-only</span>
      </div>

      {/* Code */}
      <div style={{ flex: 1, overflow: "auto", display: "flex" }}>
        {/* Gutter */}
        <div style={{
          flex: "none", display: "flex", flexDirection: "column",
          background: "#fffaf0", userSelect: "none",
          padding: "10px 0",
        }}>
          {STUDENT_CODE.map(l => (
            <div key={l.n} style={{
              height: "1.65em", display: "flex", alignItems: "center", gap: 6, paddingLeft: 12,
            }}>
              <span style={{
                width: 24, textAlign: "right",
                fontFamily: T.fontMono, fontSize: 12,
                color: l.comment ? T.teal : l.error ? T.danger : "#b6c2c8",
                fontWeight: (l.comment || l.error) ? 700 : 400,
              }}>{l.n}</span>
              <div style={{ width: 18, display: "flex", alignItems: "center", justifyContent: "center" }}>
                {/* Teacher "add comment" affordance — always visible on hover, shown here on active lines */}
                {(l.comment || l.error) && (
                  <div style={{
                    width: 14, height: 14, borderRadius: T.rPill,
                    background: l.error ? T.dangerSoft || "rgba(196,69,28,0.15)" : T.tealSoft,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    cursor: "pointer",
                  }}>
                    <div style={{
                      width: 8, height: 8, borderRadius: T.rPill,
                      background: l.error ? T.danger : T.teal,
                    }} />
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Code text */}
        <div style={{ flex: 1, padding: "10px 0 10px 6px" }}>
          {STUDENT_CODE.map(l => (
            <div key={l.n} style={{
              height: "1.65em", display: "flex", alignItems: "center",
              background: l.error ? "rgba(196,69,28,0.07)" : l.comment ? "rgba(14,154,167,0.05)" : "transparent",
              paddingRight: 16, whiteSpace: "pre",
            }}>
              <code style={{ fontFamily: T.fontMono, fontSize: 13, color: T.txt }}>{l.text}</code>
              {/* Inline comment chip */}
              {l.comment && (
                <span style={{
                  marginLeft: "1.5em",
                  display: "inline-flex", alignItems: "center", gap: 5,
                  padding: "1px 8px", borderRadius: 3,
                  background: T.tealSoft, color: T.tealDeep,
                  fontFamily: T.fontUI, fontSize: 11, fontWeight: 600, whiteSpace: "nowrap",
                }}>
                  <Icon name="users" size={10} color={T.teal} />
                  Your comment · 1 reply
                </span>
              )}
              {/* Error annotation */}
              {l.error && (
                <span style={{
                  marginLeft: "1em",
                  display: "inline-flex", alignItems: "center", gap: 5,
                  padding: "1px 8px", borderRadius: 3,
                  background: "rgba(196,69,28,0.10)", color: T.danger,
                  fontFamily: T.fontUI, fontSize: 11, fontWeight: 600, whiteSpace: "nowrap",
                }}>
                  AttributeError: no attribute 'move'
                </span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Main composite components ─────────────────────────────────────────────────

function TeacherIDEHome() {
  const [selected, setSelected] = React.useState(null);

  return (
    <div style={{
      width: "100%", height: "100%",
      display: "flex", fontFamily: T.fontUI,
      background: T.surface,
    }}>
      {/* Rail */}
      <div style={{
        width: 56, flex: "none",
        background: "#0e9aa7",
        display: "flex", flexDirection: "column",
        alignItems: "center", padding: "14px 0", gap: 4,
      }}>
        <div style={{ marginBottom: 10 }}><Pi3Logo size={22} color="#fffaf0" /></div>
        {["folder", "spark", "sparkle"].map((ic, i) => (
          <div key={ic} style={{
            width: 44, height: 44, borderRadius: 6,
            display: "flex", alignItems: "center", justifyContent: "center",
            background: "transparent", color: "rgba(255,255,255,0.55)", cursor: "pointer",
          }}>
            <Icon name={ic} size={20} color="currentColor" />
          </div>
        ))}
        <div style={{ flex: 1 }} />
        <div style={{
          width: 44, height: 44, borderRadius: 6,
          display: "flex", alignItems: "center", justifyContent: "center",
          background: "rgba(255,255,255,0.20)", color: "#fff", cursor: "pointer",
          position: "relative",
        }}>
          <Icon name="users" size={20} color="currentColor" />
        </div>
        <div style={{ width: 44, height: 44, borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center", color: "rgba(255,255,255,0.55)", cursor: "pointer" }}>
          <Icon name="settings" size={20} color="currentColor" />
        </div>
      </div>

      {/* Class panel */}
      <div style={{
        width: 240, flex: "none",
        background: T.panel,
        borderRight: `1px solid ${T.border}`,
      }}>
        <TeacherClassPanel onSelectStudent={setSelected} selectedHandle={selected} />
      </div>

      {/* Classroom grid */}
      <ClassroomGrid onSelectStudent={setSelected} />
    </div>
  );
}

function TeacherIDEReview() {
  const student = STUDENTS.find(s => s.help) || STUDENTS[0];
  const [back, setBack] = React.useState(false);

  if (back) return <TeacherIDEHome />;

  return (
    <div style={{
      width: "100%", height: "100%",
      display: "flex", fontFamily: T.fontUI, background: T.surface,
    }}>
      {/* Rail */}
      <div style={{
        width: 56, flex: "none",
        background: "#0e9aa7",
        display: "flex", flexDirection: "column",
        alignItems: "center", padding: "14px 0", gap: 4,
      }}>
        <div style={{ marginBottom: 10 }}><Pi3Logo size={22} color="#fffaf0" /></div>
        {["folder", "spark", "sparkle"].map(ic => (
          <div key={ic} style={{
            width: 44, height: 44, borderRadius: 6,
            display: "flex", alignItems: "center", justifyContent: "center",
            color: "rgba(255,255,255,0.55)", cursor: "pointer",
          }}>
            <Icon name={ic} size={20} color="currentColor" />
          </div>
        ))}
        <div style={{ flex: 1 }} />
        <div style={{
          width: 44, height: 44, borderRadius: 6,
          display: "flex", alignItems: "center", justifyContent: "center",
          background: "rgba(255,255,255,0.20)", color: "#fff", cursor: "pointer",
        }}>
          <Icon name="users" size={20} color="currentColor" />
        </div>
        <div style={{ width: 44, height: 44, borderRadius: 6, display: "flex", alignItems: "center", justifyContent: "center", color: "rgba(255,255,255,0.55)", cursor: "pointer" }}>
          <Icon name="settings" size={20} color="currentColor" />
        </div>
      </div>

      {/* Student review panel */}
      <div style={{
        width: 260, flex: "none",
        background: T.panel,
        borderRight: `1px solid ${T.border}`,
      }}>
        <TeacherReviewPanel student={student} onBack={() => setBack(true)} />
      </div>

      {/* Code editor — student's code */}
      <TeacherCodeEditor student={student} />
    </div>
  );
}

window.TeacherIDEHome = TeacherIDEHome;
window.TeacherIDEReview = TeacherIDEReview;
