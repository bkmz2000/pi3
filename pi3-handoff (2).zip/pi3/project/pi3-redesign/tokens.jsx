// pi3 Studio theme tokens — warm cream + teal
const T = {
  // Surfaces
  appBg:        "#e9e3d3",
  surface:      "#fbf6e9",
  panel:        "#fffaf0",
  panelHeader:  "#fdf3e1",
  chip:         "#f3ebd7",
  border:       "rgba(20,30,40,0.10)",
  borderStrong: "rgba(20,30,40,0.18)",

  // Text
  txt:       "#1f2933",
  txtMute:   "#5b6976",
  txtFaint:  "#9aa6b2",

  // Brand
  teal:      "#0e9aa7",
  tealDeep:  "#0a3d44",
  tealSoft:  "rgba(14,154,167,0.10)",
  tealLine:  "rgba(14,154,167,0.30)",

  // Roles
  student:        "#f6a560",
  studentSoft:    "rgba(246,165,96,0.16)",
  studentLine:    "rgba(246,165,96,0.45)",
  teacher:        "#0e9aa7",
  teacherSoft:    "rgba(14,154,167,0.13)",
  teacherLine:    "rgba(14,154,167,0.40)",

  // Status
  ok:        "#0e7c52",
  okSoft:    "rgba(14,124,82,0.12)",
  warn:      "#b87a1f",
  warnSoft:  "rgba(184,122,31,0.14)",
  danger:    "#c4451c",
  dangerSoft:"rgba(196,69,28,0.12)",
  hand:      "#d97a2b",
  handSoft:  "rgba(217,122,43,0.16)",

  // Typography
  fontUI:   "'Inter', system-ui, sans-serif",
  fontMono: "'JetBrains Mono', ui-monospace, monospace",
  fontDisplay: "'Nunito', system-ui, sans-serif",

  // Radii
  rCard:   10,
  rBtn:    6,
  rPill:   999,
  rInput:  7,

  // Shadow
  shadowCard:   "0 1px 0 rgba(20,30,40,0.04), 0 1px 3px rgba(20,30,40,0.06)",
  shadowPop:    "0 12px 32px -8px rgba(20,30,40,0.18), 0 2px 8px rgba(20,30,40,0.06)",
  shadowDialog: "0 30px 80px -28px rgba(20,30,40,0.40), 0 6px 18px rgba(20,30,40,0.10)",
};

window.T = T;

// Tiny helpers used everywhere
window.Pi3Logo = function Pi3Logo({ size = 18, color }) {
  return (
    <span style={{
      fontFamily: T.fontDisplay,
      fontWeight: 800,
      fontSize: size,
      color: color || T.tealDeep,
      letterSpacing: -0.5,
      lineHeight: 1,
    }}>
      pi<span style={{ fontSize: size * 0.65, verticalAlign: "0.15em" }}>3</span>
    </span>
  );
};

window.Avatar = function Avatar({ name, role = "student", size = 28 }) {
  const initials = (name || "?")
    .split(/[\s_-]+/).map(p => p[0]).filter(Boolean).join("").toUpperCase().slice(0, 2);
  const bg = role === "teacher" ? T.teacher : T.student;
  return (
    <span style={{
      width: size, height: size, borderRadius: T.rPill,
      background: bg, color: "#fff",
      display: "inline-flex", alignItems: "center", justifyContent: "center",
      fontFamily: T.fontUI, fontWeight: 700,
      fontSize: Math.round(size * 0.42),
      flex: "none",
    }}>{initials}</span>
  );
};

window.RoleTag = function RoleTag({ role }) {
  const teacher = role === "teacher";
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      padding: "2px 8px 2px 6px",
      borderRadius: T.rPill,
      background: teacher ? T.teacherSoft : T.studentSoft,
      color: teacher ? T.tealDeep : "#8b4a1a",
      fontFamily: T.fontUI, fontSize: 10.5, fontWeight: 700,
      letterSpacing: 0.3, textTransform: "uppercase",
    }}>
      <span style={{
        width: 6, height: 6, borderRadius: T.rPill,
        background: teacher ? T.teacher : T.student,
      }} />
      {teacher ? "Teacher" : "Student"}
    </span>
  );
};

// Lightweight icon set — just paths, no library
window.I = {
  close: <path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/>,
  check: <path d="M3 8.5l3 3 7-7" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" fill="none"/>,
  plus:  <path d="M8 3v10M3 8h10" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/>,
  chev:  <path d="M5 6l3 3 3-3" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" fill="none"/>,
  back:  <path d="M10 4l-4 4 4 4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" fill="none"/>,
  hand:  <path d="M5.5 9V4.2a1 1 0 1 1 2 0V8m0 0V3.2a1 1 0 1 1 2 0V8m0 0V4.2a1 1 0 1 1 2 0V9m-6 0v3a3 3 0 0 0 3 3h.5a3 3 0 0 0 3-3V9" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" fill="none"/>,
  users: <path d="M6 9a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5zm5 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM2 14c0-2 1.8-3.5 4-3.5S10 12 10 14m1.5-3c1.5 0 3 1 3 3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" fill="none"/>,
  folder:<path d="M2.5 5a1 1 0 0 1 1-1h2.2l1.3 1.4h5.5a1 1 0 0 1 1 1V12a1 1 0 0 1-1 1H3.5a1 1 0 0 1-1-1V5z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" fill="none"/>,
  search:<g stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round"><circle cx="7" cy="7" r="4"/><path d="M10 10l3 3"/></g>,
  dot3:  <g fill="currentColor"><circle cx="3" cy="8" r="1.2"/><circle cx="8" cy="8" r="1.2"/><circle cx="13" cy="8" r="1.2"/></g>,
  arrow: <path d="M3 8h10m-4-4l4 4-4 4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" fill="none"/>,
  trash: <path d="M3.5 5h9m-7 0V3.8a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1V5m-5.5 0v7.2a1 1 0 0 0 1 1h4a1 1 0 0 0 1-1V5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" fill="none"/>,
  bell:  <path d="M4 11h8l-1-1.2V7.5a3 3 0 0 0-2.4-2.94V4a.6.6 0 1 0-1.2 0v.56A3 3 0 0 0 5 7.5v2.3L4 11zm2.7 1.2a1.4 1.4 0 0 0 2.6 0" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" fill="none"/>,
  spark: <path d="M8 2v3m0 6v3M2 8h3m6 0h3M4.2 4.2l2 2m3.6 3.6l2 2M4.2 11.8l2-2m3.6-3.6l2-2" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>,
};

window.Icon = function Icon({ name, size = 14, color = "currentColor" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" style={{ color, flex: "none", display: "block" }}>
      {window.I[name]}
    </svg>
  );
};
