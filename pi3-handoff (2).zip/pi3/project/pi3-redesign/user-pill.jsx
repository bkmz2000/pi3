/* global React, T, Avatar, RoleTag, Icon, Pi3Logo */

// ─────────────────────────────────────────────────────────────────────────────
// 2. USER PILL — closed, open, and with status
// ─────────────────────────────────────────────────────────────────────────────
function UserPill({ user, open = false, withChrome = false }) {
  const isTeacher = user.role === "teacher";

  const pill = (
    <div style={{
      position: "relative",
      fontFamily: T.fontUI,
      display: "inline-block",
    }}>
      <button style={{
        all: "unset", cursor: "pointer",
        display: "inline-flex", alignItems: "center", gap: 9,
        padding: "4px 11px 4px 4px",
        borderRadius: T.rPill,
        background: T.panel,
        border: `1px solid ${open ? T.tealLine : T.border}`,
        boxShadow: open
          ? `0 0 0 3px ${T.tealSoft}`
          : "0 1px 0 rgba(20,30,40,0.04)",
        color: T.txt,
        fontSize: 13, fontWeight: 500,
        transition: "all 0.15s",
      }}>
        <Avatar name={user.name} role={user.role} size={26} />
        <span style={{ display: "flex", flexDirection: "column", lineHeight: 1.1, textAlign: "left" }}>
          <span style={{ fontSize: 13, fontWeight: 600, color: T.txt }}>{user.displayName || user.name}</span>
          <span style={{
            fontSize: 10, fontWeight: 700, letterSpacing: 0.3, textTransform: "uppercase",
            color: isTeacher ? T.teal : T.student, marginTop: 2,
          }}>{isTeacher ? "Teacher" : "Student"}</span>
        </span>
        <Icon name="chev" size={12} color={T.txtMute} />
      </button>

      {open && <UserMenu user={user} />}
    </div>
  );

  if (!withChrome) return pill;
  return (
    <div style={{
      width: "100%", height: "100%",
      background: T.surface,
      display: "flex", alignItems: "flex-start", justifyContent: "flex-end",
      padding: "20px 24px",
      gap: 10,
      borderBottom: `1px solid ${T.border}`,
    }}>
      {pill}
    </div>
  );
}

function UserMenu({ user }) {
  const isTeacher = user.role === "teacher";
  const items = isTeacher
    ? [
        { icon: "spark",  label: "Teacher dashboard", hint: "3 help requests", hintTone: "hand" },
        { icon: "folder", label: "My projects" },
        { icon: "users",  label: "My classes" },
      ]
    : [
        { icon: "folder", label: "My projects" },
        { icon: "hand",   label: "Ask for help", hint: "Class only" },
        { icon: "users",  label: "My class",     hint: "Period 4 · Algo" },
      ];

  return (
    <div style={{
      position: "absolute", right: 0, top: "calc(100% + 8px)",
      width: 260, zIndex: 50,
      background: T.panel,
      border: `1px solid ${T.border}`,
      borderRadius: 12,
      boxShadow: T.shadowPop,
      padding: 6,
      fontFamily: T.fontUI,
    }}>
      {/* Identity block */}
      <div style={{
        padding: "12px 12px 10px",
        display: "flex", alignItems: "center", gap: 11,
        borderBottom: `1px solid ${T.border}`,
        margin: "0 4px 6px",
      }}>
        <Avatar name={user.name} role={user.role} size={36} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13.5, fontWeight: 700, color: T.txt }}>{user.displayName || user.name}</div>
          <div style={{
            fontSize: 11, color: T.txtMute, fontFamily: T.fontMono,
            marginTop: 2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
          }}>@{user.name}</div>
        </div>
        <RoleTag role={user.role} />
      </div>

      {items.map((it, i) => (
        <button key={i} style={{
          all: "unset", cursor: "pointer",
          display: "flex", alignItems: "center", gap: 11,
          width: "100%", boxSizing: "border-box",
          padding: "9px 12px", borderRadius: 7,
          background: i === 0 ? T.tealSoft : "transparent",
          color: T.txt, fontSize: 13,
        }}>
          <Icon name={it.icon} size={14} color={i === 0 ? T.teal : T.txtMute} />
          <span style={{ flex: 1, fontWeight: i === 0 ? 600 : 500 }}>{it.label}</span>
          {it.hint && (
            <span style={{
              fontSize: 10.5, fontWeight: 700,
              padding: "2px 7px", borderRadius: T.rPill,
              background: it.hintTone === "hand" ? T.handSoft : T.chip,
              color: it.hintTone === "hand" ? T.hand : T.txtMute,
              letterSpacing: 0.2,
            }}>{it.hint}</span>
          )}
        </button>
      ))}

      <div style={{ height: 1, background: T.border, margin: "6px 8px" }} />
      <button style={{
        all: "unset", cursor: "pointer",
        display: "flex", alignItems: "center", gap: 11,
        width: "100%", boxSizing: "border-box",
        padding: "9px 12px", borderRadius: 7,
        color: T.danger, fontSize: 13, fontWeight: 500,
      }}>
        <Icon name="back" size={14} />
        Sign out
      </button>
    </div>
  );
}

window.UserPill = UserPill;
