/* global React, T, Avatar, RoleTag, Icon, Pi3Logo */

// ─────────────────────────────────────────────────────────────────────────────
// 3. USERS / PROJECTS PAGE  — clean home with a "My class" rail for students,
//    and a roster for teachers
// ─────────────────────────────────────────────────────────────────────────────

const STUDENT_PROJECTS = [
  { name: "Snake game",        files: 4, edited: "2 min ago",    status: "shared",  cover: "snake" },
  { name: "Turtle spiral",     files: 2, edited: "1 hr ago",     status: "help",    cover: "spiral" },
  { name: "Number guesser",    files: 1, edited: "yesterday",    status: "draft",   cover: "digits" },
  { name: "Pong rebuild",      files: 3, edited: "3 days ago",   status: "shared",  cover: "pong" },
  { name: "Chatbot starter",   files: 2, edited: "last week",    status: "draft",   cover: "chat" },
  { name: "Fractal tree",      files: 1, edited: "last week",    status: "shared",  cover: "tree" },
];

const ROSTER = [
  { name: "Ada Lovelace",    handle: "ada",       active: "online",   projects: 6, help: false, lastSeen: "now" },
  { name: "Linus Torvalds",  handle: "linus",     active: "online",   projects: 4, help: true,  lastSeen: "now" },
  { name: "Grace Hopper",    handle: "grace",     active: "online",   projects: 7, help: false, lastSeen: "now" },
  { name: "Alan Turing",     handle: "turing",    active: "away",     projects: 3, help: false, lastSeen: "12m" },
  { name: "Margaret Hamilton", handle: "mhamilton", active: "online", projects: 5, help: true,  lastSeen: "now" },
  { name: "Donald Knuth",    handle: "knuth",     active: "offline",  projects: 2, help: false, lastSeen: "2h" },
  { name: "Barbara Liskov",  handle: "liskov",    active: "online",   projects: 4, help: false, lastSeen: "now" },
  { name: "Tim Berners-Lee", handle: "tbl",       active: "offline",  projects: 1, help: false, lastSeen: "3d" },
];

function Cover({ kind }) {
  // Subtle placeholder covers — striped fill + monospace label
  const palettes = {
    snake:  ["#0e9aa7", "#0a3d44"],
    spiral: ["#f6a560", "#b35c1a"],
    digits: ["#0e7c52", "#0a3d44"],
    pong:   ["#1f2933", "#5b6976"],
    chat:   ["#0e9aa7", "#5fd4dc"],
    tree:   ["#34a853", "#0e7c52"],
  };
  const [a, b] = palettes[kind] || ["#0e9aa7", "#0a3d44"];
  return (
    <div style={{
      height: 84,
      background: `repeating-linear-gradient(135deg, ${a} 0 14px, ${b} 14px 28px)`,
      borderRadius: 8,
      position: "relative",
      overflow: "hidden",
    }}>
      <div style={{
        position: "absolute", inset: 0,
        background: "linear-gradient(180deg, rgba(0,0,0,0) 50%, rgba(0,0,0,0.18) 100%)",
      }} />
      <div style={{
        position: "absolute", left: 10, bottom: 8,
        fontFamily: T.fontMono, fontSize: 10.5,
        color: "rgba(255,250,240,0.85)",
        textTransform: "uppercase", letterSpacing: 1,
      }}>// {kind}.py</div>
    </div>
  );
}

function StatusChip({ status }) {
  const map = {
    shared: { label: "Shared",    bg: T.tealSoft,   fg: T.tealDeep, dot: T.teal },
    draft:  { label: "Private",   bg: T.chip,       fg: T.txtMute,  dot: T.txtFaint },
    help:   { label: "Help asked",bg: T.handSoft,   fg: T.hand,     dot: T.hand },
  }[status];
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      padding: "2px 8px 2px 7px",
      background: map.bg, color: map.fg,
      borderRadius: T.rPill, fontSize: 10.5, fontWeight: 700,
      letterSpacing: 0.2, textTransform: "uppercase",
    }}>
      <span style={{ width: 6, height: 6, borderRadius: T.rPill, background: map.dot }} />
      {map.label}
    </span>
  );
}

function ProjectCard({ p }) {
  return (
    <div style={{
      background: T.panel,
      borderRadius: T.rCard,
      border: `1px solid ${T.border}`,
      padding: 10,
      display: "flex", flexDirection: "column", gap: 10,
      boxShadow: T.shadowCard,
      fontFamily: T.fontUI,
    }}>
      <Cover kind={p.cover} />
      <div style={{ padding: "0 4px 4px", display: "flex", flexDirection: "column", gap: 6 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ flex: 1, fontSize: 14, fontWeight: 700, color: T.txt }}>{p.name}</span>
          <StatusChip status={p.status} />
        </div>
        <div style={{
          display: "flex", alignItems: "center", gap: 10,
          fontSize: 11.5, color: T.txtMute,
        }}>
          <span style={{ fontFamily: T.fontMono }}>{p.files} file{p.files === 1 ? "" : "s"}</span>
          <span style={{ width: 3, height: 3, borderRadius: T.rPill, background: T.txtFaint }} />
          <span>{p.edited}</span>
        </div>
      </div>
    </div>
  );
}

function TopBar({ user, title }) {
  return (
    <div style={{
      height: 56, flex: "none",
      display: "flex", alignItems: "center",
      padding: "0 24px", gap: 14,
      background: T.panel,
      borderBottom: `1px solid ${T.border}`,
    }}>
      <button style={{
        all: "unset", cursor: "pointer",
        display: "inline-flex", alignItems: "center", gap: 6,
        color: T.txtMute, fontSize: 12.5, fontWeight: 500,
        padding: "6px 10px 6px 8px", borderRadius: 6,
      }}>
        <Icon name="back" size={12} />
        Back to editor
      </button>
      <div style={{ width: 1, height: 20, background: T.border }} />
      <Pi3Logo size={20} />
      <div style={{
        marginLeft: 6, padding: "3px 8px", borderRadius: T.rPill,
        background: T.tealSoft, color: T.tealDeep,
        fontSize: 11, fontWeight: 700, letterSpacing: 0.3, textTransform: "uppercase",
      }}>{title}</div>
      <div style={{ flex: 1 }} />
      <UserPillInline user={user} />
    </div>
  );
}

function UserPillInline({ user }) {
  const isTeacher = user.role === "teacher";
  return (
    <div style={{
      display: "inline-flex", alignItems: "center", gap: 9,
      padding: "4px 11px 4px 4px",
      borderRadius: T.rPill,
      background: T.surface,
      border: `1px solid ${T.border}`,
      fontFamily: T.fontUI,
    }}>
      <Avatar name={user.name} role={user.role} size={24} />
      <span style={{ display: "flex", flexDirection: "column", lineHeight: 1.1 }}>
        <span style={{ fontSize: 12.5, fontWeight: 600, color: T.txt }}>{user.displayName}</span>
        <span style={{
          fontSize: 9.5, fontWeight: 700, letterSpacing: 0.3, textTransform: "uppercase",
          color: isTeacher ? T.teal : T.student, marginTop: 1,
        }}>{isTeacher ? "Teacher" : "Student"}</span>
      </span>
    </div>
  );
}

// ── Student variant ──
function StudentHome() {
  const user = { name: "ada", displayName: "Ada L.", role: "student" };
  return (
    <div style={{
      width: "100%", height: "100%", background: T.surface,
      fontFamily: T.fontUI, display: "flex", flexDirection: "column",
    }}>
      <TopBar user={user} title="My projects" />

      <div style={{ flex: 1, display: "grid", gridTemplateColumns: "1fr 280px", overflow: "hidden" }}>
        {/* Main */}
        <div style={{ overflow: "auto", padding: "28px 28px 36px" }}>
          {/* Greeting + actions */}
          <div style={{
            display: "flex", alignItems: "flex-end", gap: 18,
            marginBottom: 22,
          }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: T.txtMute, marginBottom: 4 }}>
                Good morning, Ada
              </div>
              <div style={{ fontSize: 26, fontWeight: 800, color: T.txt, letterSpacing: -0.5 }}>
                Pick up where you left off
              </div>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button style={{
                all: "unset", cursor: "pointer",
                display: "inline-flex", alignItems: "center", gap: 7,
                padding: "9px 14px", borderRadius: 8,
                background: T.panel, border: `1px solid ${T.border}`,
                color: T.txt, fontSize: 13, fontWeight: 600,
              }}>
                <Icon name="search" size={13} color={T.txtMute} />
                Search
              </button>
              <button style={{
                all: "unset", cursor: "pointer",
                display: "inline-flex", alignItems: "center", gap: 7,
                padding: "9px 16px", borderRadius: 8,
                background: T.tealDeep, color: "#fffaf0",
                fontSize: 13, fontWeight: 700,
              }}>
                <Icon name="plus" size={13} color="#fffaf0" />
                New project
              </button>
            </div>
          </div>

          {/* Filter chips */}
          <div style={{ display: "flex", gap: 6, marginBottom: 18 }}>
            {[
              { label: "All",       count: 6, on: true },
              { label: "Shared",    count: 3 },
              { label: "Private",   count: 2 },
              { label: "Help asked", count: 1 },
            ].map(c => (
              <button key={c.label} style={{
                all: "unset", cursor: "pointer",
                display: "inline-flex", alignItems: "center", gap: 6,
                padding: "6px 12px", borderRadius: T.rPill,
                background: c.on ? T.tealDeep : T.panel,
                border: `1px solid ${c.on ? T.tealDeep : T.border}`,
                color: c.on ? "#fffaf0" : T.txt,
                fontSize: 12, fontWeight: 600,
              }}>
                {c.label}
                <span style={{
                  fontFamily: T.fontMono, fontSize: 10.5,
                  opacity: c.on ? 0.7 : 0.55,
                }}>{c.count}</span>
              </button>
            ))}
          </div>

          {/* Grid */}
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))",
            gap: 12,
          }}>
            {STUDENT_PROJECTS.map(p => <ProjectCard key={p.name} p={p} />)}
          </div>
        </div>

        {/* Class rail */}
        <aside style={{
          background: T.panel,
          borderLeft: `1px solid ${T.border}`,
          overflow: "auto",
          padding: "22px 20px",
          display: "flex", flexDirection: "column", gap: 18,
        }}>
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.6, textTransform: "uppercase", color: T.txtMute }}>
              Your class
            </div>
            <div style={{ fontSize: 16, fontWeight: 800, color: T.txt, marginTop: 2 }}>Period 4 · Algorithms</div>
            <div style={{ fontSize: 12, color: T.txtMute, marginTop: 2 }}>
              Ms. Hopper · 24 students
            </div>
          </div>

          {/* Ask for help */}
          <div style={{
            padding: "14px",
            background: T.handSoft,
            border: `1px solid ${T.handSoft}`,
            borderRadius: T.rCard,
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
              <span style={{
                width: 26, height: 26, borderRadius: T.rPill, background: T.hand, color: "#fff",
                display: "inline-flex", alignItems: "center", justifyContent: "center",
              }}>
                <Icon name="hand" size={13} color="#fff" />
              </span>
              <div style={{ fontSize: 13, fontWeight: 700, color: T.txt }}>Stuck?</div>
            </div>
            <div style={{ fontSize: 12, color: T.txtMute, lineHeight: 1.4, marginBottom: 10 }}>
              Raise your hand. Ms. Hopper will see your screen.
            </div>
            <button style={{
              all: "unset", cursor: "pointer",
              display: "block", textAlign: "center",
              padding: "8px 12px", borderRadius: 7,
              background: T.hand, color: "#fff",
              fontSize: 12.5, fontWeight: 700,
              width: "100%", boxSizing: "border-box",
            }}>
              Ask for help
            </button>
          </div>

          {/* Online classmates */}
          <div>
            <div style={{
              display: "flex", alignItems: "center", marginBottom: 8,
              fontSize: 11, fontWeight: 700, letterSpacing: 0.6, textTransform: "uppercase", color: T.txtMute,
            }}>
              <span style={{ flex: 1 }}>In class now</span>
              <span style={{ fontFamily: T.fontMono, fontSize: 10.5, color: T.txtFaint, textTransform: "none", letterSpacing: 0 }}>
                {ROSTER.filter(r => r.active === "online").length}/{ROSTER.length}
              </span>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
              {ROSTER.slice(0, 6).map(s => (
                <div key={s.handle} style={{
                  display: "flex", alignItems: "center", gap: 9,
                  padding: "6px 6px",
                  borderRadius: 6,
                }}>
                  <div style={{ position: "relative" }}>
                    <Avatar name={s.name} role="student" size={26} />
                    <span style={{
                      position: "absolute", right: -1, bottom: -1,
                      width: 9, height: 9, borderRadius: T.rPill,
                      background: s.active === "online" ? "#34a853" : s.active === "away" ? "#f6a560" : T.txtFaint,
                      border: `2px solid ${T.panel}`,
                    }} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 12.5, fontWeight: 600, color: T.txt, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{s.name}</div>
                  </div>
                  {s.help && (
                    <span style={{
                      fontSize: 9.5, fontWeight: 700, padding: "2px 6px", borderRadius: T.rPill,
                      background: T.handSoft, color: T.hand,
                      letterSpacing: 0.2, textTransform: "uppercase",
                    }}>hand</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

// ── Teacher's "Users / Roster" view ──
function TeacherRoster() {
  const user = { name: "ghopper", displayName: "Ms. Hopper", role: "teacher" };
  return (
    <div style={{
      width: "100%", height: "100%", background: T.surface,
      fontFamily: T.fontUI, display: "flex", flexDirection: "column",
    }}>
      <TopBar user={user} title="Teacher · Students" />

      <div style={{ flex: 1, overflow: "auto", padding: "28px 28px 36px" }}>
        <div style={{
          display: "flex", alignItems: "flex-end", gap: 18, marginBottom: 22,
        }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: T.txtMute, marginBottom: 4 }}>Period 4 · Algorithms</div>
            <div style={{ fontSize: 26, fontWeight: 800, color: T.txt, letterSpacing: -0.5 }}>Students</div>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button style={{
              all: "unset", cursor: "pointer",
              display: "inline-flex", alignItems: "center", gap: 7,
              padding: "9px 14px", borderRadius: 8,
              background: T.panel, border: `1px solid ${T.border}`,
              color: T.txt, fontSize: 13, fontWeight: 600,
            }}>
              <Icon name="search" size={13} color={T.txtMute} />
              Search students
            </button>
            <button style={{
              all: "unset", cursor: "pointer",
              display: "inline-flex", alignItems: "center", gap: 7,
              padding: "9px 16px", borderRadius: 8,
              background: T.tealDeep, color: "#fffaf0",
              fontSize: 13, fontWeight: 700,
            }}>
              <Icon name="plus" size={13} color="#fffaf0" />
              Invite student
            </button>
          </div>
        </div>

        {/* Summary strip */}
        <div style={{
          display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10,
          marginBottom: 20,
        }}>
          {[
            { label: "In class",    val: 5, sub: "of 8",         tone: T.teal },
            { label: "Hands up",    val: 2, sub: "needs help",   tone: T.hand },
            { label: "Active code", val: 4, sub: "running now",  tone: T.ok },
            { label: "Projects",    val: 32, sub: "total",       tone: T.txtMute },
          ].map(s => (
            <div key={s.label} style={{
              padding: "14px 16px", background: T.panel,
              border: `1px solid ${T.border}`, borderRadius: T.rCard,
            }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: T.txtMute, letterSpacing: 0.5, textTransform: "uppercase" }}>{s.label}</div>
              <div style={{ display: "flex", alignItems: "baseline", gap: 6, marginTop: 4 }}>
                <span style={{ fontFamily: T.fontMono, fontSize: 22, fontWeight: 700, color: s.tone }}>{s.val}</span>
                <span style={{ fontSize: 12, color: T.txtMute }}>{s.sub}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Roster table */}
        <div style={{
          background: T.panel,
          border: `1px solid ${T.border}`,
          borderRadius: T.rCard,
          overflow: "hidden",
        }}>
          {/* Header row */}
          <div style={{
            display: "grid",
            gridTemplateColumns: "1.6fr 1fr 1fr 1fr 80px",
            padding: "10px 18px",
            background: T.panelHeader,
            fontSize: 10.5, fontWeight: 700, letterSpacing: 0.5,
            color: T.txtMute, textTransform: "uppercase",
            borderBottom: `1px solid ${T.border}`,
          }}>
            <span>Student</span>
            <span>Status</span>
            <span>Projects</span>
            <span>Last active</span>
            <span></span>
          </div>
          {ROSTER.map((s, i) => (
            <div key={s.handle} style={{
              display: "grid",
              gridTemplateColumns: "1.6fr 1fr 1fr 1fr 80px",
              padding: "12px 18px",
              alignItems: "center",
              borderBottom: i < ROSTER.length - 1 ? `1px solid ${T.border}` : "none",
              background: s.help ? T.handSoft : "transparent",
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div style={{ position: "relative" }}>
                  <Avatar name={s.name} role="student" size={32} />
                  <span style={{
                    position: "absolute", right: -1, bottom: -1,
                    width: 10, height: 10, borderRadius: T.rPill,
                    background: s.active === "online" ? "#34a853" : s.active === "away" ? "#f6a560" : T.txtFaint,
                    border: `2px solid ${s.help ? "#fff4ea" : T.panel}`,
                  }} />
                </div>
                <div>
                  <div style={{ fontSize: 13.5, fontWeight: 700, color: T.txt }}>{s.name}</div>
                  <div style={{ fontSize: 11, color: T.txtMute, fontFamily: T.fontMono }}>@{s.handle}</div>
                </div>
              </div>
              <div>
                {s.help ? (
                  <span style={{
                    display: "inline-flex", alignItems: "center", gap: 5,
                    padding: "3px 9px 3px 8px", borderRadius: T.rPill,
                    background: T.hand, color: "#fff",
                    fontSize: 11, fontWeight: 700, letterSpacing: 0.3, textTransform: "uppercase",
                  }}>
                    <Icon name="hand" size={11} color="#fff" />
                    Hand up
                  </span>
                ) : (
                  <span style={{
                    display: "inline-flex", alignItems: "center", gap: 5,
                    fontSize: 12, color: T.txtMute,
                  }}>
                    <span style={{
                      width: 7, height: 7, borderRadius: T.rPill,
                      background: s.active === "online" ? "#34a853" : s.active === "away" ? "#f6a560" : T.txtFaint,
                    }} />
                    {s.active === "online" ? "Coding" : s.active === "away" ? "Away" : "Offline"}
                  </span>
                )}
              </div>
              <div style={{ fontSize: 13, color: T.txt, fontFamily: T.fontMono }}>{s.projects}</div>
              <div style={{ fontSize: 12, color: T.txtMute }}>{s.lastSeen}</div>
              <div style={{ display: "flex", justifyContent: "flex-end", gap: 4 }}>
                <button style={{
                  all: "unset", cursor: "pointer",
                  padding: "5px 10px", borderRadius: 6,
                  background: T.surface, border: `1px solid ${T.border}`,
                  fontSize: 11.5, fontWeight: 600, color: T.txt,
                }}>Open</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

window.StudentHome = StudentHome;
window.TeacherRoster = TeacherRoster;
