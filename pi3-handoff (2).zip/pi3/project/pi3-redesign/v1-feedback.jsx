/* global React, D, DIcon, dBtn */
// v1 FEEDBACK SURFACE — the antidote to "silent save loss" + swallowed errors.
// Three pieces: a persistent SAVE-STATE pill, a TOAST stack, and proper
// ERROR / EMPTY / OFFLINE states.

// ── 1. SAVE STATE PILL (lives in the status bar, always visible) ──────────
function SavePill({ state }) {
  const map = {
    saved:    { icon: "cloud",   txt: "All changes saved", c: D.txtMute,  bg: D.chip,      bd: D.border },
    saving:   { icon: "refresh", txt: "Saving…",            c: D.cyan,    bg: D.cyanSoft,  bd: D.cyanLine, spin: true },
    unsaved:  { icon: "pencil",  txt: "Unsaved changes",    c: D.warn,    bg: D.warnSoft,  bd: "rgba(251,191,119,0.4)" },
    failed:   { icon: "warn",    txt: "Couldn't save",      c: D.danger,  bg: D.dangerSoft,bd: "rgba(255,139,139,0.45)", retry: true },
  };
  const s = map[state];
  return (
    <div style={{
      display: "inline-flex", alignItems: "center", gap: 8, padding: "6px 12px 6px 10px",
      borderRadius: D.rPill, background: s.bg, border: `1px solid ${s.bd}`, color: s.c,
      fontFamily: D.fontUI, fontSize: 12.5, fontWeight: 600, whiteSpace: "nowrap",
    }}>
      <span style={{ display: "inline-flex", animation: s.spin ? "pi3spin 0.9s linear infinite" : "none" }}>
        <DIcon name={s.icon} size={14} />
      </span>
      {s.txt}
      {s.retry && (
        <button style={{
          all: "unset", cursor: "pointer", marginLeft: 2, padding: "2px 9px", borderRadius: D.rPill,
          background: D.danger, color: D.dangerTxt, fontSize: 11.5, fontWeight: 800,
        }}>Retry</button>
      )}
    </div>
  );
}

// ── 2. TOASTS ─────────────────────────────────────────────────────────────
function Toast({ kind, title, body, action }) {
  const map = {
    error:   { c: D.danger, bg: "rgba(255,139,139,0.12)", bd: "rgba(255,139,139,0.4)", icon: "warn" },
    success: { c: D.ok,     bg: D.okSoft,                 bd: "rgba(126,224,168,0.4)", icon: "check" },
    info:    { c: D.cyan,   bg: D.cyanSoft,               bd: D.cyanLine,              icon: "cloud" },
    offline: { c: D.warn,   bg: D.warnSoft,               bd: "rgba(251,191,119,0.4)", icon: "cloud" },
  };
  const s = map[kind];
  return (
    <div style={{
      display: "flex", gap: 11, alignItems: "flex-start", width: 360, boxSizing: "border-box",
      padding: "13px 14px", borderRadius: D.rCard, background: D.panel,
      border: `1px solid ${s.bd}`, boxShadow: D.shadowPop, fontFamily: D.fontUI,
    }}>
      <span style={{
        width: 26, height: 26, borderRadius: 8, flex: "none", marginTop: 1,
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        background: s.bg, color: s.c,
      }}><DIcon name={s.icon} size={15} /></span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13.5, fontWeight: 700, color: D.txt }}>{title}</div>
        {body && <div style={{ fontSize: 12.5, color: D.txtMute, marginTop: 3, lineHeight: 1.45 }}>{body}</div>}
        {action && (
          <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
            <button style={{ ...dBtn(kind === "error" ? "primary" : "secondary"), padding: "6px 13px", fontSize: 12.5 }}>{action}</button>
            <button style={{ ...dBtn("ghost"), padding: "6px 10px", fontSize: 12.5 }}>Dismiss</button>
          </div>
        )}
      </div>
      <button style={{ all: "unset", cursor: "pointer", color: D.txtFaint, padding: 2 }}><DIcon name="close" size={13} /></button>
    </div>
  );
}

// ── 3. STATE CARDS (error / empty / loading) ──────────────────────────────
function StateCard({ kind }) {
  const cfg = {
    error:   { icon: "warn",  c: D.danger, title: "Couldn't open this project", body: "We had trouble loading your files. Your work is safe — let's try again.", btn: "Try again" },
    empty:   { icon: "folder",c: D.cyan,   title: "No projects yet", body: "Start your first project and it'll show up right here.", btn: "New project" },
  }[kind];
  return (
    <div style={{
      width: 340, boxSizing: "border-box", padding: "34px 28px", borderRadius: D.rCard,
      background: D.surface, border: `1px solid ${D.border}`, textAlign: "center",
      fontFamily: D.fontUI, display: "flex", flexDirection: "column", alignItems: "center", gap: 8,
    }}>
      <span style={{
        width: 52, height: 52, borderRadius: 14, display: "inline-flex", alignItems: "center",
        justifyContent: "center", background: kind === "error" ? D.dangerSoft : D.cyanSoft, color: cfg.c, marginBottom: 4,
      }}><DIcon name={cfg.icon} size={24} /></span>
      <div style={{ fontSize: 16, fontWeight: 800, color: D.txt }}>{cfg.title}</div>
      <div style={{ fontSize: 13, color: D.txtMute, lineHeight: 1.5, maxWidth: 260 }}>{cfg.body}</div>
      <button style={{ ...dBtn(kind === "error" ? "primary" : "secondary"), marginTop: 10 }}>
        {kind === "empty" && <DIcon name="plus" size={14} />}{cfg.btn}
      </button>
    </div>
  );
}

// ── Composed artboards ─────────────────────────────────────────────────────
function SavePillStates() {
  return (
    <div style={{ width: "100%", height: "100%", background: D.appBg, padding: 28, display: "flex", flexDirection: "column", gap: 16, fontFamily: D.fontUI, boxSizing: "border-box" }}>
      <div style={{ fontSize: 12.5, color: D.txtMute, fontWeight: 600 }}>Persistent save-state pill — the file is NEVER marked clean until a save is confirmed.</div>
      {["saved", "unsaved", "saving", "failed"].map(s => (
        <div key={s} style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <span style={{ width: 70, fontSize: 11, color: D.txtFaint, fontFamily: D.fontMono }}>{s}</span>
          <SavePill state={s} />
        </div>
      ))}
      <div style={{ marginTop: 6, fontSize: 12, color: D.txtFaint, lineHeight: 1.5, borderTop: `1px solid ${D.border}`, paddingTop: 14 }}>
        On failure the pill turns red and offers <b style={{ color: D.danger }}>Retry</b> — the child always knows their work
        state instead of silently losing it on reload.
      </div>
    </div>
  );
}

function ToastCatalog() {
  return (
    <div style={{ width: "100%", height: "100%", background: D.appBg, padding: 28, display: "flex", flexDirection: "column", gap: 14, alignItems: "center", justifyContent: "center", boxSizing: "border-box" }}>
      <Toast kind="error" title="Couldn't save your project" body="You may be offline. We'll keep your changes and retry automatically." action="Retry now" />
      <Toast kind="success" title="Saved" body="All your changes are safe in the cloud." />
      <Toast kind="offline" title="You're offline" body="Keep coding — pi3 will sync when you're back online." />
    </div>
  );
}

function StateCards() {
  return (
    <div style={{ width: "100%", height: "100%", background: D.appBg, padding: 28, display: "flex", gap: 20, alignItems: "center", justifyContent: "center", boxSizing: "border-box" }}>
      <StateCard kind="error" />
      <StateCard kind="empty" />
    </div>
  );
}

window.SavePill = SavePill;
window.SavePillStates = SavePillStates;
window.ToastCatalog = ToastCatalog;
window.StateCards = StateCards;
