/* global React, D, Pi3, DIcon, dBtn */
// v1 LOGIN — school-SSO first. Teachers are provisioned by the school's
// identity provider only; self-signup is STUDENT-ONLY (closes the
// "anyone registers as teacher" hole). No client-chosen role.

function DInput({ label, type = "text", value, onChange, hint, right }) {
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 6 }}>
        <label style={{ fontSize: 12, fontWeight: 600, color: D.txtMute }}>{label}</label>
        {right}
      </div>
      <input
        type={type} value={value} onChange={onChange}
        style={{
          all: "unset", display: "block", width: "100%", boxSizing: "border-box",
          padding: "11px 13px", background: D.surface, border: `1px solid ${D.border}`,
          borderRadius: D.rInput, fontFamily: D.fontUI, fontSize: 14, color: D.txt,
        }}
      />
      {hint && <div style={{ fontSize: 11, color: D.txtFaint, marginTop: 6 }}>{hint}</div>}
    </div>
  );
}

function LoginShell({ children, sub }) {
  return (
    <div style={{
      width: 416, background: D.panel, borderRadius: 16, boxShadow: D.shadowDialog,
      fontFamily: D.fontUI, color: D.txt, overflow: "hidden", border: `1px solid ${D.border}`,
    }}>
      <div style={{ padding: "24px 26px 20px", background: D.panelHeader, borderBottom: `1px solid ${D.border}`, position: "relative" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 11 }}>
          <Pi3 size={26} />
          <div style={{ height: 18, width: 1, background: D.border }} />
          <span style={{ fontSize: 13, color: D.txtMute, fontWeight: 500 }}>{sub}</span>
        </div>
        <button style={{
          all: "unset", cursor: "pointer", position: "absolute", top: 18, right: 18,
          width: 30, height: 30, borderRadius: 8, display: "inline-flex",
          alignItems: "center", justifyContent: "center", color: D.txtMute,
        }}><DIcon name="close" size={14} /></button>
      </div>
      {children}
    </div>
  );
}

function SsoButton() {
  return (
    <button style={{
      all: "unset", boxSizing: "border-box", cursor: "pointer", width: "100%",
      display: "flex", alignItems: "center", justifyContent: "center", gap: 10,
      padding: "13px 16px", borderRadius: D.rInput, background: D.surface,
      border: `1px solid ${D.borderStrong}`, color: D.txt, fontSize: 14, fontWeight: 700,
    }}>
      <DIcon name="google" size={18} />
      Continue with school account
    </button>
  );
}

function OrRule() {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 12, color: D.txtFaint }}>
      <div style={{ flex: 1, height: 1, background: D.border }} />
      <span style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.6 }}>OR</span>
      <div style={{ flex: 1, height: 1, background: D.border }} />
    </div>
  );
}

// ── SIGN IN ──────────────────────────────────────────────────────────────
function LoginSignIn() {
  const [u, setU] = React.useState("ada.lovelace");
  const [p, setP] = React.useState("••••••••");
  return (
    <LoginShell sub="Welcome back">
      <div style={{ padding: "22px 26px 26px", display: "flex", flexDirection: "column", gap: 16 }}>
        <div style={{ fontSize: 19, fontWeight: 800, letterSpacing: -0.2 }}>Sign in to keep coding</div>
        <SsoButton />
        <OrRule />
        <DInput label="Username" value={u} onChange={e => setU(e.target.value)} />
        <DInput
          label="Password" type="password" value={p} onChange={e => setP(e.target.value)}
          right={<a href="#" style={{ fontSize: 11.5, color: D.cyan, textDecoration: "none", fontWeight: 600 }}>Forgot?</a>}
        />
        <button style={{ ...dBtn("primary"), padding: "12px 16px", fontSize: 14 }}>Sign in</button>
        <div style={{ textAlign: "center", fontSize: 12.5, color: D.txtMute }}>
          New here?{" "}
          <a style={{ color: D.cyan, fontWeight: 700, textDecoration: "none", cursor: "pointer" }}>Create a student account</a>
        </div>
      </div>
    </LoginShell>
  );
}

// ── STUDENT SIGN UP (no role picker) ─────────────────────────────────────
function LoginSignUpStudent() {
  const [u, setU] = React.useState("");
  const [p, setP] = React.useState("");
  return (
    <LoginShell sub="Create your account">
      <div style={{ padding: "22px 26px 26px", display: "flex", flexDirection: "column", gap: 15 }}>
        <div style={{ fontSize: 19, fontWeight: 800, letterSpacing: -0.2 }}>Join your class</div>

        {/* Role is fixed to student — shown, not chosen */}
        <div style={{
          display: "flex", alignItems: "center", gap: 11, padding: "11px 13px",
          borderRadius: D.rInput, background: D.studentSoft, border: `1px solid ${D.studentLine}`,
        }}>
          <span style={{
            width: 30, height: 30, borderRadius: D.rPill, background: D.student, color: "#062a26",
            display: "inline-flex", alignItems: "center", justifyContent: "center",
          }}><DIcon name="folder" size={15} color="#062a26" /></span>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13.5, fontWeight: 800 }}>Student account</div>
            <div style={{ fontSize: 11.5, color: D.txtMute, marginTop: 1 }}>Code, play and save your projects</div>
          </div>
        </div>

        <DInput label="Pick a username" value={u} onChange={e => setU(e.target.value)} />
        <DInput label="Password" type="password" value={p} onChange={e => setP(e.target.value)}
          hint="4+ characters. Make it something you'll remember." />

        <button style={{ ...dBtn("primary"), padding: "12px 16px", fontSize: 14 }}>Create student account</button>

        {/* Teachers routed to SSO — cannot self-provision */}
        <div style={{
          display: "flex", gap: 9, alignItems: "flex-start", padding: "10px 12px",
          borderRadius: D.rInput, background: D.chip, border: `1px solid ${D.border}`,
        }}>
          <span style={{ color: D.cyan, marginTop: 1 }}><DIcon name="lock" size={14} /></span>
          <div style={{ fontSize: 11.5, color: D.txtMute, lineHeight: 1.45 }}>
            <b style={{ color: D.txt }}>Teacher?</b> Teacher accounts are set up by your school.{" "}
            <a style={{ color: D.cyan, fontWeight: 700, textDecoration: "none", cursor: "pointer" }}>Sign in with your school account</a>.
          </div>
        </div>

        <div style={{ textAlign: "center", fontSize: 12.5, color: D.txtMute }}>
          Already have an account?{" "}
          <a style={{ color: D.cyan, fontWeight: 700, textDecoration: "none", cursor: "pointer" }}>Sign in</a>
        </div>
      </div>
    </LoginShell>
  );
}

window.LoginSignIn = LoginSignIn;
window.LoginSignUpStudent = LoginSignUpStudent;
