/* global React, D, Pi3, DIcon, dBtn, DAvatar */
// v1 SIDE PANEL — Proposal A: "This project" drawer.
// A single project-scoped surface: file tree, share-with-teacher, export.
// Shown as the rail + open drawer exactly as it sits in the IDE shell.

function Rail({ active = "project" }) {
  const items = [
    { id: "project", icon: "folder" },
    { id: "assets",  icon: "file" },
    { id: "settings",icon: "dot3" },
  ];
  return (
    <div style={{
      width: 56, background: D.rail, display: "flex", flexDirection: "column",
      alignItems: "center", padding: "12px 0", gap: 6, flex: "none",
      borderRight: `1px solid ${D.border}`,
    }}>
      <div style={{ marginBottom: 10 }}><Pi3 size={20} /></div>
      {items.map(it => (
        <button key={it.id} style={{
          all: "unset", cursor: "pointer", width: 40, height: 40, borderRadius: 10,
          display: "inline-flex", alignItems: "center", justifyContent: "center",
          background: active === it.id ? "rgba(120,210,220,0.18)" : "transparent",
          color: active === it.id ? D.cyan : "rgba(155,210,216,0.7)",
          boxShadow: active === it.id ? `inset 0 0 0 1px ${D.cyanLine}` : "none",
        }}><DIcon name={it.icon} size={18} /></button>
      ))}
      <div style={{ flex: 1 }} />
      <DAvatar name="Ada L." role="student" size={32} />
    </div>
  );
}

function FileRow({ name, kind = "file", active, dirty, indent = 0 }) {
  return (
    <button style={{
      all: "unset", cursor: "pointer", boxSizing: "border-box", width: "100%",
      display: "flex", alignItems: "center", gap: 9, padding: "7px 10px",
      paddingLeft: 10 + indent * 16, borderRadius: D.rBtn,
      background: active ? D.cyanSoft : "transparent",
      color: active ? D.txt : D.txtMute, fontFamily: D.fontMono, fontSize: 12.5,
    }}>
      <span style={{ color: active ? D.cyan : D.txtFaint }}>
        <DIcon name={kind === "img" ? "eye" : "file"} size={13} />
      </span>
      <span style={{ flex: 1, color: active ? D.txt : D.txt, fontWeight: active ? 600 : 400 }}>{name}</span>
      {dirty && <span style={{ width: 7, height: 7, borderRadius: 99, background: D.warn }} />}
    </button>
  );
}

function GroupLabel({ children, action }) {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 4px", margin: "2px 0" }}>
      <span style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: 0.7, color: D.txtFaint, textTransform: "uppercase" }}>{children}</span>
      {action}
    </div>
  );
}

function ProposalA() {
  return (
    <div style={{
      width: 860, height: 540, display: "flex", borderRadius: D.rCard, overflow: "hidden",
      border: `1px solid ${D.border}`, boxShadow: D.shadowDialog, fontFamily: D.fontUI, background: D.editorBg,
    }}>
      <Rail active="project" />

      {/* drawer */}
      <div style={{ width: 300, background: D.panel, borderRight: `1px solid ${D.border}`, display: "flex", flexDirection: "column", flex: "none" }}>
        <div style={{ padding: "16px 16px 12px", borderBottom: `1px solid ${D.border}`, background: D.panelHeader }}>
          <div style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: 0.7, color: D.txtFaint, textTransform: "uppercase" }}>This project</div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 6 }}>
            <span style={{ color: D.cyan }}><DIcon name="folder" size={16} /></span>
            <input defaultValue="Asteroids Remix" style={{
              all: "unset", flex: 1, fontFamily: D.fontUI, fontSize: 15, fontWeight: 800, color: D.txt,
            }} />
            <button style={{ all: "unset", cursor: "pointer", color: D.txtFaint }}><DIcon name="pencil" size={13} /></button>
          </div>
        </div>

        <div style={{ flex: 1, overflowY: "auto", padding: 12, display: "flex", flexDirection: "column", gap: 4 }}>
          <GroupLabel action={<button style={{ all: "unset", cursor: "pointer", color: D.txtFaint }}><DIcon name="plus" size={13} /></button>}>Files</GroupLabel>
          <FileRow name="main.py" active dirty />
          <FileRow name="ship_cfg.py" />
          <FileRow name="asteroid_cfg.py" />

          <div style={{ height: 10 }} />
          <GroupLabel action={<button style={{ all: "unset", cursor: "pointer", color: D.txtFaint }}><DIcon name="plus" size={13} /></button>}>Sprites</GroupLabel>
          <FileRow name="ship.svg" kind="img" />
          <FileRow name="asteroid.svg" kind="img" />
          <FileRow name="bullet.svg" kind="img" />
        </div>

        {/* sharing + export pinned to bottom */}
        <div style={{ borderTop: `1px solid ${D.border}`, padding: 14, display: "flex", flexDirection: "column", gap: 10, background: D.surface }}>
          <div style={{
            display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: D.rBtn,
            background: D.cyanSoft, border: `1px solid ${D.cyanLine}`,
          }}>
            <span style={{ color: D.cyan }}><DIcon name="share" size={15} /></span>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 12.5, fontWeight: 700, color: D.txt }}>Shared with Ms. Hopper</div>
              <div style={{ fontSize: 11, color: D.txtMute }}>Your teacher can see this project</div>
            </div>
            {/* on toggle */}
            <div style={{ width: 34, height: 20, borderRadius: 99, background: D.cyan, position: "relative", flex: "none" }}>
              <span style={{ position: "absolute", top: 2, right: 2, width: 16, height: 16, borderRadius: 99, background: "#062a26" }} />
            </div>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button style={{ ...dBtn("secondary"), flex: 1 }}><DIcon name="download" size={14} />ZIP</button>
            <button style={{ ...dBtn("secondary"), flex: 1 }}><DIcon name="share" size={13} />HTML</button>
          </div>
        </div>
      </div>

      {/* editor peek (context) */}
      <div style={{ flex: 1, background: D.editorBg, position: "relative", minWidth: 0 }}>
        <div style={{ padding: "10px 14px", borderBottom: `1px solid ${D.border}`, display: "flex", gap: 8, alignItems: "center", background: D.surface }}>
          <span style={{ padding: "5px 12px", borderRadius: 7, background: D.panel, color: D.txt, fontFamily: D.fontMono, fontSize: 12, fontWeight: 600 }}>main.py</span>
          <span style={{ width: 7, height: 7, borderRadius: 99, background: D.warn }} />
        </div>
        <pre style={{ margin: 0, padding: "16px 18px", fontFamily: D.fontMono, fontSize: 12.5, lineHeight: 1.7, color: D.txt }}>
<span style={{ color: D.cyan }}>import</span> graphics <span style={{ color: D.cyan }}>as</span> g{"\n"}
<span style={{ color: "#5b8489" }}># your asteroids game</span>{"\n"}
ship = g.actor(<span style={{ color: "#9be7c0" }}>"ship.svg"</span>){"\n\n"}
<span style={{ color: D.accent }}>@g.on_key_press</span>(<span style={{ color: "#9be7c0" }}>"space"</span>){"\n"}
<span style={{ color: D.cyan }}>def</span> <span style={{ color: "#7adfe6" }}>fire</span>():{"\n"}
{"    "}ship.shoot()
        </pre>
      </div>
    </div>
  );
}

window.ProposalA = ProposalA;
