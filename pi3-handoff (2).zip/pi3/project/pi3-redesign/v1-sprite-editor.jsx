/* global React, D, DIcon, dBtn */
// v1 SPRITE EDITOR — fixes the two flagged problems:
//  (1) CONTRAST: the old near-black canvas hid dark sprites. Replaced with a
//      neutral mid-grey checkerboard so a sprite of ANY colour reads clearly.
//  (2) EDIT EXISTING: a sprite strip lets you open & re-edit saved sprites,
//      not just draw new ones from scratch.

const PALETTE = [
  "#1d2b34", "#7a3b69", "#c0455b", "#f0915a",
  "#f7c873", "#9fe06a", "#3fae6a", "#2c8c8c",
  "#3a4fb8", "#4f74e0", "#5fb4f0", "#7fe6e6",
  "#f2efe6", "#a9b6bd", "#6c7c83", "#23323a",
];

// 16×16 pixel map for a sample "coin" sprite (0 = transparent)
const COIN = [
  "................",
  "................",
  ".....111111.....",
  "...1122222211...",
  "..112222222211..",
  ".11222233222211.",
  ".12222333322221.",
  ".12223333332221.",
  ".12223333332221.",
  ".12222333322221.",
  ".11222333222211.",
  "..112222222211..",
  "...1122222211...",
  ".....111111.....",
  "................",
  "................",
];
const COIN_COLORS = { "1": "#c98a2e", "2": "#f7c873", "3": "#fce9b0" };

function Canvas16({ map = COIN, colors = COIN_COLORS, px = 26 }) {
  const N = 16;
  return (
    <div style={{
      position: "relative", width: N * px, height: N * px,
      borderRadius: 6, overflow: "hidden",
      // Neutral checkerboard — the actual fix for the invisible-sprite bug
      backgroundColor: "#46575d",
      backgroundImage:
        "linear-gradient(45deg, #3a4a50 25%, transparent 25%, transparent 75%, #3a4a50 75%, #3a4a50)," +
        "linear-gradient(45deg, #3a4a50 25%, transparent 25%, transparent 75%, #3a4a50 75%, #3a4a50)",
      backgroundSize: `${px}px ${px}px`,
      backgroundPosition: `0 0, ${px / 2}px ${px / 2}px`,
      boxShadow: D.cyanGlow,
    }}>
      {/* painted pixels */}
      {map.map((row, y) => row.split("").map((c, x) => c !== "." && (
        <div key={`${x}-${y}`} style={{
          position: "absolute", left: x * px, top: y * px, width: px, height: px,
          background: colors[c],
        }} />
      )))}
      {/* faint pixel grid */}
      <div style={{
        position: "absolute", inset: 0, pointerEvents: "none",
        backgroundImage:
          "linear-gradient(to right, rgba(255,255,255,0.05) 1px, transparent 1px)," +
          "linear-gradient(to bottom, rgba(255,255,255,0.05) 1px, transparent 1px)",
        backgroundSize: `${px}px ${px}px`,
      }} />
    </div>
  );
}

function Tool({ name, label, active, onClick }) {
  return (
    <button onClick={onClick} style={{
      all: "unset", boxSizing: "border-box", cursor: "pointer",
      display: "flex", alignItems: "center", gap: 8, padding: "9px 11px",
      borderRadius: D.rBtn, fontFamily: D.fontUI, fontSize: 13, fontWeight: 600,
      background: active ? D.accent : D.chip, color: active ? D.accentTxt : D.txt,
      border: `1px solid ${active ? "transparent" : D.border}`,
    }}>
      <DIcon name={name} size={15} />{label}
    </button>
  );
}

function SectionLabel({ children }) {
  return <div style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: 0.7, color: D.txtFaint, textTransform: "uppercase", margin: "2px 0 2px" }}>{children}</div>;
}

// existing sprites the student can re-open and edit
const EXISTING = [
  { id: "coin", name: "coin", map: COIN, colors: COIN_COLORS, on: true },
  { id: "hero", name: "hero" },
  { id: "slime", name: "slime" },
  { id: "flag", name: "flag" },
];

function SpriteThumb({ s, active }) {
  return (
    <button title={s.name} style={{
      all: "unset", cursor: "pointer", boxSizing: "border-box",
      width: 52, height: 52, borderRadius: 8, flex: "none",
      display: "flex", alignItems: "center", justifyContent: "center",
      background: "#46575d",
      backgroundImage:
        "linear-gradient(45deg, #3a4a50 25%, transparent 25%, transparent 75%, #3a4a50 75%, #3a4a50)," +
        "linear-gradient(45deg, #3a4a50 25%, transparent 25%, transparent 75%, #3a4a50 75%, #3a4a50)",
      backgroundSize: "10px 10px", backgroundPosition: "0 0, 5px 5px",
      border: active ? `2px solid ${D.cyan}` : `1px solid ${D.border}`,
      boxShadow: active ? D.cyanGlow : "none", overflow: "hidden",
    }}>
      {s.map
        ? <Canvas16 map={s.map} colors={s.colors} px={3} />
        : <span style={{ fontFamily: D.fontMono, fontSize: 9, color: D.txtFaint }}>{s.name}</span>}
    </button>
  );
}

function SpriteEditorV1() {
  const [tool, setTool] = React.useState("pencil");
  const [color, setColor] = React.useState("#f7c873");
  return (
    <div style={{
      width: 860, height: 600, background: D.panel, borderRadius: D.rCard,
      border: `1px solid ${D.border}`, boxShadow: D.shadowDialog, fontFamily: D.fontUI,
      color: D.txt, display: "flex", flexDirection: "column", overflow: "hidden",
    }}>
      {/* header */}
      <div style={{
        display: "flex", alignItems: "center", gap: 12, padding: "14px 18px",
        borderBottom: `1px solid ${D.border}`, background: D.panelHeader,
      }}>
        <span style={{ color: D.cyan }}><DIcon name="pencil" size={16} /></span>
        <input defaultValue="coin" style={{
          all: "unset", padding: "8px 12px", background: D.surface, border: `1px solid ${D.border}`,
          borderRadius: D.rInput, fontFamily: D.fontMono, fontSize: 14, color: D.txt, width: 180,
        }} />
        <span style={{ fontSize: 12, color: D.txtFaint }}>editing existing sprite · 16×16</span>
        <div style={{ flex: 1 }} />
        <button style={dBtn("secondary")}>Cancel</button>
        <button style={dBtn("primary")}><DIcon name="check" size={14} />Save</button>
      </div>

      <div style={{ flex: 1, display: "flex", minHeight: 0 }}>
        {/* left — canvas + existing-sprite strip */}
        <div style={{ flex: 1, padding: 20, display: "flex", flexDirection: "column", gap: 16, minWidth: 0 }}>
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <span style={{ fontSize: 11.5, color: D.txtMute }}>Grid</span>
            {["16×16", "32×32"].map((g, i) => (
              <button key={g} style={{
                all: "unset", cursor: "pointer", padding: "5px 12px", borderRadius: D.rPill,
                fontSize: 12, fontWeight: 600, background: i === 0 ? D.cyanSoft : D.chip,
                color: i === 0 ? D.cyan : D.txtMute, border: `1px solid ${i === 0 ? D.cyanLine : D.border}`,
              }}>{g}</button>
            ))}
          </div>
          <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Canvas16 />
          </div>
          {/* EDIT-EXISTING strip */}
          <div>
            <SectionLabel>Sprites in this project</SectionLabel>
            <div style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 6 }}>
              {EXISTING.map(s => <SpriteThumb key={s.id} s={s} active={s.on} />)}
              <button title="New sprite" style={{
                all: "unset", cursor: "pointer", width: 52, height: 52, borderRadius: 8, flex: "none",
                display: "flex", alignItems: "center", justifyContent: "center",
                background: D.chip, border: `1px dashed ${D.borderStrong}`, color: D.txtMute,
              }}><DIcon name="plus" size={18} /></button>
            </div>
          </div>
        </div>

        {/* right rail — tools */}
        <div style={{
          width: 224, borderLeft: `1px solid ${D.border}`, background: D.surface,
          padding: 16, display: "flex", flexDirection: "column", gap: 14, overflowY: "auto",
        }}>
          <div>
            <SectionLabel>Tools</SectionLabel>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 7, marginTop: 4 }}>
              <Tool name="pencil" label="Pencil" active={tool === "pencil"} onClick={() => setTool("pencil")} />
              <Tool name="close" label="Eraser" active={tool === "eraser"} onClick={() => setTool("eraser")} />
              <Tool name="folder" label="Fill" active={tool === "fill"} onClick={() => setTool("fill")} />
              <Tool name="eye" label="Pick" active={tool === "pick"} onClick={() => setTool("pick")} />
            </div>
          </div>

          <div>
            <SectionLabel>Colour</SectionLabel>
            <div style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 4 }}>
              <div style={{ width: 34, height: 34, borderRadius: 7, background: color, border: `1px solid ${D.borderStrong}`, boxShadow: "inset 0 0 0 2px rgba(0,0,0,0.2)" }} />
              <div style={{ flex: 1, height: 10, borderRadius: 5, background: `linear-gradient(90deg, #fff, ${color})` }} />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 6, marginTop: 10 }}>
              {PALETTE.map(c => (
                <button key={c} onClick={() => setColor(c)} style={{
                  all: "unset", cursor: "pointer", aspectRatio: "1", borderRadius: 6, background: c,
                  border: color === c ? `2px solid ${D.cyan}` : `1px solid rgba(0,0,0,0.25)`,
                  boxShadow: color === c ? D.cyanGlow : "none",
                }} />
              ))}
            </div>
          </div>

          <div>
            <SectionLabel>Layers</SectionLabel>
            <div style={{
              display: "flex", alignItems: "center", gap: 8, padding: "8px 10px", marginTop: 4,
              borderRadius: D.rBtn, background: D.cyanSoft, border: `1px solid ${D.cyanLine}`,
            }}>
              <span style={{ color: D.cyan }}><DIcon name="eye" size={14} /></span>
              <span style={{ fontSize: 13, fontWeight: 600, flex: 1 }}>Layer 1</span>
              <DIcon name="dot3" size={14} color={D.txtMute} />
            </div>
          </div>

          <div style={{ flex: 1 }} />
          <div style={{ display: "flex", gap: 7 }}>
            <button style={{ ...dBtn("secondary"), flex: 1 }}><DIcon name="back" size={13} />Undo</button>
            <button style={{ ...dBtn("ghost"), flex: 1, border: `1px solid ${D.border}` }}>Redo</button>
          </div>
        </div>
      </div>
    </div>
  );
}

window.SpriteEditorV1 = SpriteEditorV1;
