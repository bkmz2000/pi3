/* global React, D, Pi3, DIcon, dBtn, DAvatar, DRoleTag */
// v1 TEACHER IN THE IDE — same shell, two states. v1 scope is minimal:
// a real class ROSTER + READ-ONLY view of a student's code.
// (No live help queue / comments — those are v2.)

const ROSTER = [
  { name: "Ada Lovelace",   proj: "Snake",          status: "coding", min: 0 },
  { name: "Linus T.",       proj: "Asteroids Remix",status: "coding", min: 1 },
  { name: "Grace Hopper",   proj: "Platformer",     status: "idle",   min: 8 },
  { name: "Alan Turing",    proj: "Pong",           status: "done",   min: 2 },
  { name: "Katherine J.",   proj: "Maze",           status: "coding", min: 0 },
  { name: "Edsger D.",      proj: "hello world",    status: "idle",   min: 22 },
  { name: "Margaret H.",    proj: "Tetris",         status: "coding", min: 3 },
  { name: "Tim B-L.",       proj: "Breakout",       status: "done",   min: 5 },
];

function StatusDot({ status }) {
  const c = status === "coding" ? D.run : status === "done" ? D.cyan : D.txtFaint;
  const label = status === "coding" ? "Coding now" : status === "done" ? "Ran successfully" : "Idle";
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 11.5, color: D.txtMute, fontWeight: 600 }}>
      <span style={{ width: 8, height: 8, borderRadius: 99, background: c, boxShadow: status === "coding" ? `0 0 8px ${D.run}` : "none" }} />
      {label}
    </span>
  );
}

// Teacher shell chrome (rail + topbar)
function TeacherShell({ children, crumb, back }) {
  return (
    <div style={{
      width: 1180, height: 760, display: "flex", borderRadius: D.rCard, overflow: "hidden",
      border: `1px solid ${D.border}`, boxShadow: D.shadowDialog, fontFamily: D.fontUI, background: D.appBg,
    }}>
      {/* rail */}
      <div style={{ width: 56, background: D.rail, display: "flex", flexDirection: "column", alignItems: "center", padding: "12px 0", gap: 6, flex: "none", borderRight: `1px solid ${D.border}` }}>
        <div style={{ marginBottom: 10 }}><Pi3 size={20} /></div>
        {[{ i: "users", on: true }, { i: "folder" }, { i: "dot3" }].map((it, k) => (
          <button key={k} style={{
            all: "unset", cursor: "pointer", width: 40, height: 40, borderRadius: 10,
            display: "inline-flex", alignItems: "center", justifyContent: "center",
            background: it.on ? "rgba(120,210,220,0.18)" : "transparent",
            color: it.on ? D.cyan : "rgba(155,210,216,0.7)",
            boxShadow: it.on ? `inset 0 0 0 1px ${D.cyanLine}` : "none",
          }}><DIcon name={it.i} size={18} /></button>
        ))}
        <div style={{ flex: 1 }} />
        <DAvatar name="Ms Hopper" role="teacher" size={32} />
      </div>

      <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
        {/* topbar */}
        <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "13px 18px", borderBottom: `1px solid ${D.border}`, background: D.surface }}>
          {back && <button style={{ ...dBtn("ghost"), border: `1px solid ${D.border}`, padding: "7px 12px" }}><DIcon name="back" size={13} />Class</button>}
          <div style={{ fontSize: 15, fontWeight: 800, color: D.txt }}>{crumb}</div>
          <DRoleTag role="teacher" />
          <div style={{ flex: 1 }} />
          <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 12px", borderRadius: D.rInput, background: D.panel, border: `1px solid ${D.border}`, color: D.txtMute }}>
            <DIcon name="search" size={14} />
            <span style={{ fontSize: 12.5 }}>Find a student…</span>
          </div>
        </div>
        {children}
      </div>
    </div>
  );
}

// ── STATE 1 — class roster replaces the editor ────────────────────────────
function TeacherIDEHome() {
  return (
    <TeacherShell crumb="Period 3 · Game Design">
      <div style={{ flex: 1, overflowY: "auto", padding: 22, background: D.appBg }}>
        <div style={{ display: "flex", alignItems: "baseline", gap: 12, marginBottom: 16 }}>
          <div style={{ fontSize: 13, color: D.txtMute }}>
            <b style={{ color: D.txt }}>26 students</b> · 18 coding now
          </div>
          <div style={{ flex: 1 }} />
          <button style={{ ...dBtn("secondary") }}><DIcon name="plus" size={14} />Add students</button>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14 }}>
          {ROSTER.map((s, i) => (
            <div key={i} style={{
              background: D.surface, border: `1px solid ${D.border}`, borderRadius: D.rCard,
              padding: 15, display: "flex", flexDirection: "column", gap: 11, cursor: "pointer",
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <DAvatar name={s.name} role="student" size={34} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 700, color: D.txt, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{s.name}</div>
                  <div style={{ fontSize: 11, color: D.txtFaint }}>{s.min === 0 ? "active now" : `${s.min}m ago`}</div>
                </div>
              </div>
              {/* mini code/canvas preview */}
              <div style={{
                height: 64, borderRadius: 8, background: D.editorBg, border: `1px solid ${D.border}`,
                padding: "8px 10px", fontFamily: D.fontMono, fontSize: 8.5, lineHeight: 1.5, color: D.txtFaint, overflow: "hidden",
              }}>
                <div><span style={{ color: D.cyan }}>import</span> graphics</div>
                <div style={{ color: D.run }}>ship = actor(...)</div>
                <div><span style={{ color: D.accent }}>@on_key</span>(<span style={{ color: "#9be7c0" }}>"up"</span>)</div>
                <div><span style={{ color: D.cyan }}>def</span> move(): ...</div>
              </div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ fontFamily: D.fontMono, fontSize: 11.5, color: D.txt, fontWeight: 600 }}>{s.proj}</span>
                <StatusDot status={s.status} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </TeacherShell>
  );
}

// ── STATE 2 — read-only review of one student ─────────────────────────────
function TeacherIDEReview() {
  const code = [
    ["import", " graphics ", "as", " g"],
    ["comment", "# Linus's asteroids remix"],
    ["plain", "ship = g.actor(", "str", '"ship.svg"', "plain", ")"],
    ["plain", "ship.set_coords(200, 200)"],
    ["blank"],
    ["dec", "@g.on_key_press(", "str", '"space"', "dec", ")"],
    ["kw", "def", " ", "fn", "fire", "plain", "():"],
    ["plain", "    bullet = g.actor(", "str", '"bullet.svg"', "plain", ")"],
    ["plain", "    bullet.point_to(ship.angle)"],
    ["plain", "    bullet.set_speed(8, 8)"],
    ["blank"],
    ["dec", "@g.every(", "num", "30", "dec", ")"],
    ["kw", "def", " ", "fn", "spawn_rock", "plain", "():"],
    ["plain", "    g.actor(", "str", '"asteroid.svg"', "plain", ")"],
  ];
  const col = { import: D.cyan, kw: D.cyan, as: D.cyan, comment: "#5b8489", str: "#9be7c0", dec: D.accent, num: D.warn, fn: "#7adfe6", plain: D.txt };
  return (
    <TeacherShell crumb="Linus T. · Asteroids Remix" back>
      <div style={{ flex: 1, display: "flex", minHeight: 0 }}>
        {/* roster sidebar */}
        <div style={{ width: 210, borderRight: `1px solid ${D.border}`, background: D.surface, overflowY: "auto", padding: 8, flex: "none" }}>
          {ROSTER.map((s, i) => (
            <div key={i} style={{
              display: "flex", alignItems: "center", gap: 9, padding: "8px 9px", borderRadius: D.rBtn,
              background: i === 1 ? D.cyanSoft : "transparent", cursor: "pointer", marginBottom: 2,
              boxShadow: i === 1 ? `inset 0 0 0 1px ${D.cyanLine}` : "none",
            }}>
              <DAvatar name={s.name} role="student" size={26} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12, fontWeight: i === 1 ? 700 : 500, color: D.txt, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{s.name}</div>
              </div>
              <span style={{ width: 7, height: 7, borderRadius: 99, background: s.status === "coding" ? D.run : s.status === "done" ? D.cyan : D.txtFaint }} />
            </div>
          ))}
        </div>

        {/* read-only editor */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0, background: D.editorBg }}>
          {/* read-only banner */}
          <div style={{
            display: "flex", alignItems: "center", gap: 9, padding: "9px 16px",
            background: D.cyanSoft, borderBottom: `1px solid ${D.cyanLine}`, color: D.cyan, fontSize: 12.5, fontWeight: 600,
          }}>
            <DIcon name="eye" size={14} /> Read-only — you're viewing Linus's live code
            <div style={{ flex: 1 }} />
            <span style={{ fontFamily: D.fontMono, fontSize: 11, color: D.txtMute }}>updated 3s ago</span>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center", padding: "9px 14px", borderBottom: `1px solid ${D.border}`, background: D.surface }}>
            <span style={{ padding: "5px 12px", borderRadius: 7, background: D.panel, color: D.txt, fontFamily: D.fontMono, fontSize: 12, fontWeight: 600 }}>main.py</span>
            <span style={{ padding: "5px 12px", borderRadius: 7, color: D.txtMute, fontFamily: D.fontMono, fontSize: 12 }}>ship_cfg.py</span>
          </div>
          <div style={{ flex: 1, display: "flex", fontFamily: D.fontMono, fontSize: 13, lineHeight: 1.85, overflow: "auto" }}>
            {/* gutter */}
            <div style={{ padding: "14px 0", textAlign: "right", color: D.txtFaint, userSelect: "none", background: "rgba(0,0,0,0.12)", minWidth: 42 }}>
              {code.map((_, i) => <div key={i} style={{ padding: "0 12px" }}>{i + 1}</div>)}
            </div>
            <div style={{ padding: "14px 16px", flex: 1 }}>
              {code.map((row, i) => (
                <div key={i} style={{ minHeight: "1.85em", whiteSpace: "pre" }}>
                  {row[0] === "blank" ? " " : row.reduce((acc, tok, j) => {
                    if (j % 2 === 0) { acc._k = tok; return acc; }
                    acc.push(<span key={j} style={{ color: col[acc._k] || D.txt }}>{tok}</span>);
                    return acc;
                  }, Object.assign([], { _k: "plain" }))}
                </div>
              ))}
            </div>
          </div>
          {/* v1 action bar — read-only, no comments yet */}
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "11px 16px", borderTop: `1px solid ${D.border}`, background: D.surface }}>
            <span style={{ fontSize: 12, color: D.txtFaint }}>Comments &amp; live help arrive in a later update.</span>
            <div style={{ flex: 1 }} />
            <button style={dBtn("secondary")}><DIcon name="download" size={14} />Open a copy</button>
          </div>
        </div>
      </div>
    </TeacherShell>
  );
}

window.TeacherIDEHome = TeacherIDEHome;
window.TeacherIDEReview = TeacherIDEReview;
