/* global React */
// pi3 v1 — DARK TEAL ("Midnight") tokens, lifted verbatim from
// src/state/useTheme.ts so these screens match the shipping editor exactly.
const D = {
  // Surfaces
  appBg:        "#06181b",
  surface:      "#0c2e34",
  panel:        "#11444b",
  panelHeader:  "#0f3a40",
  rail:         "#072428",
  console:      "#072428",
  editorBg:     "#0e3a40",

  border:       "rgba(148,210,216,0.14)",
  borderStrong: "rgba(148,210,216,0.28)",
  chip:         "rgba(255,255,255,0.06)",
  chipHover:    "rgba(255,255,255,0.10)",

  // Text
  txt:       "#e8f2f4",
  txtMute:   "#9bb3b8",
  txtFaint:  "#5b8489",

  // Brand / accents
  cyan:      "#5fd4dc",
  cyanBright:"#22d3ee",
  cyanSoft:  "rgba(120,210,220,0.14)",
  cyanLine:  "rgba(120,210,220,0.40)",
  cyanGlow:  "0 0 0 1px rgba(95,212,220,0.5), 0 0 18px -2px rgba(95,212,220,0.45)",

  accent:    "#f7b67a",   // warm peach — primary action
  accentDeep:"#e0975a",
  accentTxt: "#062a26",

  // Roles
  student:     "#f7b67a",
  studentSoft: "rgba(247,182,122,0.16)",
  studentLine: "rgba(247,182,122,0.45)",
  teacher:     "#5fd4dc",
  teacherSoft: "rgba(95,212,220,0.15)",
  teacherLine: "rgba(95,212,220,0.42)",

  // Status
  run:       "#7ed3a4",
  runTxt:    "#062a26",
  ok:        "#7ee0a8",
  okSoft:    "rgba(126,224,168,0.14)",
  warn:      "#fbbf77",
  warnSoft:  "rgba(251,191,119,0.15)",
  danger:    "#ff8b8b",
  dangerSoft:"rgba(255,139,139,0.14)",
  dangerTxt: "#062a26",

  // Typography
  fontUI:   "'Inter', system-ui, sans-serif",
  fontMono: "'JetBrains Mono', ui-monospace, monospace",

  // Radii
  rCard:  12,
  rBtn:   8,
  rPill:  999,
  rInput: 8,

  shadowPop:    "0 16px 40px -12px rgba(0,0,0,0.55), 0 2px 10px rgba(0,0,0,0.35)",
  shadowDialog: "0 30px 70px -20px rgba(0,0,0,0.6), 0 4px 18px rgba(0,0,0,0.3)",
};
window.D = D;

// pi3 wordmark
window.Pi3 = function Pi3({ size = 20, color }) {
  return (
    <span style={{
      fontFamily: D.fontMono, fontWeight: 700, fontSize: size,
      color: color || D.cyan, letterSpacing: -0.5, lineHeight: 1,
    }}>
      pi<span style={{ fontSize: size * 0.62, verticalAlign: "0.2em" }}>3</span>
    </span>
  );
};

window.DAvatar = function DAvatar({ name, role = "student", size = 30 }) {
  const initials = (name || "?")
    .split(/[\s_.\-]+/).map(p => p[0]).filter(Boolean).join("").toUpperCase().slice(0, 2);
  const bg = role === "teacher" ? D.teacher : D.student;
  return (
    <span style={{
      width: size, height: size, borderRadius: D.rPill, background: bg, color: "#062a26",
      display: "inline-flex", alignItems: "center", justifyContent: "center",
      fontFamily: D.fontUI, fontWeight: 800, fontSize: Math.round(size * 0.4), flex: "none",
    }}>{initials}</span>
  );
};

window.DRoleTag = function DRoleTag({ role }) {
  const t = role === "teacher";
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5, padding: "2px 9px 2px 7px",
      borderRadius: D.rPill, background: t ? D.teacherSoft : D.studentSoft,
      color: t ? D.cyan : D.accent, fontFamily: D.fontUI, fontSize: 10.5, fontWeight: 700,
      letterSpacing: 0.4, textTransform: "uppercase",
    }}>
      <span style={{ width: 6, height: 6, borderRadius: D.rPill, background: t ? D.teacher : D.student }} />
      {t ? "Teacher" : "Student"}
    </span>
  );
};

// Minimal stroke-icon set
window.DI = {
  close: <path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/>,
  check: <path d="M3 8.5l3 3 7-7" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" fill="none"/>,
  plus:  <path d="M8 3v10M3 8h10" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"/>,
  minus: <path d="M3 8h10" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round"/>,
  chev:  <path d="M5 6l3 3 3-3" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" fill="none"/>,
  back:  <path d="M10 4l-4 4 4 4" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" fill="none"/>,
  folder:<path d="M2.5 5a1 1 0 0 1 1-1h2.2l1.3 1.4h5.5a1 1 0 0 1 1 1V12a1 1 0 0 1-1 1H3.5a1 1 0 0 1-1-1V5z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" fill="none"/>,
  file:  <path d="M4.5 2.5h4l3 3V13a.5.5 0 0 1-.5.5h-6a.5.5 0 0 1-.5-.5V3a.5.5 0 0 1 .5-.5zM8.5 2.5V5.5h3" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" fill="none"/>,
  search:<g stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round"><circle cx="7" cy="7" r="4"/><path d="M10 10l3 3"/></g>,
  dot3:  <g fill="currentColor"><circle cx="3" cy="8" r="1.2"/><circle cx="8" cy="8" r="1.2"/><circle cx="13" cy="8" r="1.2"/></g>,
  arrow: <path d="M3 8h10m-4-4l4 4-4 4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" fill="none"/>,
  trash: <path d="M3.5 5h9m-7 0V3.8a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1V5m-5.5 0v7.2a1 1 0 0 0 1 1h4a1 1 0 0 0 1-1V5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" fill="none"/>,
  share: <g stroke="currentColor" strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="4" r="1.8"/><circle cx="4" cy="8" r="1.8"/><circle cx="12" cy="12" r="1.8"/><path d="M5.6 7.1l4.8-2.2M5.6 8.9l4.8 2.2"/></g>,
  download:<path d="M8 3v7m0 0l-3-3m3 3l3-3M3.5 13h9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none"/>,
  cloud: <path d="M5 12h6.2a2.3 2.3 0 0 0 .3-4.58A3.3 3.3 0 0 0 5.2 6.4 2.6 2.6 0 0 0 5 12z" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round" fill="none"/>,
  pencil:<path d="M11 3.2l1.8 1.8L6 11.8l-2.3.5.5-2.3L11 3.2z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" fill="none"/>,
  eye:   <g stroke="currentColor" strokeWidth="1.3" fill="none"><path d="M1.8 8S4 4 8 4s6.2 4 6.2 4-2.2 4-6.2 4S1.8 8 1.8 8z"/><circle cx="8" cy="8" r="1.6"/></g>,
  warn:  <path d="M8 2.6l6 10.4H2L8 2.6zM8 6.5v3M8 11.2v.01" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none"/>,
  users: <path d="M6 9a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5zm5 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM2 14c0-2 1.8-3.5 4-3.5S10 12 10 14m1.5-3c1.5 0 3 1 3 3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" fill="none"/>,
  google:<g><path d="M14.4 8.16c0-.45-.04-.9-.12-1.32H8v2.5h3.6a3.08 3.08 0 0 1-1.34 2.02v1.68h2.17c1.27-1.17 2-2.9 2-4.88z" fill="#5fd4dc"/><path d="M8 14.5c1.8 0 3.32-.6 4.43-1.62l-2.17-1.68c-.6.4-1.37.64-2.26.64-1.74 0-3.21-1.17-3.74-2.75H2.02v1.73A6.5 6.5 0 0 0 8 14.5z" fill="rgba(232,242,244,0.75)"/><path d="M4.26 9.09a3.9 3.9 0 0 1 0-2.49V4.87H2.02a6.5 6.5 0 0 0 0 5.84l2.24-1.62z" fill="rgba(232,242,244,0.45)"/><path d="M8 4.6c.98 0 1.86.34 2.55 1l1.9-1.9A6.5 6.5 0 0 0 2.02 4.87L4.26 6.6C4.79 5.02 6.26 4.6 8 4.6z" fill="#f7b67a"/></g>,
  play:  <path d="M5 3.5l7 4.5-7 4.5z" fill="currentColor"/>,
  stop:  <rect x="4.5" y="4.5" width="7" height="7" rx="1.2" fill="currentColor"/>,
  pause: <g fill="currentColor"><rect x="4.5" y="4" width="2.5" height="8" rx="1"/><rect x="9" y="4" width="2.5" height="8" rx="1"/></g>,
  refresh:<path d="M12.5 5.5A5 5 0 1 0 13 9M12.5 3v2.6H9.9" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" fill="none"/>,
  lock:  <g stroke="currentColor" strokeWidth="1.3" fill="none"><rect x="3.5" y="7" width="9" height="6" rx="1.3"/><path d="M5.5 7V5.3a2.5 2.5 0 0 1 5 0V7"/></g>,
};

window.DIcon = function DIcon({ name, size = 14, color = "currentColor" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" style={{ color, flex: "none", display: "block" }}>
      {window.DI[name]}
    </svg>
  );
};

// Shared button factory
window.dBtn = function dBtn(kind = "secondary") {
  const base = {
    all: "unset", boxSizing: "border-box", cursor: "pointer",
    display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 7,
    fontFamily: window.D.fontUI, fontSize: 13, fontWeight: 600,
    padding: "9px 15px", borderRadius: window.D.rBtn, textAlign: "center",
  };
  const D = window.D;
  if (kind === "primary") return { ...base, background: D.accent, color: D.accentTxt, fontWeight: 700 };
  if (kind === "ghost")   return { ...base, background: "transparent", color: D.txtMute };
  if (kind === "danger")  return { ...base, background: D.dangerSoft, color: D.danger };
  return { ...base, background: D.chip, color: D.txt, border: `1px solid ${D.border}` };
};
