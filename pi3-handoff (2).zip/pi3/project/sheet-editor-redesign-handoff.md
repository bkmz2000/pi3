# Sheet Editor — Redesign Handoff

Reference prototype: `Sheet Editor Redesign.html`  
Source file: `src/SheetEditor.tsx`

---

## What Changed and Why

The original editor crammed all controls into a single horizontal toolbar row: undo/redo, 10 tool buttons, 4 brush sizes, tile palette, stacked colour swatches, 10 lerp buttons, and view controls — all at once. The hierarchy panel had a `borderRight` instead of `borderLeft`, and the overall visual language was flat and undifferentiated.

---

## Layout Restructure

### Before
```
┌──────────────────────────────────────────────── [everything] ──┐  ← 1 toolbar row
├─────────────────────────────────────────────┬───────────────────┤
│                 CANVAS                      │  hierarchy 180px  │  ← borderRight bug
└─────────────────────────────────────────────┴───────────────────┘
```

### After
```
┌─── title │ undo redo │ panel grid fit ──────────────── close ──┐  ← slim header 44px
├──────┬──────────────────────────────────────────┬──────────────┤
│      │                                          │              │
│tools │             CANVAS                       │  SPRITES     │  ← panel on right
│strip │                                          │   w: 206px   │  ← borderLeft ✓
│ 50px │                                [zoom]    │              │
├──────┴──────────────────────────────────────────┴──────────────┤
│ A/B │ palette 8×2 │ lerp strip │ brush dots │       coords     │  ← status bar 40px
└─────────────────────────────────────────────────────────────────┘
```

---

## Changes by Area

### 1. Header (`<div>` toolbar)
- **Remove**: all tool buttons, brush sizes, colour swatches, lerp strip, tile palette
- **Keep**: title, undo, redo, panel-toggle, grid-toggle, fit-to-view, close
- Height: `44px`
- Background: `theme.panelHeader` (deepest panel tone)

### 2. New: Left Tool Strip
Add a vertical `<aside>` before the canvas scroll area.

```tsx
// Layout wrapper change — add tools aside:
<div style={{ display: "flex", flex: 1, overflow: "hidden" }}>
  <aside style={{
    width: 50, flexShrink: 0,
    display: "flex", flexDirection: "column", alignItems: "center",
    padding: "8px 0", gap: 1,
    background: theme.panelHeader,
    borderRight: `1px solid ${theme.panelBorder}`,
    overflowY: "auto",
  }}>
    {/* Group 1: select, pencil, eraser, fill */}
    {/* Group 2: darken, lighten */}
    {/* Group 3: line, rect, ellipse */}
    {/* Group 4: region, tile */}
    {/* Dividers between groups */}
  </aside>

  {/* canvas scroll area — unchanged */}
  <div ref={scrollRef} style={{ flex: 1, overflow: "auto" }}>
    ...
  </div>

  {/* hierarchy panel */}
  ...
</div>
```

Tool button spec:
- Size: `38×34px`, `borderRadius: 6`
- Inactive: color `panelTxtMute`, background transparent
- Hover: background `chip`
- Active: background `accent`, color `#1e0800`
- Tooltip via `title` attribute (existing behaviour)
- Dividers: `1px solid panelBorder`, width `26px`, margin `5px 0`

### 3. Hierarchy Panel
- Fix `borderRight` → `borderLeft`
- Widen: `180px` → `206px`
- Panel header height: `34px`, background `panelHeader`
- Header label: `9.5px`, `700`, `panelTxtMute`, `letter-spacing: 0.07em`, uppercase
- Sprite rows:
  - Selected: `background: accent + "22"` (unchanged logic, just ensure amber not teal)
- Animation rows:
  - Active: `background: teal + "11"`, name color `#5fd4dc`, dot `background: #5fd4dc` with `box-shadow: 0 0 4px #5fd4dc`
  - fps + frame count chips: `9px`, `panelTxtMute`, subtle border chip style
  - Delete `×` button: opacity 0, show on row hover; red on hover

Add mini thumbnail canvases (`26×20px`) to each sprite row. Draw from the sheet canvas on mount/update using `ctx.drawImage(sheetCanvas, sx, sy, sw, sh, dx, dy, dw, dh)` with `imageSmoothingEnabled = false`.

### 4. Status Bar (new bottom bar)
Replace the existing coordinate-only status bar with a full-width bar containing:

```
[A/B swatches] [8×2 palette grid] [sep] [10-step lerp strip] [sep] [brush dots] [coords →]
```

Height: `40px`, background `panelHeader`, `borderTop: 1px solid panelBorder`

**A/B colour stack** — keep existing stacking logic, just reposition here.

**Palette grid**: `display: grid; grid-template-columns: repeat(8, 14px); gap: 2px`  
Each swatch: `14×11px`, `borderRadius: 2`, hover scale `1.3`.

**Lerp strip**: `12×20px` per swatch, gap `2px`. (Moved from toolbar — same logic.)

**Brush size selector** — replace text pills with visual dots:
```tsx
const BRUSH_SIZES = [
  { size: 1, dotPx: 3 },
  { size: 2, dotPx: 5 },
  { size: 4, dotPx: 9 },
  { size: 8, dotPx: 15 },
];
// Button: 28×28px, borderRadius 5, border 1.5px transparent
// Active: accent-tinted background + accent-tinted border
// Inner div: dotPx × dotPx square, borderRadius 1
//   color panelTxtMute → panelTxt on hover → accent when active
```

**Coordinates**: `marginLeft: auto`, `font-family: fontMono`, `10.5px`, `panelTxtMute`

### 5. Canvas Overlays — Sprite UI
These already exist in `SheetEditor.tsx` as absolutely-positioned divs. Improvements:

**Sprite label tag** (top of each sprite block):
```tsx
style={{
  height: 20, background: "rgba(6,22,26,0.88)",
  backdropFilter: "blur(6px)",
  borderRadius: "4px 4px 0 0",
  fontSize: 10, fontWeight: 700,
}}
```

**Animation label** (rotated left of each row):
```tsx
style={{
  writingMode: "vertical-lr", transform: "rotate(180deg)",
  fontSize: 8.5, color: "rgba(255,255,255,0.5)",
  background: "rgba(6,22,26,0.7)",
  padding: "3px 2px", borderRadius: 2,
}}
```

**Frame cell borders**: `rgba(95,212,220,0.22)` inactive, `#5fd4dc` selected with inner glow

**Add-frame `+` button** (right of each row):
```tsx
style={{
  width: 16, height: rowH,
  background: "rgba(6,22,26,0.6)",
  color: "rgba(255,255,255,0.45)",
  border: "1px dashed rgba(148,210,216,0.25)",
  // hover: teal tint
}}
```

**Add-animation button** (bottom of sprite block):
```tsx
style={{
  height: 17, padding: "0 10px",
  background: "rgba(6,22,26,0.6)",
  border: "1px dashed rgba(148,210,216,0.22)",
  borderRadius: "0 0 4px 4px",
  fontSize: 10,
  // hover: teal tint
}}
```

**FPS input** (bottom-right corner of each row, only when `rowH >= 28`):
```tsx
style={{
  position: "absolute", right: 20, bottom: 4,
  width: 34, height: 16,
  background: "rgba(6,22,26,0.82)",
  color: "rgba(95,212,220,0.65)",
  border: "1px solid rgba(95,212,220,0.18)",
  borderRadius: 3,
  fontSize: 8.5, fontFamily: fontMono,
  textAlign: "center",
  // hide spin arrows via appearance: textfield
}}
```

### 6. Zoom Widget
Keep the existing float but improve styles:
```tsx
style={{
  position: "absolute", bottom: 14, right: 14,
  display: "flex", gap: 2, alignItems: "center",
  background: surfacePanel, border: `1px solid ${panelBorder}`,
  borderRadius: 8, padding: "3px 5px",
  boxShadow: "0 4px 20px rgba(0,0,0,0.45)",
  zIndex: 10,
}}
```

---

## Icon Pack Migration

**Recommended: Lucide React**

```bash
npm install lucide-react
```

Remove `react-icons` from `package.json` after migration.

### Direct replacements for SheetEditor.tsx

| Remove | Add |
|---|---|
| `MdNearMe` | `MousePointer2` |
| `MdEdit` | `Pencil` |
| `FaEraser` | `Eraser` |
| `MdFormatPaint` | `PaintBucket` |
| `MdBrightnessLow` | `SunDim` |
| `MdBrightnessHigh` | `Sun` |
| `MdShowChart` | `Spline` |
| `MdCropSquare` | `Square` |
| `MdCircle` | `Circle` |
| `FaStamp` | `Stamp` |
| `MdGridView` | `LayoutGrid` |
| `MdUndo` | `Undo2` |
| `MdRedo` | `Redo2` |
| `MdGridOn` | `Grid2x2` |
| `MdZoomOutMap` | `Maximize` |
| `MdViewList` | `PanelRight` |

Import syntax:
```tsx
import { Pencil, Eraser, PaintBucket, Undo2, Redo2, Grid2x2, Maximize, PanelRight, Square, Circle, Spline, MousePointer2, SunDim, Sun, LayoutGrid, Stamp } from "lucide-react";
```

All Lucide icons accept `size`, `color`, `strokeWidth` props. Use `size={18}` for toolbar, `size={20}` for left tool strip.

---

## Theme Token Reference

All colour values come from `useThemeStore`. The redesign uses only existing tokens — no new colours were introduced.

| Token | Midnight value | Usage |
|---|---|---|
| `panelHeader` | `#0f3a40` | Header, tool strip, status bar bg |
| `surfacePanel` | `#11444b` | Hierarchy panel, zoom widget bg |
| `panelBorder` | `rgba(148,210,216,0.13)` | All dividers and borders |
| `accent` | `#f7b67a` | Active tool, active brush, active palette swatch |
| `#5fd4dc` (teal) | — | Active animation row, selected frame border, fps input |
| `panelTxtMute` | `#9bb3b8` | Inactive icon colour |
| `panelTxt` | `#e8f2f4` | Primary text |
| `chip` | `rgba(255,255,255,0.05)` | Hover background on buttons |

Note: `#5fd4dc` (`canvasStar` / `canvasHud`) is not exposed as a named token in `Theme` but is used throughout the canvas overlay UI. Consider adding `teal: string` to the `Theme` interface.
